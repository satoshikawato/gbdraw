#!/usr/bin/env python
# coding: utf-8

"""Protein-level colinearity helpers for linear pairwise comparisons."""

from __future__ import annotations

import copy
from contextlib import ExitStack
from dataclasses import dataclass, field, replace
import base64
import hashlib
from importlib import resources
from io import StringIO
import json
import logging
import math
import os
import platform
from pathlib import Path
import re
import stat
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from typing import Callable, Literal, Mapping, Sequence

import pandas as pd
from Bio.SeqRecord import SeqRecord  # type: ignore[reportMissingImports]
from Bio.SeqFeature import SeqFeature  # type: ignore[reportMissingImports]
from pandas import DataFrame  # type: ignore[reportMissingImports]

from gbdraw.analysis.ortholog_paths import OrthologPath, OrthologPathCollection, ortholog_edge_id
from gbdraw.core.record_metadata import (
    _absolute_display_interval,
    _read_coord_map as _read_record_coord_map,
    _source_feature_index,
    _source_feature_location_parts,
)
from gbdraw.exceptions import ParseError, ValidationError
from gbdraw.features.ids import compute_feature_hash_from_location_parts
from gbdraw.features.visibility import should_include_feature_in_analysis
from gbdraw.io.comparisons import COMPARISON_COLUMNS

# Historical internal import; edge identity is owned by ortholog_paths.
_edge_id = ortholog_edge_id

logger = logging.getLogger(__name__)

_DEFAULT_LOSATP_BIN = "losat"
_BUNDLED_LOSATP_DIR = "bin"
PROTEIN_IDENTITY_MANIFEST_SCHEMA = 2
PROTEIN_LOSAT_CACHE_SCHEMA = 4
LEGACY_PROTEIN_LOSAT_CACHE_SCHEMA = 2
LEGACY_PROTEIN_RAW_CANDIDATE_SCHEMA = 1
# Backwards-compatible import name. Protein raw-cache writers now emit schema 4.
LOSAT_CACHE_SCHEMA = PROTEIN_LOSAT_CACHE_SCHEMA

_VALID_PROTEIN_RE = re.compile(r"^[A-Z]+$")
_VALID_FASTA_ID_RE = re.compile(r"^\S+$")
_VALID_RUNTIME_HANDLE_RE = re.compile(r"^h_[a-z2-7]{26}$")
_RUNTIME_HANDLE_SEARCH_RE = re.compile(r"(?<![a-z2-7_])h_[a-z2-7]{26}(?![a-z2-7])")
_MANIFEST_PRESENTATION_IDENTITY_FRAGMENTS = frozenset(
    {
        "viewfeaturesvgid",
        "viewfeaturehashparts",
        "renderedfeaturesvgid",
        "renderedsvgid",
    }
)
_NUMERIC_COMPARISON_COLUMNS = COMPARISON_COLUMNS[2:]
_INTEGER_COMPARISON_COLUMNS = frozenset(
    {
        "alignment_length",
        "mismatches",
        "gap_opens",
        "qstart",
        "qend",
        "sstart",
        "send",
    }
)
_STRICT_DECIMAL_INTEGER_RE = re.compile(r"^[+-]?[0-9]+$")
_STRICT_DECIMAL_NUMBER_RE = re.compile(
    r"^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$"
)
LOSATP_METADATA_COLUMNS = (
    "query_protein_id",
    "subject_protein_id",
    "query_source_protein_id",
    "subject_source_protein_id",
    "query_record_index",
    "subject_record_index",
    "query_feature_index",
    "subject_feature_index",
    "query_feature_svg_id",
    "subject_feature_svg_id",
    "query_view_feature_svg_id",
    "subject_view_feature_svg_id",
    "orthogroup_id",
    "rbh_orthogroup_id",
    "ortholog_path_id",
    "edge_kind",
    "render_role",
    "query_orthogroup_representative",
    "subject_orthogroup_representative",
    "query_orthogroup_member_count",
    "subject_orthogroup_member_count",
    "query_orthogroup_role",
    "subject_orthogroup_role",
    "query_orthogroup_confidence",
    "subject_orthogroup_confidence",
    "query_orthogroup_assignment_reason",
    "subject_orthogroup_assignment_reason",
)
LOSATP_COMPARISON_COLUMNS = tuple(COMPARISON_COLUMNS) + LOSATP_METADATA_COLUMNS
PROTEIN_BLASTP_MODES = ("none", "pairwise", "orthogroup", "collinear")
ProteinBlastpMode = Literal["none", "pairwise", "orthogroup", "collinear"]
ORTHOGROUP_INFERENCE_VERSION = "anchor_core_v1"
ORTHOGROUP_MEMBERSHIP_MODES = (ORTHOGROUP_INFERENCE_VERSION,)
_LEGACY_ORTHOGROUP_MEMBERSHIP_MODES = ("rbh", "family_merge", "distribution_split")
OrthogroupMembershipMode = Literal["anchor_core_v1"]
OrthogroupScope = Literal["cross_record", "record_local"]
OrthogroupMemberRole = Literal["anchor", "coortholog", "inparalog", "low_confidence", "local_paralog"]
OrthogroupMemberConfidence = Literal["high", "medium", "low"]
OrthologEdgeKind = Literal[
    "rbh",
    "coortholog",
    "same_record_inparalog",
    "record_local_paralog",
    "related_homolog",
    "ambiguous_paralog",
    "weak_bridge",
    "domain_only",
    "related_paralog",
]
OrthologRenderRole = Literal["block_anchor", "display_edge"]
ORTHOLOG_DISPLAY_EDGE_KIND_RANK = {
    "rbh": 0,
    "coortholog": 1,
    "same_record_inparalog": 2,
    "record_local_paralog": 3,
    "related_homolog": 4,
    "ambiguous_paralog": 5,
    "weak_bridge": 6,
    "domain_only": 7,
    "related_paralog": 8,
}
_NEAR_RECIPROCAL_MIN_RATIO = 0.85
_INPARALOG_MIN_SAME_RECORD_RATIO_TO_LOCAL_ANCHOR = 0.75
_MIN_BEST_SECOND_CORE_RATIO = 1.25
_MIN_MEMBERSHIP_MIN_COVERAGE = 0.30
_DOMAIN_ONLY_MAX_MIN_COVERAGE = 0.25
_LOW_CONFIDENCE_MIN_BEST_SECOND_CORE_RATIO = 1.10
_ORTHOGROUP_SPLIT_TOP_FRACTION = 0.05
_ORTHOGROUP_SPLIT_MIN_COVERAGE = 0.30
_ORTHOGROUP_SPLIT_MIN_FIT_HITS = 12
_ORTHOGROUP_SPLIT_EPSILON = 1e-12
_RECORD_LOCAL_NEAR_RECIPROCAL_MIN_RATIO = 0.85
_RECORD_LOCAL_MIN_MEMBERS = 2
_RECORD_LOCAL_MIN_MEMBERSHIP_MIN_COVERAGE = _MIN_MEMBERSHIP_MIN_COVERAGE
_RECORD_LOCAL_CORE_COMPETITION_RATIO = 1.10


@dataclass(frozen=True)
class CdsProtein:
    """A protein sequence and its genomic CDS coordinates."""

    protein_id: str
    record_index: int
    feature_index: int
    record_id: str
    start: int
    end: int
    strand: int | None
    label: str
    protein_length: int
    sequence: str
    source_protein_id: str | None = None
    feature_svg_id: str | None = None
    gene: str | None = None
    product: str | None = None
    note: str | None = None
    locus_tag: str | None = None
    gene_id: str | None = None
    old_locus_tag: str | None = None
    db_xref: tuple[str, ...] = ()
    gff_id: str | None = None
    parent_ids: tuple[str, ...] = ()
    gene_parent_id: str | None = None
    feature_type: str = "CDS"
    feature_hash_start: int | None = None
    feature_hash_end: int | None = None
    feature_hash_strand: int | None = None
    feature_hash_parts: tuple[tuple[int, int, int | None], ...] = ()
    location_operator: str = ""
    source_feature_position: int | None = None
    same_location_ordinal: int | None = None
    feature_analysis_id: str | None = None
    display_alias: str | None = None
    runtime_handle: str | None = None
    aa_sha256: str | None = None
    record_instance_key: str | None = None
    record_analysis_id: str | None = None
    protein_set_hash: str | None = None
    runtime_binding_hash: str | None = None
    display_binding_hash: str | None = None
    view_feature_svg_id: str | None = None


@dataclass(frozen=True)
class ProteinIdentityManifest:
    """Schema-2 authority for protein sets, analyses, and runtime bindings."""

    protein_sets: dict[str, dict[str, object]]
    record_analyses: dict[str, dict[str, object]]
    record_instances: dict[str, dict[str, object]]
    schema: int = PROTEIN_IDENTITY_MANIFEST_SCHEMA

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "proteinSets": self.protein_sets,
            "recordAnalyses": self.record_analyses,
            "recordInstances": self.record_instances,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "ProteinIdentityManifest":
        return validate_protein_identity_manifest(value)

    def binding_for(self, record_instance_key: str) -> dict[str, object]:
        try:
            return self.record_instances[str(record_instance_key)]
        except KeyError as exc:
            raise ValidationError(
                f"Protein manifest has no record instance {record_instance_key!r}."
            ) from exc


@dataclass(frozen=True)
class ProteinLosatPairIdentity:
    """Directional raw-cache identity for one query/subject protein pair."""

    query_protein_set_hash: str
    subject_protein_set_hash: str
    query_runtime_binding_hash: str
    subject_runtime_binding_hash: str
    query_record_instance_key: str
    subject_record_instance_key: str

    def cache_payload(
        self,
        *,
        args: Sequence[str],
        program: str = "blastp",
        outfmt: str = "6",
    ) -> dict[str, object]:
        return {
            "cacheSchema": PROTEIN_LOSAT_CACHE_SCHEMA,
            "identityKind": "protein",
            "idEncoding": "runtime-handle-v1",
            "program": str(program),
            "outfmt": str(outfmt),
            "args": [str(arg) for arg in args],
            "queryProteinSetHash": self.query_protein_set_hash,
            "subjectProteinSetHash": self.subject_protein_set_hash,
            "queryRuntimeBindingHash": self.query_runtime_binding_hash,
            "subjectRuntimeBindingHash": self.subject_runtime_binding_hash,
            "queryRecordInstanceKey": self.query_record_instance_key,
            "subjectRecordInstanceKey": self.subject_record_instance_key,
        }

@dataclass(frozen=True)
class LegacyProteinRawCachePromotion:
    """A verified, copy-on-write schema-2 to schema-4 promotion."""

    candidate_index: int
    entry: dict[str, object]
    rewritten_tsv: str
    legacy_query_fasta: str
    legacy_subject_fasta: str


@dataclass(frozen=True)
class LegacyProteinRawCacheRejection:
    """Why a legacy candidate could not be promoted for the current pair."""

    candidate_index: int
    reason: str


@dataclass(frozen=True)
class LegacyProteinRawCachePromotionScan:
    """Promotion result plus pair-local rejection diagnostics."""

    promotion: LegacyProteinRawCachePromotion | None
    rejections: tuple[LegacyProteinRawCacheRejection, ...] = ()


@dataclass(frozen=True)
class ProteinExtractionResult:
    """CDS protein extraction output grouped for pairwise LOSATP runs."""

    proteins_by_record: list[list[CdsProtein]]
    protein_map: dict[str, CdsProtein]
    identity_manifest: ProteinIdentityManifest | None = None
    record_instance_keys: tuple[str, ...] = ()
    protein_set_hashes: tuple[str, ...] = ()
    record_analysis_ids: tuple[str, ...] = ()
    runtime_binding_hashes: tuple[str, ...] = ()
    display_binding_hashes: tuple[str, ...] = ()


@dataclass(frozen=True)
class OrthogroupMember:
    """A CDS/protein member assigned to an orthogroup."""

    orthogroup_id: str
    protein_id: str
    record_index: int
    feature_index: int
    record_id: str
    label: str
    start: int
    end: int
    strand: int | None
    feature_svg_id: str | None
    source_protein_id: str | None
    gene: str | None = None
    product: str | None = None
    note: str | None = None
    representative: bool = False
    role: OrthogroupMemberRole = "anchor"
    confidence: OrthogroupMemberConfidence = "high"
    assignment_reason: str = ""
    supporting_edges: tuple[str, ...] = ()
    best_core_support: float = 0.0
    second_best_core_support: float = 0.0


@dataclass(frozen=True)
class OrthologEdge:
    """Selected evidence edge describing relationships inside or near an orthogroup."""

    orthogroup_id: str
    source_rbh_orthogroup_id: str | None
    target_rbh_orthogroup_id: str | None
    query_protein_id: str
    subject_protein_id: str
    query_record_index: int
    subject_record_index: int
    edge_kind: OrthologEdgeKind
    render_role: OrthologRenderRole
    path_id: str | None
    identity: float
    evalue: float
    bitscore: float
    alignment_length: int


@dataclass(frozen=True)
class OrthogroupNameCandidate:
    """Annotation-derived display-name candidate for an orthogroup."""

    text: str
    source: str
    member_count: int
    record_coverage_count: int
    representative_count: int
    score: float


@dataclass(frozen=True)
class OrthogroupResult:
    """Connected-component orthogroups and per-protein lookup metadata."""

    orthogroups: dict[str, list[OrthogroupMember]]
    member_by_protein_id: dict[str, OrthogroupMember]
    names_by_orthogroup_id: dict[str, str] = field(default_factory=dict)
    descriptions_by_orthogroup_id: dict[str, str] = field(default_factory=dict)
    name_candidates_by_orthogroup_id: dict[str, list[OrthogroupNameCandidate]] = field(default_factory=dict)
    confidence_by_orthogroup_id: dict[str, str] = field(default_factory=dict)
    rbh_orthogroups: dict[str, tuple[str, ...]] = field(default_factory=dict)
    ortholog_edges_by_orthogroup_id: dict[str, tuple[OrthologEdge, ...]] = field(default_factory=dict)
    ortholog_paths_by_orthogroup_id: dict[str, tuple[OrthologPath, ...]] = field(default_factory=dict)
    related_edges_by_orthogroup_id: dict[str, tuple[OrthologEdge, ...]] = field(default_factory=dict)
    scope_by_orthogroup_id: dict[str, OrthogroupScope] = field(default_factory=dict)
    source_record_index_by_orthogroup_id: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class OrthogroupGraphResult:
    """Orthogroups with compact lossless path indexes (the default result)."""

    orthogroups: dict[str, list[OrthogroupMember]]
    member_by_protein_id: dict[str, OrthogroupMember]
    names_by_orthogroup_id: dict[str, str] = field(default_factory=dict)
    descriptions_by_orthogroup_id: dict[str, str] = field(default_factory=dict)
    name_candidates_by_orthogroup_id: dict[str, list[OrthogroupNameCandidate]] = field(default_factory=dict)
    confidence_by_orthogroup_id: dict[str, str] = field(default_factory=dict)
    rbh_orthogroups: dict[str, tuple[str, ...]] = field(default_factory=dict)
    ortholog_edges_by_orthogroup_id: dict[str, tuple[OrthologEdge, ...]] = field(default_factory=dict)
    path_indexes_by_orthogroup_id: dict[str, OrthologPathCollection] = field(default_factory=dict)
    related_edges_by_orthogroup_id: dict[str, tuple[OrthologEdge, ...]] = field(default_factory=dict)
    scope_by_orthogroup_id: dict[str, OrthogroupScope] = field(default_factory=dict)
    source_record_index_by_orthogroup_id: dict[str, int] = field(default_factory=dict)

    def __post_init__(self):
        for group_id, index in self.path_indexes_by_orthogroup_id.items():
            if not isinstance(index, OrthologPathCollection) or group_id != index.orthogroup_id:
                raise ValidationError("Orthogroup path index has an inconsistent group ID")
            index.validate_edges(self.ortholog_edges_by_orthogroup_id.get(group_id, ()))


def _orthogroup_metadata_fields(result):
    return {name: getattr(result, name) for name in OrthogroupResult.__dataclass_fields__
            if name != "ortholog_paths_by_orthogroup_id"}


def compact_ortholog_paths(result: OrthogroupResult | OrthogroupGraphResult) -> OrthogroupGraphResult:
    """Adapt a legacy corpus once, without reconstructing its edge closure."""
    if isinstance(result, OrthogroupGraphResult):
        return result
    return OrthogroupGraphResult(
        **_orthogroup_metadata_fields(result),
        path_indexes_by_orthogroup_id={
            group_id: OrthologPathCollection(group_id, "explicit", paths=paths)
            for group_id, paths in result.ortholog_paths_by_orthogroup_id.items()
        },
    )


def materialize_ortholog_paths(result: OrthogroupResult | OrthogroupGraphResult) -> OrthogroupResult:
    """Explicit exhaustive legacy output; time and memory grow with all paths."""
    if isinstance(result, OrthogroupResult):
        return result
    return OrthogroupResult(
        **_orthogroup_metadata_fields(result),
        ortholog_paths_by_orthogroup_id={
            group_id: tuple(index.iter_paths())
            for group_id, index in result.path_indexes_by_orthogroup_id.items()
        },
    )


@dataclass(frozen=True)
class ProteinBlastpResult:
    """LOSATP blastp display comparisons plus optional orthogroup metadata."""

    comparisons: list[DataFrame]
    orthogroups: OrthogroupResult | OrthogroupGraphResult | None = None


@dataclass(frozen=True)
class ProteinBlastpRuntime:
    """Resolved executable for protein blastp searches."""

    kind: Literal["losat", "ncbi-blastp"]
    executable: str
    source: Literal["explicit", "bundled", "path"]


@dataclass(frozen=True)
class OrthogroupEdgeSelectionResult:
    """Orthogroup selection plus separate adjacent anchor and display edges."""

    orthogroups: OrthogroupResult | OrthogroupGraphResult
    all_edges_by_pair: dict[tuple[int, int], DataFrame]
    adjacent_anchor_edges_by_pair: dict[tuple[int, int], DataFrame]
    adjacent_display_edges_by_pair: dict[tuple[int, int], DataFrame]


@dataclass(frozen=True)
class _LocalThreshold:
    protein_id: str
    score: float
    source: str
    rbnh_count: int
    accepted_edge_count: int


@dataclass(frozen=True)
class _AnchorCoreEvidenceEdge:
    query_id: str
    subject_id: str
    row: object
    score: float
    reverse_score: float
    edge_kind: Literal["rbh", "coortholog", "record_local_paralog"]


@dataclass(frozen=True)
class _CoreSupportCandidate:
    group_id: str
    support: float
    diagnostic_score: float
    same_record_score: float
    cross_record_score: float
    evidence_row: object
    evidence_query_id: str
    evidence_subject_id: str
    relation_kind: OrthologEdgeKind
    min_coverage: float
    domain_only: bool
    high_confidence_pass: bool
    low_confidence_pass: bool
    reason: str


@dataclass(frozen=True)
class _BestCoreEvidence:
    support_score: float
    support_row: object | None
    support_query_id: str
    support_subject_id: str
    diagnostic_score: float
    diagnostic_row: object | None
    diagnostic_query_id: str
    diagnostic_subject_id: str


@dataclass(frozen=True)
class _CdsProteinCandidate:
    protein_id: str
    source_protein_id: str | None
    record_index: int
    feature_index: int
    record_id: str
    start: int
    end: int
    strand: int | None
    label: str
    protein_length: int
    sequence: str
    feature_svg_id: str | None
    view_feature_svg_id: str | None
    gene: str | None
    product: str | None
    note: str | None
    locus_tag: str | None
    gene_id: str | None
    old_locus_tag: str | None
    db_xref: tuple[str, ...]
    gff_id: str | None
    parent_ids: tuple[str, ...]
    gene_parent_id: str | None
    feature_type: str
    feature_hash_start: int | None
    feature_hash_end: int | None
    feature_hash_strand: int | None
    feature_hash_parts: tuple[tuple[int, int, int | None], ...]
    location_operator: str
    source_feature_position: int


LosatpRunner = Callable[[str, str], DataFrame]


def _hash_text_sha256(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _web_json_dumps(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def canonical_protein_identity_json(value: object) -> str:
    """Serialize a protein identity value using the normative JSON contract."""

    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"Protein identity value is not canonical JSON: {exc}") from exc


def _identity_sha256(value: object) -> str:
    digest = hashlib.sha256(canonical_protein_identity_json(value).encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


def _normalize_identity_text(value: object) -> str:
    return unicodedata.normalize("NFC", str(value or ""))


def _canonical_identity_context_value(value: object) -> object:
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return _normalize_identity_text(value)
    if isinstance(value, Mapping):
        return {
            _normalize_identity_text(key): _canonical_identity_context_value(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_canonical_identity_context_value(item) for item in value]
    raise ValidationError(
        f"Protein record analysis context contains unsupported {type(value).__name__}."
    )


def percent_encode_losat_transport_field(value: object) -> str:
    """Encode one transport field with NFC/UTF-8 and the fixed safe alphabet."""

    safe = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-"
    safe_bytes = set(safe)
    encoded: list[str] = []
    for byte in _normalize_identity_text(value).encode("utf-8"):
        encoded.append(chr(byte) if byte in safe_bytes else f"%{byte:02X}")
    return "".join(encoded)


def build_protein_runtime_handle(
    *,
    feature_analysis_id: str,
    record_instance_key: object,
) -> str:
    """Build the deterministic session-global runtime handle for one CDS."""

    feature_id = str(feature_analysis_id)
    instance_key = _normalize_identity_text(record_instance_key).strip()
    if not re.fullmatch(r"f_[0-9a-f]{64}", feature_id):
        raise ValidationError(
            "feature_analysis_id must be f_ followed by 64 lowercase hex digits."
        )
    if not instance_key:
        raise ValidationError("record_instance_key must be non-empty.")
    payload = canonical_protein_identity_json(
        {
            "featureAnalysisId": feature_id,
            "recordInstanceKey": instance_key,
        }
    ).encode("utf-8")
    digest = hashlib.sha256(b"gbdraw-runtime-handle-v1\0" + payload).digest()[:16]
    token = base64.b32encode(digest).decode("ascii").lower().rstrip("=")
    handle = f"h_{token}"
    if not _VALID_RUNTIME_HANDLE_RE.fullmatch(handle):  # pragma: no cover
        raise ValidationError("Generated protein runtime handle is invalid.")
    return handle


def canonical_feature_analysis_id(
    *,
    feature_type: str,
    location_operator: str | None,
    location_parts: Sequence[Sequence[int | None]],
    strand: int | None,
    same_location_ordinal: int,
) -> str:
    """Return the canonical, qualifier-independent ID for one CDS feature."""

    ordinal = int(same_location_ordinal)
    if ordinal <= 0:
        raise ValidationError("same_location_ordinal must be a positive integer.")
    normalized_parts: list[list[int | None]] = []
    for raw_part in location_parts:
        if len(raw_part) != 3:
            raise ValidationError("Each location part must contain start, end, and strand.")
        start = int(raw_part[0])  # type: ignore[arg-type]
        end = int(raw_part[1])  # type: ignore[arg-type]
        part_strand = int(raw_part[2]) if raw_part[2] in {-1, 1} else None
        if start < 0 or end <= start:
            raise ValidationError("Feature identity location parts must be 0-based, end-exclusive intervals.")
        normalized_parts.append([start, end, part_strand])
    if not normalized_parts:
        raise ValidationError("Feature identity requires at least one location part.")
    normalized_strand = int(strand) if strand in {-1, 1} else None
    payload = {
        "featureType": _normalize_identity_text(feature_type),
        "locationOperator": _normalize_identity_text(location_operator),
        "locationParts": normalized_parts,
        "sameLocationOrdinal": ordinal,
        "strand": normalized_strand,
    }
    digest = hashlib.sha256(canonical_protein_identity_json(payload).encode("utf-8")).hexdigest()
    return f"f_{digest}"


def _strand_display(value: int | None) -> str:
    if value == 1:
        return "+"
    if value == -1:
        return "-"
    return "0"


def select_protein_display_alias(protein: CdsProtein) -> str:
    """Choose the readable alias without using it as machine identity."""

    for value in (protein.source_protein_id, protein.locus_tag, protein.gff_id):
        normalized = _normalize_identity_text(value).strip()
        if normalized:
            return normalized
    parts = protein.feature_hash_parts or (
        (protein.start, protein.end, protein.strand),
    )
    location = ",".join(f"{int(start)}-{int(end)}" for start, end, _ in parts)
    operator = _normalize_identity_text(protein.location_operator).strip()
    if operator and len(parts) > 1:
        location = f"{operator}({location})"
    return f"CDS:{location}:{_strand_display(protein.feature_hash_strand)}"


def _validate_protein_sets_and_record_analyses(
    raw_sets: Mapping[object, object],
    raw_analyses: Mapping[object, object],
) -> tuple[dict[str, dict[str, object]], dict[str, dict[str, object]]]:
    """Validate manifest authorities shared independently of top-level schema."""

    protein_sets: dict[str, dict[str, object]] = {}
    for key, raw_set in raw_sets.items():
        set_key = str(key)
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", set_key) or not isinstance(raw_set, Mapping):
            raise ValidationError("Protein set keys must be sha256 digests.")
        raw_proteins = raw_set.get("proteins")
        if raw_set.get("schema") != 1 or not isinstance(raw_proteins, list):
            raise ValidationError(f"Protein set {set_key!r} is invalid.")
        identity_pairs: list[dict[str, str]] = []
        feature_ids: set[str] = set()
        for protein in raw_proteins:
            if not isinstance(protein, Mapping):
                raise ValidationError(f"Protein set {set_key!r} contains an invalid protein.")
            feature_id = str(protein.get("featureAnalysisId") or "")
            aa_sha256 = str(protein.get("aaSha256") or "")
            if not re.fullmatch(r"f_[0-9a-f]{64}", feature_id):
                raise ValidationError(f"Protein set {set_key!r} contains an invalid feature ID.")
            if not re.fullmatch(r"[0-9a-f]{64}", aa_sha256) or feature_id in feature_ids:
                raise ValidationError(f"Protein set {set_key!r} has invalid or duplicate protein identity.")
            try:
                expected_feature_id = canonical_feature_analysis_id(
                    feature_type=str(protein.get("featureType") or ""),
                    location_operator=str(protein.get("locationOperator") or ""),
                    location_parts=protein.get("locationParts") or (),  # type: ignore[arg-type]
                    strand=protein.get("strand"),  # type: ignore[arg-type]
                    same_location_ordinal=int(protein.get("sameLocationOrdinal") or 0),
                )
            except (TypeError, ValueError) as exc:
                raise ValidationError(f"Protein set {set_key!r} contains invalid feature identity fields.") from exc
            if expected_feature_id != feature_id:
                raise ValidationError(f"Protein set {set_key!r} feature ID does not match its content.")
            feature_ids.add(feature_id)
            identity_pairs.append({"featureAnalysisId": feature_id, "aaSha256": aa_sha256})
        identity_pairs.sort(key=lambda protein: protein["featureAnalysisId"])
        if [
            str(protein.get("featureAnalysisId"))
            for protein in raw_proteins
        ] != [protein["featureAnalysisId"] for protein in identity_pairs]:
            raise ValidationError(f"Protein set {set_key!r} is not in canonical feature order.")
        if _identity_sha256({"proteins": identity_pairs}) != set_key:
            raise ValidationError(f"Protein set {set_key!r} hash does not match its content.")
        protein_sets[set_key] = dict(raw_set)

    record_analyses: dict[str, dict[str, object]] = {}
    for key, raw_analysis in raw_analyses.items():
        analysis_key = str(key)
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", analysis_key) or not isinstance(raw_analysis, Mapping):
            raise ValidationError("Record analysis keys must be sha256 digests.")
        protein_set_hash = str(raw_analysis.get("proteinSetHash") or "")
        record_source_id = raw_analysis.get("recordSourceId")
        if (
            raw_analysis.get("schema") != 1
            or protein_set_hash not in protein_sets
            or not isinstance(record_source_id, str)
            or not record_source_id
        ):
            raise ValidationError(f"Record analysis {analysis_key!r} has an invalid protein set reference.")
        analysis_hash_payload = {
            "proteinSetHash": protein_set_hash,
            "recordSourceId": raw_analysis.get("recordSourceId"),
            "region": raw_analysis.get("region"),
            "selector": raw_analysis.get("selector"),
        }
        if _identity_sha256(analysis_hash_payload) != analysis_key:
            raise ValidationError(f"Record analysis {analysis_key!r} hash does not match its content.")
        record_analyses[analysis_key] = dict(raw_analysis)

    return protein_sets, record_analyses


def _runtime_binding_payload(
    *,
    protein_set_hash: str,
    record_instance_key: str,
    runtime_ids: Mapping[str, str],
) -> dict[str, object]:
    return {
        "encoding": "runtime-handle-v1",
        "proteinSetHash": str(protein_set_hash),
        "recordInstanceKey": str(record_instance_key),
        "runtimeIds": dict(runtime_ids),
    }


def _display_binding_payload(
    *,
    record_analysis_id: str,
    record_source_id: str,
    record_instance_key: str,
    feature_metadata: Mapping[str, object],
) -> dict[str, object]:
    return {
        "recordAnalysisId": str(record_analysis_id),
        "recordSourceId": str(record_source_id),
        "recordInstanceKey": str(record_instance_key),
        "featureMetadata": dict(feature_metadata),
    }


def _expected_export_ordinals(
    feature_metadata: Mapping[str, Mapping[str, object]],
) -> dict[str, int | None]:
    feature_ids_by_alias: dict[str, list[str]] = {}
    for feature_id, metadata in feature_metadata.items():
        alias = _normalize_identity_text(metadata.get("displayAlias")).strip()
        if not alias:
            raise ValidationError("Protein feature metadata requires a display alias.")
        feature_ids_by_alias.setdefault(alias, []).append(str(feature_id))
    expected: dict[str, int | None] = {}
    for feature_ids in feature_ids_by_alias.values():
        ordered = sorted(feature_ids)
        for ordinal, feature_id in enumerate(ordered, start=1):
            expected[feature_id] = ordinal if len(ordered) > 1 else None
    return expected


def _reject_manifest_presentation_identity(value: Mapping[str, object]) -> None:
    """Keep protein identity manifests independent of rendered view coordinates."""

    pending: list[object] = [value]
    visited: set[int] = set()
    while pending:
        current = pending.pop()
        if isinstance(current, Mapping):
            object_id = id(current)
            if object_id in visited:
                continue
            visited.add(object_id)
            for raw_key, item in current.items():
                normalized_key = re.sub(
                    r"[^a-z0-9]+",
                    "",
                    unicodedata.normalize("NFKC", str(raw_key)).casefold(),
                )
                if any(
                    fragment in normalized_key
                    for fragment in _MANIFEST_PRESENTATION_IDENTITY_FRAGMENTS
                ):
                    raise ValidationError(
                        "Protein identity manifests cannot contain rendered-view identity fields."
                    )
                pending.append(item)
        elif isinstance(current, (list, tuple)):
            pending.extend(current)


def validate_protein_identity_manifest(
    value: Mapping[str, object],
) -> ProteinIdentityManifest:
    """Validate and materialize a schema-2 compact protein manifest."""

    if not isinstance(value, Mapping) or value.get("schema") != PROTEIN_IDENTITY_MANIFEST_SCHEMA:
        raise ValidationError("Protein identity manifest must use schema 2.")
    _reject_manifest_presentation_identity(value)
    raw_sets = value.get("proteinSets")
    raw_analyses = value.get("recordAnalyses")
    raw_instances = value.get("recordInstances")
    if (
        not isinstance(raw_sets, Mapping)
        or not isinstance(raw_analyses, Mapping)
        or not isinstance(raw_instances, Mapping)
    ):
        raise ValidationError("Protein identity manifest maps are missing or invalid.")

    protein_sets, record_analyses = _validate_protein_sets_and_record_analyses(
        raw_sets,
        raw_analyses,
    )

    record_instances: dict[str, dict[str, object]] = {}
    all_runtime_handles: set[str] = set()
    for key, raw_binding in raw_instances.items():
        instance_key = str(key)
        if not instance_key or not isinstance(raw_binding, Mapping) or raw_binding.get("schema") != 2:
            raise ValidationError("Record instance bindings must be non-empty schema-2 objects.")
        analysis_id = str(raw_binding.get("recordAnalysisId") or "")
        runtime_binding_hash = str(raw_binding.get("runtimeBindingHash") or "")
        display_binding_hash = str(raw_binding.get("displayBindingHash") or "")
        runtime_ids = raw_binding.get("runtimeIds")
        feature_metadata = raw_binding.get("featureMetadata")
        if analysis_id not in record_analyses:
            raise ValidationError(
                f"Record instance {instance_key!r} has an invalid analysis reference."
            )
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", runtime_binding_hash):
            raise ValidationError(
                f"Record instance {instance_key!r} has an invalid runtime binding hash."
            )
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", display_binding_hash):
            raise ValidationError(
                f"Record instance {instance_key!r} has an invalid display binding hash."
            )
        if not isinstance(runtime_ids, Mapping) or not isinstance(feature_metadata, Mapping):
            raise ValidationError(
                f"Record instance {instance_key!r} has invalid runtime or metadata maps."
            )

        protein_set_hash = str(record_analyses[analysis_id]["proteinSetHash"])
        expected_feature_ids = {
            str(protein["featureAnalysisId"])
            for protein in protein_sets[protein_set_hash]["proteins"]  # type: ignore[index]
        }
        normalized_runtime_ids: dict[str, str] = {}
        for feature_id, runtime_handle in runtime_ids.items():
            feature_key = str(feature_id)
            handle = str(runtime_handle)
            if feature_key not in expected_feature_ids:
                raise ValidationError("Runtime map contains an unknown feature analysis ID.")
            if (
                not _VALID_RUNTIME_HANDLE_RE.fullmatch(handle)
                or handle
                != build_protein_runtime_handle(
                    feature_analysis_id=feature_key,
                    record_instance_key=instance_key,
                )
                or handle in all_runtime_handles
            ):
                raise ValidationError(
                    "Runtime handles must be deterministic and globally unique."
                )
            normalized_runtime_ids[feature_key] = handle
            all_runtime_handles.add(handle)
        if set(normalized_runtime_ids) != expected_feature_ids:
            raise ValidationError(
                f"Record instance {instance_key!r} runtime map does not match its protein set."
            )

        normalized_metadata: dict[str, dict[str, object]] = {}
        for feature_id, metadata in feature_metadata.items():
            feature_key = str(feature_id)
            if feature_key not in expected_feature_ids or not isinstance(metadata, Mapping):
                raise ValidationError(
                    f"Record instance {instance_key!r} contains invalid feature metadata."
                )
            normalized_metadata[feature_key] = dict(metadata)
        if set(normalized_metadata) != expected_feature_ids:
            raise ValidationError(
                f"Record instance {instance_key!r} metadata does not match its protein set."
            )
        expected_ordinals = _expected_export_ordinals(normalized_metadata)
        for feature_id, expected_ordinal in expected_ordinals.items():
            actual = normalized_metadata[feature_id].get("exportOrdinal")
            if actual != expected_ordinal:
                raise ValidationError(
                    f"Record instance {instance_key!r} has a non-canonical export ordinal."
                )

        runtime_payload = _runtime_binding_payload(
            protein_set_hash=protein_set_hash,
            record_instance_key=instance_key,
            runtime_ids=normalized_runtime_ids,
        )
        if _identity_sha256(runtime_payload) != runtime_binding_hash:
            raise ValidationError(
                f"Record instance {instance_key!r} runtime binding hash does not match."
            )
        display_payload = _display_binding_payload(
            record_analysis_id=analysis_id,
            record_source_id=str(record_analyses[analysis_id]["recordSourceId"]),
            record_instance_key=instance_key,
            feature_metadata=normalized_metadata,
        )
        if _identity_sha256(display_payload) != display_binding_hash:
            raise ValidationError(
                f"Record instance {instance_key!r} display binding hash does not match."
            )

        normalized_binding = dict(raw_binding)
        normalized_binding["runtimeIds"] = dict(sorted(normalized_runtime_ids.items()))
        normalized_binding["featureMetadata"] = dict(sorted(normalized_metadata.items()))
        record_instances[instance_key] = normalized_binding

    return ProteinIdentityManifest(
        protein_sets=protein_sets,
        record_analyses=record_analyses,
        record_instances=record_instances,
    )


def _safe_web_protein_id_token(value: object) -> str:
    """Legacy schema-2 token sanitizer used only for verified migration."""

    text = str(value or "").strip()
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", text)
    text = text.strip("._-")
    return text or "record"


def _with_stable_web_protein_ids(
    proteins: Sequence[CdsProtein],
    record_instance_key: object,
) -> list[CdsProtein]:
    """Reconstruct legacy schema-2 Web IDs for verified migration only."""

    record_key = _safe_web_protein_id_token(record_instance_key)
    remapped: list[CdsProtein] = []
    used: set[str] = set()
    for protein in proteins:
        strand = protein.strand if protein.strand in {-1, 1} else 0
        aa_hash = hashlib.sha256(str(protein.sequence or "").encode("utf-8")).hexdigest()[:12]
        base_id = f"p_{record_key}_{int(protein.start)}_{int(protein.end)}_{strand}_{aa_hash}"
        protein_id = base_id
        suffix = 2
        while protein_id in used:
            protein_id = f"{base_id}_{suffix}"
            suffix += 1
        used.add(protein_id)
        remapped.append(replace(protein, protein_id=protein_id))
    return remapped


def extract_web_stable_cds_proteins(
    records: Sequence[SeqRecord],
    *,
    record_instance_keys: Sequence[str] | None = None,
    record_source_ids: Sequence[str] | None = None,
    record_selectors: Sequence[object] | None = None,
    regions: Sequence[object] | None = None,
    record_index_offset: int = 0,
    feature_visibility_rules: list[dict[str, object]] | None = None,
) -> ProteinExtractionResult:
    """Extract CDS proteins with the current manifest and runtime handles."""

    return extract_protein_identity_manifest(
        records,
        record_instance_keys=record_instance_keys,
        record_source_ids=record_source_ids,
        record_selectors=record_selectors,
        regions=regions,
        record_index_offset=record_index_offset,
        feature_visibility_rules=feature_visibility_rules,
    )


def _per_record_values(
    values: Sequence[object] | None,
    records: Sequence[SeqRecord],
    *,
    name: str,
    default: Callable[[int, SeqRecord], object],
) -> list[object]:
    if values is not None and len(values) != len(records):
        raise ValidationError(f"{name} must have one value per record.")
    if values is None:
        return [default(index, record) for index, record in enumerate(records)]
    return list(values)


def _protein_location_identity_key(protein: CdsProtein) -> tuple[object, ...]:
    return (
        _normalize_identity_text(protein.feature_type),
        _normalize_identity_text(protein.location_operator),
        tuple(
            (int(start), int(end), int(strand) if strand in {-1, 1} else None)
            for start, end, strand in protein.feature_hash_parts
        ),
        (
            int(protein.feature_hash_strand)
            if protein.feature_hash_strand in {-1, 1}
            else None
        ),
    )


def _same_location_sort_key(protein: CdsProtein) -> tuple[object, ...]:
    aa_sha256 = hashlib.sha256(protein.sequence.encode("utf-8")).hexdigest()
    # Display qualifiers are intentionally excluded; source position only breaks
    # ties between otherwise identical same-location protein sequences.
    source_position = (
        int(protein.source_feature_position)
        if protein.source_feature_position is not None
        else int(protein.feature_index)
    )
    return aa_sha256, source_position


def _protein_identity_core(protein: CdsProtein) -> dict[str, object]:
    return {
        "featureAnalysisId": str(protein.feature_analysis_id),
        "sameLocationOrdinal": int(protein.same_location_ordinal or 0),
        "featureType": protein.feature_type,
        "locationOperator": protein.location_operator,
        "locationParts": [list(part) for part in protein.feature_hash_parts],
        "strand": protein.feature_hash_strand,
        "aaSha256": str(protein.aa_sha256),
    }


def _protein_binding_metadata(
    protein: CdsProtein,
    *,
    export_ordinal: int | None,
) -> dict[str, object]:
    return {
        "displayAlias": protein.display_alias,
        "exportOrdinal": export_ordinal,
        "sourceFeaturePosition": protein.source_feature_position,
        "sourceProteinId": protein.source_protein_id,
        "locusTag": protein.locus_tag,
        "gffId": protein.gff_id,
        "featureSvgId": protein.feature_svg_id,
        "gene": protein.gene,
        "product": protein.product,
        "note": protein.note,
        "oldLocusTag": protein.old_locus_tag,
        "geneId": protein.gene_id,
        "dbXref": list(protein.db_xref),
        "parentIds": list(protein.parent_ids),
        "geneParentId": protein.gene_parent_id,
        "start": protein.start,
        "end": protein.end,
    }


def extract_protein_identity_manifest(
    records: Sequence[SeqRecord],
    *,
    record_instance_keys: Sequence[str] | None = None,
    record_source_ids: Sequence[str] | None = None,
    record_selectors: Sequence[object] | None = None,
    regions: Sequence[object] | None = None,
    record_index_offset: int = 0,
    feature_visibility_rules: list[dict[str, object]] | None = None,
) -> ProteinExtractionResult:
    """Build the canonical protein manifest and runtime-bound extraction."""

    base = extract_cds_proteins(
        records,
        record_index_offset=record_index_offset,
        prefer_source_ids=False,
        feature_visibility_rules=feature_visibility_rules,
    )
    instance_values = _per_record_values(
        record_instance_keys,
        records,
        name="record_instance_keys",
        default=lambda index, record: (
            (getattr(record, "annotations", {}) or {}).get("gbdraw_record_key")
            or f"record-{index + 1}"
        ),
    )
    source_values = _per_record_values(
        record_source_ids,
        records,
        name="record_source_ids",
        default=lambda _index, record: record.id,
    )
    selector_values = _per_record_values(
        record_selectors,
        records,
        name="record_selectors",
        default=lambda _index, _record: None,
    )
    region_values = _per_record_values(
        regions,
        records,
        name="regions",
        default=lambda _index, _record: None,
    )
    instance_keys = [_normalize_identity_text(value).strip() for value in instance_values]
    if any(not key for key in instance_keys):
        raise ValidationError("record_instance_keys must be non-empty.")
    if len(set(instance_keys)) != len(instance_keys):
        raise ValidationError("record_instance_keys must be unique across the extraction.")

    protein_sets: dict[str, dict[str, object]] = {}
    record_analyses: dict[str, dict[str, object]] = {}
    record_instances: dict[str, dict[str, object]] = {}
    proteins_by_record: list[list[CdsProtein]] = []
    protein_map: dict[str, CdsProtein] = {}
    protein_set_hashes: list[str] = []
    record_analysis_ids: list[str] = []
    runtime_binding_hashes: list[str] = []
    display_binding_hashes: list[str] = []

    for record_index, base_proteins in enumerate(base.proteins_by_record):
        grouped: dict[tuple[object, ...], list[CdsProtein]] = {}
        for protein in base_proteins:
            grouped.setdefault(_protein_location_identity_key(protein), []).append(protein)

        identified_by_position: dict[int, CdsProtein] = {}
        for group in grouped.values():
            for ordinal, protein in enumerate(sorted(group, key=_same_location_sort_key), start=1):
                aa_sha256 = hashlib.sha256(protein.sequence.encode("utf-8")).hexdigest()
                feature_analysis_id = canonical_feature_analysis_id(
                    feature_type=protein.feature_type,
                    location_operator=protein.location_operator,
                    location_parts=protein.feature_hash_parts,
                    strand=protein.feature_hash_strand,
                    same_location_ordinal=ordinal,
                )
                display_alias = select_protein_display_alias(protein)
                identified_by_position[id(protein)] = replace(
                    protein,
                    source_feature_position=(
                        protein.source_feature_position
                        if protein.source_feature_position is not None
                        else protein.feature_index
                    ),
                    same_location_ordinal=ordinal,
                    feature_analysis_id=feature_analysis_id,
                    display_alias=display_alias,
                    aa_sha256=aa_sha256,
                )

        identified = [identified_by_position[id(protein)] for protein in base_proteins]
        sorted_core = sorted(
            (_protein_identity_core(protein) for protein in identified),
            key=lambda entry: str(entry["featureAnalysisId"]),
        )
        hash_proteins = [
            {
                "featureAnalysisId": entry["featureAnalysisId"],
                "aaSha256": entry["aaSha256"],
            }
            for entry in sorted_core
        ]
        protein_set_hash = _identity_sha256({"proteins": hash_proteins})
        protein_set = {"schema": 1, "proteins": sorted_core}
        existing_set = protein_sets.get(protein_set_hash)
        if (
            existing_set is not None
            and canonical_protein_identity_json(existing_set)
            != canonical_protein_identity_json(protein_set)
        ):
            raise ValidationError("Protein-set hash resolved to conflicting canonical content.")
        protein_sets.setdefault(protein_set_hash, protein_set)

        record_source_id = _normalize_identity_text(source_values[record_index]).strip()
        if not record_source_id:
            raise ValidationError("record_source_ids must be non-empty.")
        selector = _canonical_identity_context_value(selector_values[record_index])
        region = _canonical_identity_context_value(region_values[record_index])
        analysis_hash_payload = {
            "proteinSetHash": protein_set_hash,
            "recordSourceId": record_source_id,
            "region": region,
            "selector": selector,
        }
        record_analysis_id = _identity_sha256(analysis_hash_payload)
        record_analysis = {
            "schema": 1,
            "recordSourceId": record_source_id,
            "selector": selector,
            "region": region,
            "proteinSetHash": protein_set_hash,
        }
        existing_analysis = record_analyses.get(record_analysis_id)
        if (
            existing_analysis is not None
            and canonical_protein_identity_json(existing_analysis)
            != canonical_protein_identity_json(record_analysis)
        ):
            raise ValidationError("Record-analysis hash resolved to conflicting canonical content.")
        record_analyses.setdefault(record_analysis_id, record_analysis)

        instance_key = instance_keys[record_index]
        runtime_ids: dict[str, str] = {}
        for protein in sorted(
            identified,
            key=lambda item: str(item.feature_analysis_id),
        ):
            feature_id = str(protein.feature_analysis_id)
            runtime_ids[feature_id] = build_protein_runtime_handle(
                feature_analysis_id=feature_id,
                record_instance_key=instance_key,
            )

        feature_ids_by_alias: dict[str, list[str]] = {}
        for protein in identified:
            feature_ids_by_alias.setdefault(
                _normalize_identity_text(protein.display_alias).strip(),
                [],
            ).append(str(protein.feature_analysis_id))
        export_ordinals: dict[str, int | None] = {}
        for feature_ids in feature_ids_by_alias.values():
            ordered_feature_ids = sorted(feature_ids)
            for ordinal, feature_id in enumerate(ordered_feature_ids, start=1):
                export_ordinals[feature_id] = (
                    ordinal if len(ordered_feature_ids) > 1 else None
                )

        feature_metadata = {
            str(protein.feature_analysis_id): _protein_binding_metadata(
                protein,
                export_ordinal=export_ordinals[str(protein.feature_analysis_id)],
            )
            for protein in identified
        }
        feature_metadata = dict(sorted(feature_metadata.items()))
        runtime_binding_hash = _identity_sha256(
            _runtime_binding_payload(
                protein_set_hash=protein_set_hash,
                record_instance_key=instance_key,
                runtime_ids=runtime_ids,
            )
        )
        display_binding_hash = _identity_sha256(
            _display_binding_payload(
                record_analysis_id=record_analysis_id,
                record_source_id=record_source_id,
                record_instance_key=instance_key,
                feature_metadata=feature_metadata,
            )
        )

        bound: list[CdsProtein] = []
        for protein in identified:
            feature_id = str(protein.feature_analysis_id)
            runtime_handle = runtime_ids[feature_id]
            bound_protein = replace(
                protein,
                protein_id=runtime_handle,
                runtime_handle=runtime_handle,
                record_instance_key=instance_key,
                record_analysis_id=record_analysis_id,
                protein_set_hash=protein_set_hash,
                runtime_binding_hash=runtime_binding_hash,
                display_binding_hash=display_binding_hash,
            )
            if runtime_handle in protein_map:
                raise ValidationError(
                    f"Duplicate protein runtime handle {runtime_handle!r}."
                )
            bound.append(bound_protein)
            protein_map[runtime_handle] = bound_protein

        binding = {
            "schema": 2,
            "recordAnalysisId": record_analysis_id,
            "runtimeBindingHash": runtime_binding_hash,
            "displayBindingHash": display_binding_hash,
            "runtimeIds": runtime_ids,
            "featureMetadata": feature_metadata,
        }
        record_instances[instance_key] = binding
        proteins_by_record.append(bound)
        protein_set_hashes.append(protein_set_hash)
        record_analysis_ids.append(record_analysis_id)
        runtime_binding_hashes.append(runtime_binding_hash)
        display_binding_hashes.append(display_binding_hash)

    manifest = validate_protein_identity_manifest(
        {
            "schema": PROTEIN_IDENTITY_MANIFEST_SCHEMA,
            "proteinSets": protein_sets,
            "recordAnalyses": record_analyses,
            "recordInstances": record_instances,
        }
    )
    return ProteinExtractionResult(
        proteins_by_record=proteins_by_record,
        protein_map=protein_map,
        identity_manifest=manifest,
        record_instance_keys=tuple(instance_keys),
        protein_set_hashes=tuple(protein_set_hashes),
        record_analysis_ids=tuple(record_analysis_ids),
        runtime_binding_hashes=tuple(runtime_binding_hashes),
        display_binding_hashes=tuple(display_binding_hashes),
    )


def build_web_losat_cache_key(
    *,
    query_fasta: str,
    subject_fasta: str,
    args: Sequence[str],
    program: str = "blastp",
    outfmt: str = "6",
    runtime_compatibility: str = "threaded-compatible-v1",
    threads_per_job: str | int = "auto",
) -> tuple[str, str, str]:
    """Rebuild a legacy schema-2 full-FASTA cache key for verification.

    Thread/runtime options are intentionally excluded: they control execution
    resources, not the raw LOSAT result identity.
    """

    query_hash = _hash_text_sha256(query_fasta)
    subject_hash = _hash_text_sha256(subject_fasta)
    payload = {
        "cacheSchema": LEGACY_PROTEIN_LOSAT_CACHE_SCHEMA,
        "program": program,
        "outfmt": str(outfmt),
        "args": [str(arg) for arg in args],
        "queryCanonicalHash": query_hash,
        "subjectCanonicalHash": subject_hash,
    }
    return _hash_text_sha256(_web_json_dumps(payload)), query_hash, subject_hash


def build_protein_losat_pair_identity(
    manifest: ProteinIdentityManifest | Mapping[str, object],
    *,
    query_record_instance_key: str,
    subject_record_instance_key: str,
) -> ProteinLosatPairIdentity:
    """Resolve one directional pair from a validated identity manifest."""

    authority = (
        manifest
        if isinstance(manifest, ProteinIdentityManifest)
        else validate_protein_identity_manifest(manifest)
    )

    def resolve(instance_key: str) -> tuple[str, str]:
        binding = authority.binding_for(instance_key)
        analysis_id = str(binding["recordAnalysisId"])
        analysis = authority.record_analyses[analysis_id]
        return str(analysis["proteinSetHash"]), str(binding["runtimeBindingHash"])

    query_set_hash, query_runtime_binding_hash = resolve(
        str(query_record_instance_key)
    )
    subject_set_hash, subject_runtime_binding_hash = resolve(
        str(subject_record_instance_key)
    )
    return ProteinLosatPairIdentity(
        query_protein_set_hash=query_set_hash,
        subject_protein_set_hash=subject_set_hash,
        query_runtime_binding_hash=query_runtime_binding_hash,
        subject_runtime_binding_hash=subject_runtime_binding_hash,
        query_record_instance_key=str(query_record_instance_key),
        subject_record_instance_key=str(subject_record_instance_key),
    )


def build_protein_losat_cache_key(
    pair_identity: ProteinLosatPairIdentity,
    *,
    args: Sequence[str],
    program: str = "blastp",
    outfmt: str = "6",
    search_context: str | None = None,
) -> str:
    """Return the Web-compatible directional schema-4 protein raw key."""

    payload = pair_identity.cache_payload(args=args, program=program, outfmt=outfmt)
    if search_context is not None:
        if not re.fullmatch(r"[0-9a-f]{64}", search_context):
            raise ValidationError("LOSAT search context must be a SHA-256 digest")
        payload["searchContext"] = search_context
    return _hash_text_sha256(_web_json_dumps(payload))


def parse_losat_fasta_ids(fasta_text: str) -> tuple[str, ...]:
    """Return FASTA identifier tokens and reject malformed/duplicate headers."""

    ids: list[str] = []
    seen: set[str] = set()
    for line_number, raw_line in enumerate(str(fasta_text).splitlines(), start=1):
        if not raw_line.startswith(">"):
            continue
        token = raw_line[1:].strip().split(maxsplit=1)[0] if raw_line[1:].strip() else ""
        if not token or not _VALID_FASTA_ID_RE.fullmatch(token):
            raise ValidationError(f"Invalid FASTA identifier on line {line_number}.")
        if token in seen:
            raise ValidationError(f"Duplicate FASTA identifier {token!r}.")
        seen.add(token)
        ids.append(token)
    if not ids and str(fasta_text).strip():
        raise ValidationError("Protein FASTA contains no identifier headers.")
    return tuple(ids)


def _parse_losat_fasta_sequences(fasta_text: str) -> dict[str, str]:
    ids = parse_losat_fasta_ids(fasta_text)
    if not ids:
        raise ValidationError("Protein FASTA contains no sequences.")
    sequences: dict[str, list[str]] = {protein_id: [] for protein_id in ids}
    current_id: str | None = None
    for line_number, raw_line in enumerate(str(fasta_text).splitlines(), start=1):
        if raw_line.startswith(">"):
            current_id = raw_line[1:].strip().split(maxsplit=1)[0]
            continue
        sequence_part = "".join(raw_line.split()).upper()
        if not sequence_part:
            continue
        if current_id is None:
            raise ValidationError(
                f"Protein FASTA sequence appears before its header on line {line_number}."
            )
        sequences[current_id].append(sequence_part)
    normalized = {
        protein_id: "".join(parts)
        for protein_id, parts in sequences.items()
    }
    if any(not sequence or not _VALID_PROTEIN_RE.fullmatch(sequence) for sequence in normalized.values()):
        raise ValidationError("Protein FASTA contains an empty or invalid amino-acid sequence.")
    return normalized


def _binding_runtime_ids(
    manifest: ProteinIdentityManifest,
    record_instance_key: str,
) -> set[str]:
    binding = manifest.binding_for(record_instance_key)
    runtime_ids = binding.get("runtimeIds")
    if not isinstance(runtime_ids, Mapping):
        raise ValidationError("Protein record binding has no runtime handles.")
    return {str(value) for value in runtime_ids.values()}


def _fasta_record_instance_key(
    fasta_text: str,
    manifest: ProteinIdentityManifest,
) -> str:
    fasta_sequences = _parse_losat_fasta_sequences(fasta_text)
    fasta_ids = set(fasta_sequences)
    matches: list[str] = []
    for instance_key, binding in manifest.record_instances.items():
        if fasta_ids != _binding_runtime_ids(manifest, instance_key):
            continue
        analysis = manifest.record_analyses[str(binding["recordAnalysisId"])]
        protein_set = manifest.protein_sets[str(analysis["proteinSetHash"])]
        aa_by_feature_id = {
            str(protein["featureAnalysisId"]): str(protein["aaSha256"])
            for protein in protein_set["proteins"]  # type: ignore[index]
        }
        runtime_ids = binding["runtimeIds"]
        if not isinstance(runtime_ids, Mapping):
            continue
        if all(
            hashlib.sha256(fasta_sequences[str(runtime_handle)].encode("utf-8")).hexdigest()
            == aa_by_feature_id[str(feature_id)]
            for feature_id, runtime_handle in runtime_ids.items()
        ):
            matches.append(instance_key)
    if len(matches) != 1:
        raise ValidationError(
            "Protein FASTA IDs and sequences must match exactly one complete record-instance binding."
        )
    return matches[0]


def raw_protein_tsv_matches_bindings(
    text: str,
    *,
    query_ids: set[str],
    subject_ids: set[str],
) -> bool:
    """Return whether every non-comment TSV row belongs to the directional pair."""

    for raw_line in str(text).splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        columns = raw_line.split("\t")
        if (
            len(columns) != len(COMPARISON_COLUMNS)
            or columns[0] not in query_ids
            or columns[1] not in subject_ids
        ):
            return False
    try:
        parse_losatp_outfmt6(str(text))
    except ParseError:
        return False
    return True


def is_protein_losat_cache_entry(entry: Mapping[str, object] | object) -> bool:
    """Discriminate a current schema-4 protein raw entry."""

    if not isinstance(entry, Mapping):
        return False
    required_text = (
        "key",
        "queryProteinSetHash",
        "subjectProteinSetHash",
        "queryRuntimeBindingHash",
        "subjectRuntimeBindingHash",
        "queryRecordInstanceKey",
        "subjectRecordInstanceKey",
    )
    return (
        entry.get("schema") == PROTEIN_LOSAT_CACHE_SCHEMA
        and entry.get("kind") == "raw-losat"
        and entry.get("identityKind") == "protein"
        and entry.get("idEncoding") == "runtime-handle-v1"
        and str(entry.get("program") or "").lower() == "blastp"
        and isinstance(entry.get("text"), str)
        and all(isinstance(entry.get(key), str) and bool(entry.get(key)) for key in required_text)
    )


def is_legacy_protein_losat_cache_entry(entry: Mapping[str, object] | object) -> bool:
    """Discriminate an imported schema-2 blastp candidate."""

    return (
        isinstance(entry, Mapping)
        and entry.get("schema") == LEGACY_PROTEIN_LOSAT_CACHE_SCHEMA
        and entry.get("kind") == "raw-losat"
        and isinstance(entry.get("text"), str)
        and str(entry.get("program") or "blastp").lower() == "blastp"
        and str(entry.get("flow") or "").lower() not in {"blastn", "tblastx", "nucleotide"}
    )


def validate_protein_raw_entry_references(
    entry: Mapping[str, object] | object,
    manifest: ProteinIdentityManifest | Mapping[str, object],
) -> bool:
    """Validate a schema-4 key, manifest references, and directional TSV IDs."""

    if not is_protein_losat_cache_entry(entry):
        return False
    try:
        authority = (
            manifest
            if isinstance(manifest, ProteinIdentityManifest)
            else validate_protein_identity_manifest(manifest)
        )
        pair_identity = build_protein_losat_pair_identity(
            authority,
            query_record_instance_key=str(entry["queryRecordInstanceKey"]),  # type: ignore[index]
            subject_record_instance_key=str(entry["subjectRecordInstanceKey"]),  # type: ignore[index]
        )
        if (
            str(entry["queryProteinSetHash"]) != pair_identity.query_protein_set_hash  # type: ignore[index]
            or str(entry["subjectProteinSetHash"]) != pair_identity.subject_protein_set_hash  # type: ignore[index]
            or str(entry["queryRuntimeBindingHash"])  # type: ignore[index]
            != pair_identity.query_runtime_binding_hash
            or str(entry["subjectRuntimeBindingHash"])  # type: ignore[index]
            != pair_identity.subject_runtime_binding_hash
        ):
            return False
        args = entry.get("args")
        if not isinstance(args, list):
            return False
        expected_key = build_protein_losat_cache_key(
            pair_identity,
            args=args,
            program=str(entry.get("program") or "blastp"),
            outfmt=str(entry.get("outfmt") or "6"),
            search_context=entry.get("searchContext"),
        )
        if str(entry.get("key") or "") != expected_key:
            return False
        return raw_protein_tsv_matches_bindings(
            str(entry.get("text") or ""),
            query_ids=_binding_runtime_ids(
                authority,
                pair_identity.query_record_instance_key,
            ),
            subject_ids=_binding_runtime_ids(
                authority,
                pair_identity.subject_record_instance_key,
            ),
        )
    except (KeyError, TypeError, ValueError, ValidationError):
        return False


def build_protein_export_id_map(
    manifest: ProteinIdentityManifest | Mapping[str, object],
    record_instance_key: str,
) -> dict[str, str]:
    """Resolve runtime handles to deterministic user-visible export IDs."""

    authority = (
        manifest
        if isinstance(manifest, ProteinIdentityManifest)
        else validate_protein_identity_manifest(manifest)
    )
    binding = authority.binding_for(str(record_instance_key))
    runtime_ids = binding.get("runtimeIds")
    feature_metadata = binding.get("featureMetadata")
    if not isinstance(runtime_ids, Mapping) or not isinstance(feature_metadata, Mapping):
        raise ValidationError("Protein record binding cannot resolve export IDs.")

    result: dict[str, str] = {}
    for feature_id, runtime_handle in runtime_ids.items():
        metadata = feature_metadata.get(feature_id)
        if not isinstance(metadata, Mapping):
            raise ValidationError("Protein export metadata is incomplete.")
        alias = _normalize_identity_text(metadata.get("displayAlias")).strip()
        if not alias:
            raise ValidationError("Protein export alias is empty.")
        export_id = percent_encode_losat_transport_field(alias)
        ordinal = metadata.get("exportOrdinal")
        if ordinal is not None:
            if isinstance(ordinal, bool) or not isinstance(ordinal, int) or ordinal <= 0:
                raise ValidationError("Protein export ordinal is invalid.")
            export_id = f"{export_id}~{ordinal}"
        handle = str(runtime_handle)
        if handle in result:
            raise ValidationError("Protein runtime handle has multiple export IDs.")
        result[handle] = export_id
    if len(set(result.values())) != len(result):
        raise ValidationError("Protein export IDs are not unique within the record instance.")
    return result


def hydrate_protein_losat_tsv(
    entry: Mapping[str, object],
    manifest: ProteinIdentityManifest | Mapping[str, object],
) -> str:
    """Replace only QUERY/SUBJECT runtime handles for a raw TSV download."""

    authority = (
        manifest
        if isinstance(manifest, ProteinIdentityManifest)
        else validate_protein_identity_manifest(manifest)
    )
    if not validate_protein_raw_entry_references(entry, authority):
        raise ValidationError(
            "Protein raw LOSAT entry does not resolve through the current manifest."
        )
    query_ids = build_protein_export_id_map(
        authority,
        str(entry["queryRecordInstanceKey"]),
    )
    subject_ids = build_protein_export_id_map(
        authority,
        str(entry["subjectRecordInstanceKey"]),
    )
    hydrated: list[str] = []
    for raw_line in str(entry.get("text") or "").splitlines(keepends=True):
        body = raw_line.rstrip("\r\n")
        ending = raw_line[len(body) :]
        if not body.strip() or body.lstrip().startswith("#"):
            hydrated.append(raw_line)
            continue
        columns = body.split("\t")
        if len(columns) != len(COMPARISON_COLUMNS):
            raise ValidationError("Protein LOSAT TSV must contain exactly 12 columns.")
        try:
            columns[0] = query_ids[columns[0]]
            columns[1] = subject_ids[columns[1]]
        except KeyError as exc:
            raise ValidationError(
                "Protein LOSAT TSV contains an unresolved or wrong-binding runtime handle."
            ) from exc
        hydrated.append("\t".join(columns) + ending)
    result = "".join(hydrated)
    if _RUNTIME_HANDLE_SEARCH_RE.search(result):
        raise ValidationError("Protein LOSAT export still contains an internal runtime handle.")
    return result


def make_legacy_protein_raw_candidate(
    entry: Mapping[str, object],
    *,
    state: Literal["pending", "promoted", "rejected"] = "pending",
    rejection_reason: str | None = None,
) -> dict[str, object]:
    """Wrap an imported legacy entry without modifying its original payload."""

    if not is_legacy_protein_losat_cache_entry(entry):
        raise ValidationError("Legacy protein candidate must contain a schema-2 blastp entry.")
    if state not in {"pending", "promoted", "rejected"}:
        raise ValidationError(f"Unsupported legacy protein candidate state {state!r}.")
    return {
        "state": state,
        "originalEntry": copy.deepcopy(dict(entry)),
        "rejectionReason": str(rejection_reason) if rejection_reason is not None else None,
    }


def validate_legacy_protein_raw_candidate_envelope(
    value: Mapping[str, object],
) -> dict[str, object]:
    """Validate the lossless schema-1 legacy candidate envelope."""

    if value.get("schema") != LEGACY_PROTEIN_RAW_CANDIDATE_SCHEMA or not isinstance(value.get("entries"), list):
        raise ValidationError("Legacy protein raw candidate envelope must use schema 1.")
    entries: list[dict[str, object]] = []
    for candidate in value["entries"]:  # type: ignore[index]
        if not isinstance(candidate, Mapping):
            raise ValidationError("Legacy protein candidate must be an object.")
        state = str(candidate.get("state") or "")
        original = candidate.get("originalEntry")
        if state not in {"pending", "promoted", "rejected"} or not isinstance(original, Mapping):
            raise ValidationError("Legacy protein candidate state or original entry is invalid.")
        if not is_legacy_protein_losat_cache_entry(original):
            raise ValidationError("Legacy protein candidate contains a non-protein entry.")
        entries.append(
            make_legacy_protein_raw_candidate(
                original,
                state=state,  # type: ignore[arg-type]
                rejection_reason=(
                    str(candidate.get("rejectionReason"))
                    if candidate.get("rejectionReason") is not None
                    else None
                ),
            )
        )
    return {"schema": LEGACY_PROTEIN_RAW_CANDIDATE_SCHEMA, "entries": entries}


_LEGACY_WEB_PROTEIN_ID_RE = re.compile(
    r"^p_(?P<record_token>.+)_(?P<start>\d+)_(?P<end>\d+)_"
    r"(?P<strand>-1|0|1)_(?P<aa_sha12>[0-9a-f]{12})(?:_(?P<duplicate>[2-9][0-9]*))?$"
)


def _legacy_record_tokens_from_tsv(text: str) -> tuple[str, str]:
    query_tokens: set[str] = set()
    subject_tokens: set[str] = set()
    found_row = False
    for raw_line in str(text).splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        columns = raw_line.split("\t")
        if len(columns) != len(COMPARISON_COLUMNS):
            raise ValidationError("Legacy LOSAT TSV does not contain 12 outfmt-6 columns.")
        query_match = _LEGACY_WEB_PROTEIN_ID_RE.fullmatch(columns[0])
        subject_match = _LEGACY_WEB_PROTEIN_ID_RE.fullmatch(columns[1])
        if query_match is None or subject_match is None:
            raise ValidationError("Legacy LOSAT TSV contains an unrecognized protein ID.")
        query_tokens.add(query_match.group("record_token"))
        subject_tokens.add(subject_match.group("record_token"))
        found_row = True
    if not found_row:
        raise ValidationError("Empty legacy LOSAT output does not prove record tokens.")
    if len(query_tokens) != 1 or len(subject_tokens) != 1:
        raise ValidationError("Legacy LOSAT TSV does not resolve to one directional record pair.")
    return next(iter(query_tokens)), next(iter(subject_tokens))


def _legacy_record_token_evidence(
    entries: Sequence[Mapping[str, object]],
) -> dict[str, set[str]]:
    tokens_by_fasta_hash: dict[str, set[str]] = {}
    for candidate in entries:
        entry = _legacy_original_entry(candidate)
        if not is_legacy_protein_losat_cache_entry(entry):
            continue
        try:
            query_token, subject_token = _legacy_record_tokens_from_tsv(
                str(entry.get("text") or "")
            )
        except ValidationError:
            continue
        for hash_field, token in (
            ("queryCanonicalHash", query_token),
            ("subjectCanonicalHash", subject_token),
        ):
            fasta_hash = str(entry.get(hash_field) or "")
            if fasta_hash:
                tokens_by_fasta_hash.setdefault(fasta_hash, set()).add(token)
    return tokens_by_fasta_hash


def _legacy_fasta_and_id_map(
    proteins: Sequence[CdsProtein],
    record_token: str,
) -> tuple[str, dict[str, str]]:
    legacy = _with_stable_web_protein_ids(proteins, record_token)
    mapping: dict[str, str] = {}
    for legacy_protein, current_protein in zip(legacy, proteins, strict=True):
        if legacy_protein.protein_id in mapping:
            raise ValidationError("Legacy protein IDs are not one-to-one.")
        mapping[legacy_protein.protein_id] = current_protein.protein_id
    if len(set(mapping.values())) != len(mapping):
        raise ValidationError("Current runtime handles are not one-to-one.")
    return proteins_to_fasta(legacy), mapping


def _legacy_reverse_record_lengths(
    proteins: Sequence[CdsProtein],
    references: set[str],
) -> set[int]:
    """Infer lengths that make references exact reverse-complement spans."""

    lengths: set[int] = set()
    for reference in references:
        match = _LEGACY_WEB_PROTEIN_ID_RE.fullmatch(reference)
        if match is None:  # Already validated by the caller.
            continue
        reference_start = int(match.group("start"))
        reference_end = int(match.group("end"))
        reference_strand = int(match.group("strand"))
        reference_aa_sha12 = match.group("aa_sha12")
        for protein in proteins:
            protein_start = (
                int(protein.feature_hash_start)
                if protein.feature_hash_start is not None
                else int(protein.start)
            )
            protein_end = (
                int(protein.feature_hash_end)
                if protein.feature_hash_end is not None
                else int(protein.end)
            )
            identity_strand = (
                protein.feature_hash_strand
                if protein.feature_hash_strand is not None
                else protein.strand
            )
            protein_strand = identity_strand if identity_strand in {-1, 1} else 0
            reversed_strand = -protein_strand if protein_strand else 0
            if (
                reference_aa_sha12
                != hashlib.sha256(protein.sequence.encode("utf-8")).hexdigest()[:12]
                or reference_end - reference_start != protein_end - protein_start
                or reference_strand != reversed_strand
            ):
                continue
            length_from_start = reference_start + protein_end
            length_from_end = reference_end + protein_start
            if (
                length_from_start == length_from_end
                and length_from_start >= max(reference_end, protein_end)
            ):
                lengths.add(length_from_start)
    return lengths


def _legacy_reverse_id_map(
    proteins: Sequence[CdsProtein],
    record_token: str,
    record_length: int,
) -> dict[str, str]:
    """Reconstruct IDs emitted for a legacy reverse-complemented record."""

    reversed_proteins: list[CdsProtein] = []
    for protein in reversed(proteins):
        protein_start = (
            int(protein.feature_hash_start)
            if protein.feature_hash_start is not None
            else int(protein.start)
        )
        protein_end = (
            int(protein.feature_hash_end)
            if protein.feature_hash_end is not None
            else int(protein.end)
        )
        start = int(record_length) - protein_end
        end = int(record_length) - protein_start
        if start < 0 or end <= start:
            return {}
        identity_strand = (
            protein.feature_hash_strand
            if protein.feature_hash_strand is not None
            else protein.strand
        )
        protein_strand = identity_strand if identity_strand in {-1, 1} else 0
        reversed_proteins.append(
            replace(
                protein,
                start=start,
                end=end,
                strand=-protein_strand if protein_strand else None,
                feature_hash_start=start,
                feature_hash_end=end,
                feature_hash_strand=-protein_strand if protein_strand else None,
            )
        )
    _, mapping = _legacy_fasta_and_id_map(reversed_proteins, record_token)
    return mapping


def build_legacy_protein_reference_map(
    extraction: ProteinExtractionResult,
    reference_ids: Sequence[str],
) -> dict[str, str]:
    """Resolve legacy ``p_r_`` artifact IDs through current protein identity."""

    if extraction.identity_manifest is None:
        raise ValidationError(
            "Legacy protein reference migration requires an identity manifest."
        )
    references_by_token: dict[str, set[str]] = {}
    for raw_reference in reference_ids:
        reference = str(raw_reference)
        match = _LEGACY_WEB_PROTEIN_ID_RE.fullmatch(reference)
        if match is None:
            raise ValidationError(
                f"Unrecognized legacy protein reference {reference!r}."
            )
        references_by_token.setdefault(
            match.group("record_token"), set()
        ).add(reference)

    resolved: dict[str, str] = {}
    for record_token, references in references_by_token.items():
        candidate_maps: list[dict[str, str]] = []
        candidate_signatures: set[tuple[tuple[str, str], ...]] = set()
        for proteins in extraction.proteins_by_record:
            _, direct_map = _legacy_fasta_and_id_map(proteins, record_token)
            unresolved = references.difference(direct_map)
            combined_maps = [direct_map] if not unresolved else []
            for record_length in _legacy_reverse_record_lengths(
                proteins,
                unresolved,
            ):
                reverse_map = _legacy_reverse_id_map(
                    proteins,
                    record_token,
                    record_length,
                )
                if any(
                    reference in direct_map
                    and direct_map[reference] != runtime_handle
                    for reference, runtime_handle in reverse_map.items()
                ):
                    continue
                combined_maps.append({**direct_map, **reverse_map})
            for candidate_map in combined_maps:
                if not references.issubset(candidate_map):
                    continue
                projected_map = {
                    reference: candidate_map[reference]
                    for reference in references
                }
                signature = tuple(sorted(projected_map.items()))
                if signature in candidate_signatures:
                    continue
                candidate_signatures.add(signature)
                candidate_maps.append(projected_map)
        if len(candidate_maps) != 1:
            raise ValidationError(
                f"Legacy protein record token {record_token!r} resolves to "
                f"{len(candidate_maps)} current record instances."
            )
        candidate_map = candidate_maps[0]
        for reference in references:
            runtime_handle = candidate_map[reference]
            previous = resolved.get(reference)
            if previous is not None and previous != runtime_handle:
                raise ValidationError(
                    f"Legacy protein reference {reference!r} is ambiguous."
                )
            resolved[reference] = runtime_handle
    return resolved


def _rewrite_legacy_protein_tsv(
    text: str,
    query_id_map: Mapping[str, str],
    subject_id_map: Mapping[str, str],
) -> str:
    rewritten: list[str] = []
    for raw_line in str(text).splitlines(keepends=True):
        body = raw_line.rstrip("\r\n")
        ending = raw_line[len(body) :]
        if not body.strip() or body.lstrip().startswith("#"):
            rewritten.append(raw_line)
            continue
        columns = body.split("\t")
        if len(columns) != len(COMPARISON_COLUMNS):
            raise ValidationError("Legacy LOSAT TSV does not contain 12 outfmt-6 columns.")
        if columns[0] not in query_id_map or columns[1] not in subject_id_map:
            raise ValidationError("Legacy LOSAT TSV references a protein outside the verified pair.")
        columns[0] = query_id_map[columns[0]]
        columns[1] = subject_id_map[columns[1]]
        rewritten.append("\t".join(columns) + ending)
    result = "".join(rewritten)
    # Parsing also proves that all numeric fields survived the rewrite.
    parse_losatp_outfmt6(result)
    return result


def _legacy_original_entry(candidate: Mapping[str, object]) -> Mapping[str, object]:
    original = candidate.get("originalEntry")
    return original if isinstance(original, Mapping) else candidate


def promote_legacy_protein_raw_cache_entries(
    entries: Sequence[Mapping[str, object]],
    *,
    query_proteins: Sequence[CdsProtein],
    subject_proteins: Sequence[CdsProtein],
    query_fasta: str,
    subject_fasta: str,
    identity_manifest: ProteinIdentityManifest | Mapping[str, object],
    expected_args: Sequence[str],
    expected_program: str = "blastp",
    expected_outfmt: str = "6",
) -> LegacyProteinRawCachePromotionScan:
    """Find and verify a legacy pair, then return a schema-4 copy.

    No input object is mutated. A failed candidate contributes a pair-local
    rejection diagnostic and never enters the current cache.
    """

    manifest = (
        identity_manifest
        if isinstance(identity_manifest, ProteinIdentityManifest)
        else validate_protein_identity_manifest(identity_manifest)
    )
    if proteins_to_fasta(query_proteins) != str(query_fasta):
        raise ValidationError("query_fasta does not match the current query extraction.")
    if proteins_to_fasta(subject_proteins) != str(subject_fasta):
        raise ValidationError("subject_fasta does not match the current subject extraction.")
    query_instance_key = _fasta_record_instance_key(query_fasta, manifest)
    subject_instance_key = _fasta_record_instance_key(subject_fasta, manifest)
    pair_identity = build_protein_losat_pair_identity(
        manifest,
        query_record_instance_key=query_instance_key,
        subject_record_instance_key=subject_instance_key,
    )
    expected_arg_tuple = tuple(str(arg) for arg in expected_args)
    rejections: list[LegacyProteinRawCacheRejection] = []
    token_evidence: dict[str, set[str]] | None = None

    for candidate_index, candidate in enumerate(entries):
        entry = _legacy_original_entry(candidate)
        try:
            if not is_legacy_protein_losat_cache_entry(entry):
                raise ValidationError("Candidate is not a schema-2 protein raw entry.")
            if str(entry.get("program") or "blastp").lower() != str(expected_program).lower():
                raise ValidationError("Legacy program does not match the requested program.")
            if str(entry.get("outfmt") or "") != str(expected_outfmt):
                raise ValidationError("Legacy outfmt is missing or does not match.")
            raw_args = entry.get("args")
            if not isinstance(raw_args, list) or tuple(str(arg) for arg in raw_args) != expected_arg_tuple:
                raise ValidationError("Legacy search args are missing or do not match.")

            raw_text = str(entry.get("text") or "")
            if any(
                line.strip() and not line.lstrip().startswith("#")
                for line in raw_text.splitlines()
            ):
                query_token, subject_token = _legacy_record_tokens_from_tsv(raw_text)
            else:
                if token_evidence is None:
                    token_evidence = _legacy_record_token_evidence(entries)
                query_candidates = token_evidence.get(
                    str(entry.get("queryCanonicalHash") or ""),
                    set(),
                )
                subject_candidates = token_evidence.get(
                    str(entry.get("subjectCanonicalHash") or ""),
                    set(),
                )
                if len(query_candidates) != 1 or len(subject_candidates) != 1:
                    raise ValidationError(
                        "Empty legacy LOSAT output does not prove record tokens."
                    )
                query_token = next(iter(query_candidates))
                subject_token = next(iter(subject_candidates))
            legacy_query_fasta, query_id_map = _legacy_fasta_and_id_map(
                query_proteins,
                query_token,
            )
            legacy_subject_fasta, subject_id_map = _legacy_fasta_and_id_map(
                subject_proteins,
                subject_token,
            )
            if _hash_text_sha256(legacy_query_fasta) != str(entry.get("queryCanonicalHash") or ""):
                raise ValidationError("Legacy query FASTA hash does not match.")
            if _hash_text_sha256(legacy_subject_fasta) != str(entry.get("subjectCanonicalHash") or ""):
                raise ValidationError("Legacy subject FASTA hash does not match.")
            rewritten_tsv = _rewrite_legacy_protein_tsv(
                raw_text,
                query_id_map,
                subject_id_map,
            )
            query_ids = _binding_runtime_ids(manifest, query_instance_key)
            subject_ids = _binding_runtime_ids(manifest, subject_instance_key)
            if not raw_protein_tsv_matches_bindings(
                rewritten_tsv,
                query_ids=query_ids,
                subject_ids=subject_ids,
            ):
                raise ValidationError("Rewritten TSV does not match the current bindings.")

            cache_key = build_protein_losat_cache_key(
                pair_identity,
                args=expected_arg_tuple,
                program=expected_program,
                outfmt=expected_outfmt,
            )
            promoted: dict[str, object] = {
                "schema": PROTEIN_LOSAT_CACHE_SCHEMA,
                "kind": "raw-losat",
                "identityKind": "protein",
                "idEncoding": "runtime-handle-v1",
                "key": cache_key,
                "filename": str(entry.get("filename") or ""),
                "display": bool(entry.get("display")) if "display" in entry else False,
                "text": rewritten_tsv,
                "program": str(expected_program),
                "outfmt": str(expected_outfmt),
                "args": list(expected_arg_tuple),
                "queryProteinSetHash": pair_identity.query_protein_set_hash,
                "subjectProteinSetHash": pair_identity.subject_protein_set_hash,
                "queryRuntimeBindingHash": pair_identity.query_runtime_binding_hash,
                "subjectRuntimeBindingHash": pair_identity.subject_runtime_binding_hash,
                "queryRecordInstanceKey": pair_identity.query_record_instance_key,
                "subjectRecordInstanceKey": pair_identity.subject_record_instance_key,
            }
            if not is_protein_losat_cache_entry(promoted):
                raise ValidationError("Promoted schema-4 entry failed validation.")
            return LegacyProteinRawCachePromotionScan(
                promotion=LegacyProteinRawCachePromotion(
                    candidate_index=candidate_index,
                    entry=promoted,
                    rewritten_tsv=rewritten_tsv,
                    legacy_query_fasta=legacy_query_fasta,
                    legacy_subject_fasta=legacy_subject_fasta,
                ),
                rejections=tuple(rejections),
            )
        except (ParseError, ValidationError) as exc:
            rejections.append(
                LegacyProteinRawCacheRejection(
                    candidate_index=candidate_index,
                    reason=str(exc),
                )
            )

    return LegacyProteinRawCachePromotionScan(
        promotion=None,
        rejections=tuple(rejections),
    )


class LosatpCacheManager:
    """Validated schema-4 protein raw-cache lookup and collection."""

    def __init__(
        self,
        entries: Sequence[Mapping[str, object]] | None = None,
        *,
        identity_manifest: ProteinIdentityManifest | Mapping[str, object] | None = None,
        threads_per_job: str | int = "auto",
        runtime_compatibility: str = "threaded-compatible-v1",
    ) -> None:
        self.threads_per_job = threads_per_job
        self.runtime_compatibility = runtime_compatibility
        self.identity_manifest = (
            identity_manifest
            if isinstance(identity_manifest, ProteinIdentityManifest)
            else (
                validate_protein_identity_manifest(identity_manifest)
                if identity_manifest is not None
                else None
            )
        )
        self._entries_by_key: dict[str, dict[str, object]] = {}
        self._legacy_entries: list[dict[str, object]] = []
        self._proteins_by_instance: dict[str, tuple[CdsProtein, ...]] = {}
        self._display_order: list[str] = []
        self._display_info: dict[str, tuple[str, bool]] = {}
        for entry in entries or ():
            if is_legacy_protein_losat_cache_entry(entry):
                self._legacy_entries.append(copy.deepcopy(dict(entry)))
                continue
            if not is_protein_losat_cache_entry(entry):
                continue
            key = str(entry.get("key") or "").strip()
            if not key:
                continue
            normalized = {
                "schema": PROTEIN_LOSAT_CACHE_SCHEMA,
                "kind": "raw-losat",
                "identityKind": "protein",
                "idEncoding": "runtime-handle-v1",
                "key": key,
                "filename": str(entry.get("filename") or ""),
                "display": bool(entry.get("display")) if "display" in entry else False,
                "text": str(entry.get("text") or ""),
                "program": str(entry.get("program") or "blastp"),
                "outfmt": str(entry.get("outfmt") or "6"),
                "args": [str(arg) for arg in entry.get("args") or ()],
                "queryProteinSetHash": str(entry.get("queryProteinSetHash") or ""),
                "subjectProteinSetHash": str(entry.get("subjectProteinSetHash") or ""),
                "queryRuntimeBindingHash": str(
                    entry.get("queryRuntimeBindingHash") or ""
                ),
                "subjectRuntimeBindingHash": str(
                    entry.get("subjectRuntimeBindingHash") or ""
                ),
                "queryRecordInstanceKey": str(entry.get("queryRecordInstanceKey") or ""),
                "subjectRecordInstanceKey": str(entry.get("subjectRecordInstanceKey") or ""),
            }
            if "searchContext" in entry:
                normalized["searchContext"] = entry["searchContext"]
            if self.identity_manifest is not None and not validate_protein_raw_entry_references(
                normalized,
                self.identity_manifest,
            ):
                continue
            self._entries_by_key[key] = normalized
            if normalized["display"] is not False and key not in self._display_info:
                self._display_order.append(key)
                self._display_info[key] = (str(normalized["filename"] or ""), True)

    @property
    def has_entries(self) -> bool:
        return bool(self._entries_by_key)

    @property
    def has_legacy_candidates(self) -> bool:
        return bool(self._legacy_entries)

    def set_identity_manifest(
        self,
        manifest: ProteinIdentityManifest | Mapping[str, object],
    ) -> None:
        self.identity_manifest = (
            manifest
            if isinstance(manifest, ProteinIdentityManifest)
            else validate_protein_identity_manifest(manifest)
        )
        self._entries_by_key = {
            key: entry
            for key, entry in self._entries_by_key.items()
            if validate_protein_raw_entry_references(entry, self.identity_manifest)
        }
        self._display_order = [
            key for key in self._display_order if key in self._entries_by_key
        ]
        self._display_info = {
            key: value
            for key, value in self._display_info.items()
            if key in self._entries_by_key
        }

    def set_protein_extraction(self, extraction: ProteinExtractionResult) -> None:
        """Attach the current extraction needed to verify legacy cache candidates."""

        if extraction.identity_manifest is None:
            raise ValidationError(
                "Stable protein extraction must include an identity manifest."
            )
        if len(extraction.record_instance_keys) != len(extraction.proteins_by_record):
            raise ValidationError(
                "Stable protein extraction record bindings are incomplete."
            )

        self.set_identity_manifest(extraction.identity_manifest)
        proteins_by_instance: dict[str, tuple[CdsProtein, ...]] = {}
        for instance_key, proteins in zip(
            extraction.record_instance_keys,
            extraction.proteins_by_record,
            strict=True,
        ):
            normalized_key = str(instance_key).strip()
            if not normalized_key or normalized_key in proteins_by_instance:
                raise ValidationError(
                    "Stable protein extraction record-instance keys must be non-empty and unique."
                )
            protein_tuple = tuple(proteins)
            fasta_text = proteins_to_fasta(protein_tuple)
            if _fasta_record_instance_key(fasta_text, self.identity_manifest) != normalized_key:
                raise ValidationError(
                    "Stable protein extraction does not match its record-instance binding."
                )
            proteins_by_instance[normalized_key] = protein_tuple
        self._proteins_by_instance = proteins_by_instance

    def legacy_candidate_envelope(self) -> dict[str, object]:
        return {
            "schema": LEGACY_PROTEIN_RAW_CANDIDATE_SCHEMA,
            "entries": [make_legacy_protein_raw_candidate(entry) for entry in self._legacy_entries],
        }

    def add_promoted_entry(self, entry: Mapping[str, object]) -> None:
        if not is_protein_losat_cache_entry(entry):
            raise ValidationError(
                "Only current schema-4 protein entries can be promoted into the cache."
            )
        if self.identity_manifest is None or not validate_protein_raw_entry_references(
            entry,
            self.identity_manifest,
        ):
            raise ValidationError("Promoted protein entry does not match the current manifest.")
        key = str(entry["key"])
        self._entries_by_key[key] = dict(entry)

    def _pair_identity_from_fasta(
        self,
        query_fasta: str,
        subject_fasta: str,
    ) -> ProteinLosatPairIdentity:
        if self.identity_manifest is None:
            raise ValidationError(
                "Protein raw cache schema 4 requires a protein identity manifest."
            )
        query_instance_key = _fasta_record_instance_key(query_fasta, self.identity_manifest)
        subject_instance_key = _fasta_record_instance_key(subject_fasta, self.identity_manifest)
        return build_protein_losat_pair_identity(
            self.identity_manifest,
            query_record_instance_key=query_instance_key,
            subject_record_instance_key=subject_instance_key,
        )

    def _find_cached_entry(
        self,
        *,
        cache_key: str,
        pair_identity: ProteinLosatPairIdentity,
        program: str,
        outfmt: str,
        args: Sequence[str],
    ) -> dict[str, object] | None:
        cached = self._entries_by_key.get(cache_key)
        if cached is None or self.identity_manifest is None:
            return None
        expected = pair_identity.cache_payload(args=args, program=program, outfmt=outfmt)
        for payload_key, entry_key in (
            ("queryProteinSetHash", "queryProteinSetHash"),
            ("subjectProteinSetHash", "subjectProteinSetHash"),
            ("queryRuntimeBindingHash", "queryRuntimeBindingHash"),
            ("subjectRuntimeBindingHash", "subjectRuntimeBindingHash"),
            ("queryRecordInstanceKey", "queryRecordInstanceKey"),
            ("subjectRecordInstanceKey", "subjectRecordInstanceKey"),
        ):
            if str(cached.get(entry_key) or "") != str(expected[payload_key]):
                return None
        if str(cached.get("program") or "") != program:
            return None
        if str(cached.get("outfmt") or "") != outfmt:
            return None
        if tuple(str(arg) for arg in cached.get("args") or ()) != tuple(str(arg) for arg in args):
            return None
        query_ids = _binding_runtime_ids(
            self.identity_manifest,
            pair_identity.query_record_instance_key,
        )
        subject_ids = _binding_runtime_ids(
            self.identity_manifest,
            pair_identity.subject_record_instance_key,
        )
        if not raw_protein_tsv_matches_bindings(
            str(cached.get("text") or ""),
            query_ids=query_ids,
            subject_ids=subject_ids,
        ):
            return None
        return cached

    def runner_for_search(
        self,
        *,
        losatp_bin: str,
        ncbi_blastp_bin: str | None = None,
        losatp_threads: int | None,
        candidate_limit: int | None,
        max_hsps_per_subject: int | None,
        args: Sequence[str],
        filename: str = "",
        display: bool = False,
    ) -> LosatpRunner:
        def _runner(query_fasta: str, subject_fasta: str) -> DataFrame:
            pair_identity = self._pair_identity_from_fasta(query_fasta, subject_fasta)
            cache_key = build_protein_losat_cache_key(
                pair_identity,
                args=args,
                program="blastp",
                outfmt="6",
            )
            cached = self._find_cached_entry(
                cache_key=cache_key,
                pair_identity=pair_identity,
                program="blastp",
                outfmt="6",
                args=args,
            )
            if cached is not None:
                if display:
                    self._mark_display(cache_key, filename)
                return parse_losatp_outfmt6(str(cached.get("text") or ""))

            query_proteins = self._proteins_by_instance.get(
                pair_identity.query_record_instance_key
            )
            subject_proteins = self._proteins_by_instance.get(
                pair_identity.subject_record_instance_key
            )
            if self._legacy_entries and query_proteins is not None and subject_proteins is not None:
                scan = promote_legacy_protein_raw_cache_entries(
                    self._legacy_entries,
                    query_proteins=query_proteins,
                    subject_proteins=subject_proteins,
                    query_fasta=query_fasta,
                    subject_fasta=subject_fasta,
                    identity_manifest=self.identity_manifest,  # type: ignore[arg-type]
                    expected_args=args,
                    expected_program="blastp",
                    expected_outfmt="6",
                )
                if scan.promotion is not None:
                    promotion = scan.promotion
                    promoted_result = parse_losatp_outfmt6(promotion.rewritten_tsv)
                    self.add_promoted_entry(promotion.entry)
                    del self._legacy_entries[promotion.candidate_index]
                    if display:
                        self._mark_display(cache_key, filename)
                    return promoted_result

            raw_text_holder: dict[str, str] = {}
            result = _execute_losatp_search(
                query_fasta,
                subject_fasta,
                losatp_bin=losatp_bin,
                ncbi_blastp_bin=ncbi_blastp_bin,
                candidate_limit=candidate_limit,
                max_hsps_per_subject=max_hsps_per_subject,
                losatp_threads=losatp_threads,
                runner=None,
                losatp_cache=None,
                raw_output_callback=lambda text: raw_text_holder.__setitem__("text", text),
            )
            entry = {
                "schema": PROTEIN_LOSAT_CACHE_SCHEMA,
                "kind": "raw-losat",
                "identityKind": "protein",
                "idEncoding": "runtime-handle-v1",
                "key": cache_key,
                "filename": filename if display else "",
                "display": bool(display),
                "text": raw_text_holder.get("text", ""),
                "program": "blastp",
                "outfmt": "6",
                "args": [str(arg) for arg in args],
                "queryProteinSetHash": pair_identity.query_protein_set_hash,
                "subjectProteinSetHash": pair_identity.subject_protein_set_hash,
                "queryRuntimeBindingHash": pair_identity.query_runtime_binding_hash,
                "subjectRuntimeBindingHash": pair_identity.subject_runtime_binding_hash,
                "queryRecordInstanceKey": pair_identity.query_record_instance_key,
                "subjectRecordInstanceKey": pair_identity.subject_record_instance_key,
            }
            if not raw_protein_tsv_matches_bindings(
                str(entry["text"]),
                query_ids=_binding_runtime_ids(
                    self.identity_manifest,  # type: ignore[arg-type]
                    pair_identity.query_record_instance_key,
                ),
                subject_ids=_binding_runtime_ids(
                    self.identity_manifest,  # type: ignore[arg-type]
                    pair_identity.subject_record_instance_key,
                ),
            ):
                raise ValidationError("LOSAT output references IDs outside the current protein bindings.")
            self._entries_by_key[cache_key] = entry
            if display:
                self._mark_display(cache_key, filename)
            return result

        return _runner

    def _mark_display(self, key: str, filename: str) -> None:
        if key not in self._display_info:
            self._display_order.append(key)
        self._display_info[key] = (str(filename or ""), True)

    def session_entries(self) -> tuple[dict[str, object], ...]:
        result: list[dict[str, object]] = []
        seen: set[str] = set()
        for key in self._display_order:
            entry = self._entries_by_key.get(key)
            if entry is None:
                continue
            filename, display = self._display_info.get(key, ("", True))
            rendered = dict(entry)
            rendered["filename"] = filename
            rendered["display"] = display
            result.append(rendered)
            seen.add(key)
        for key, entry in self._entries_by_key.items():
            if key in seen:
                continue
            rendered = dict(entry)
            rendered["filename"] = ""
            rendered["display"] = False
            result.append(rendered)
        return tuple(result)


def _first_qualifier(feature: SeqFeature, key: str) -> str | None:
    value = feature.qualifiers.get(key)
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        if not value:
            return None
        value = value[0]
    text = str(value).strip()
    return text or None


def _qualifier_values(feature: SeqFeature, key: str) -> tuple[str, ...]:
    value = feature.qualifiers.get(key)
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        value = (value,)
    values: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            values.append(text)
    return tuple(values)


def _first_qualifier_from_any(feature: SeqFeature, keys: Sequence[str]) -> str | None:
    for key in keys:
        value = _first_qualifier(feature, key)
        if value:
            return value
    return None


def _fasta_safe_protein_id(protein_id: str | None) -> str | None:
    if protein_id is None:
        return None
    return protein_id if _VALID_FASTA_ID_RE.fullmatch(protein_id) else None


def _unique_protein_id(
    preferred_id: str | None,
    fallback_id: str,
    used_ids: set[str],
) -> str:
    if preferred_id is not None and preferred_id not in used_ids:
        return preferred_id
    if fallback_id not in used_ids:
        return fallback_id
    suffix = 2
    while f"{fallback_id}_{suffix}" in used_ids:
        suffix += 1
    return f"{fallback_id}_{suffix}"


def _clean_protein_sequence(sequence: object | None) -> str | None:
    if sequence is None:
        return None
    protein = "".join(str(sequence).split()).upper()
    while protein.endswith("*"):
        protein = protein[:-1]
    if not protein or "*" in protein:
        return None
    if not _VALID_PROTEIN_RE.fullmatch(protein):
        return None
    return protein


def _translation_table(feature: SeqFeature) -> int | str:
    raw_table = _first_qualifier(feature, "transl_table")
    if raw_table is None:
        return 1
    try:
        return int(raw_table)
    except ValueError:
        return raw_table


def _codon_start(feature: SeqFeature) -> int:
    raw_start = _first_qualifier(feature, "codon_start")
    if raw_start is None:
        return 1
    try:
        codon_start = int(raw_start)
    except ValueError:
        return 1
    return codon_start if codon_start in {1, 2, 3} else 1


def _feature_identifier(feature: SeqFeature) -> str | None:
    feature_id = _first_qualifier(feature, "ID")
    if feature_id:
        return feature_id
    raw_id = str(getattr(feature, "id", "") or "").strip()
    if raw_id and raw_id != "<unknown id>":
        return raw_id
    return None


def _iter_record_features(
    record: SeqRecord,
) -> list[tuple[int, SeqFeature, tuple[SeqFeature, ...]]]:
    items: list[tuple[int, SeqFeature, tuple[SeqFeature, ...]]] = []

    def walk(feature: SeqFeature, ancestors: tuple[SeqFeature, ...]) -> None:
        source_index = _source_feature_index(feature)
        items.append(
            (
                len(items) if source_index is None else source_index,
                feature,
                ancestors,
            )
        )
        sub_features = getattr(feature, "sub_features", None) or []
        for sub_feature in sub_features:
            walk(sub_feature, ancestors + (feature,))

    for feature in record.features:
        walk(feature, ())
    return items


def _build_parent_graph(
    feature_items: Sequence[tuple[int, SeqFeature, tuple[SeqFeature, ...]]],
) -> dict[str, tuple[str, tuple[str, ...]]]:
    graph: dict[str, tuple[str, tuple[str, ...]]] = {}
    for _feature_index, feature, ancestors in feature_items:
        feature_id = _feature_identifier(feature)
        if not feature_id:
            continue
        parent_ids = _qualifier_values(feature, "Parent")
        if not parent_ids and ancestors:
            ancestor_id = _feature_identifier(ancestors[-1])
            if ancestor_id:
                parent_ids = (ancestor_id,)
        graph[feature_id] = (str(feature.type), tuple(parent_ids))
    return graph


def _resolve_gene_parent_id(
    feature: SeqFeature,
    ancestors: Sequence[SeqFeature],
    parent_graph: Mapping[str, tuple[str, tuple[str, ...]]],
) -> str | None:
    for ancestor in reversed(tuple(ancestors)):
        if str(ancestor.type).lower() == "gene":
            ancestor_id = _feature_identifier(ancestor)
            if ancestor_id:
                return ancestor_id

    start_ids = list(_qualifier_values(feature, "Parent"))
    if not start_ids and ancestors:
        ancestor_id = _feature_identifier(ancestors[-1])
        if ancestor_id:
            start_ids.append(ancestor_id)

    seen: set[str] = set()

    def resolve(feature_id: str) -> str | None:
        if feature_id in seen:
            return None
        seen.add(feature_id)
        feature_type, parent_ids = parent_graph.get(feature_id, ("", ()))
        if str(feature_type).lower() == "gene":
            return feature_id
        for parent_id in parent_ids:
            resolved = resolve(parent_id)
            if resolved:
                return resolved
        return None

    for parent_id in start_ids:
        resolved = resolve(parent_id)
        if resolved:
            return resolved
    return None


def _translate_cds_feature(record: SeqRecord, feature: SeqFeature) -> str | None:
    try:
        nucleotide_sequence = feature.extract(record.seq)
        offset = _codon_start(feature) - 1
        if offset:
            nucleotide_sequence = nucleotide_sequence[offset:]
        protein = nucleotide_sequence.translate(table=_translation_table(feature), to_stop=False)
    except Exception as exc:
        logger.debug(
            "Skipping CDS feature %s on %s: translation failed: %s",
            getattr(feature, "id", ""),
            record.id,
            exc,
        )
        return None
    return _clean_protein_sequence(protein)


def _cds_span(feature: SeqFeature) -> tuple[int, int, int | None] | None:
    location = feature.location
    if location is None:
        return None
    start = int(location.start)
    end = int(location.end)
    if start < 0 or end <= start:
        return None
    strand = location.strand if location.strand in {-1, 1} else None
    return start, end, strand


def _feature_hash_parts(
    feature: SeqFeature,
    coord_base: int = 1,
    coord_step: int = 1,
) -> tuple[tuple[int, int, int | None], ...]:
    """Return hash parts in the source-record biological coordinate system."""

    source_parts = _source_feature_location_parts(feature)
    if source_parts is not None:
        return source_parts
    location = feature.location
    if location is None:
        return ()
    if hasattr(location, "parts") and location.parts:
        raw_parts = location.parts
    else:
        raw_parts = [location]
    parts: list[tuple[int, int, int | None]] = []
    for part in raw_parts:
        strand = part.strand if part.strand in {-1, 1} else None
        start, end = _absolute_display_interval(
            int(part.start),
            int(part.end),
            coord_base,
            coord_step,
        )
        biological_strand = (
            int(strand) * (1 if int(coord_step) >= 0 else -1)
            if strand is not None
            else None
        )
        parts.append((start, end, biological_strand))
    return tuple(parts)


def _view_feature_hash_parts(
    feature: SeqFeature,
) -> tuple[tuple[int, int, int | None], ...]:
    """Return location parts in the currently rendered record view."""

    location = feature.location
    if location is None:
        return ()
    raw_parts = location.parts if hasattr(location, "parts") and location.parts else [location]
    return tuple(
        (
            int(part.start),
            int(part.end),
            int(part.strand) if part.strand in {-1, 1} else None,
        )
        for part in raw_parts
    )


def extract_cds_proteins(
    records: Sequence[SeqRecord],
    *,
    record_index_offset: int = 0,
    prefer_source_ids: bool = True,
    feature_visibility_rules: list[dict[str, object]] | None = None,
) -> ProteinExtractionResult:
    """Extract CDS proteins using protein IDs where possible and genomic spans.

    Coordinates in the returned metadata are Python/Biopython-style 0-based start
    and 0-based exclusive end values.
    """

    candidate_records: list[list[_CdsProteinCandidate]] = []
    source_id_counts: dict[str, int] = {}
    protein_map: dict[str, CdsProtein] = {}

    record_index_offset = int(record_index_offset)

    for record_index, record in enumerate(records):
        global_record_index = record_index + record_index_offset
        coord_base, coord_step = _read_record_coord_map(record)
        record_candidates: list[_CdsProteinCandidate] = []
        cds_count = 0
        feature_items = _iter_record_features(record)
        parent_graph = _build_parent_graph(feature_items)
        for feature_index, feature, ancestors in feature_items:
            if feature.type != "CDS":
                continue
            if not should_include_feature_in_analysis(
                feature,
                feature_visibility_rules,
                record_id=record.id,
            ):
                continue

            span = _cds_span(feature)
            if span is None:
                continue
            start, end, strand = span

            protein_sequence = _clean_protein_sequence(
                _first_qualifier(feature, "translation")
            )
            if protein_sequence is None:
                protein_sequence = _translate_cds_feature(record, feature)
            if protein_sequence is None:
                continue

            cds_count += 1
            hash_parts = _feature_hash_parts(feature, coord_base, coord_step)
            view_hash_parts = _view_feature_hash_parts(feature)
            view_feature_svg_id = (
                compute_feature_hash_from_location_parts(
                    str(feature.type or ""),
                    view_hash_parts,
                    record_id=record.id,
                )
                if view_hash_parts
                else None
            )
            hash_start, hash_end, hash_strand = hash_parts[0] if hash_parts else (None, None, None)
            synthetic_protein_id = f"gbd_r{global_record_index + 1:04d}_cds{cds_count:06d}"
            source_protein_id = _first_qualifier(feature, "protein_id")
            fasta_safe_source_id = _fasta_safe_protein_id(source_protein_id)
            if fasta_safe_source_id is not None:
                source_id_counts[fasta_safe_source_id] = source_id_counts.get(fasta_safe_source_id, 0) + 1
            gene = _first_qualifier(feature, "gene")
            product = _first_qualifier(feature, "product")
            note = _first_qualifier(feature, "note")
            locus_tag = _first_qualifier(feature, "locus_tag")
            gene_id = _first_qualifier(feature, "gene_id")
            old_locus_tag = _first_qualifier(feature, "old_locus_tag")
            db_xref = _qualifier_values(feature, "db_xref")
            gff_id = _feature_identifier(feature)
            parent_ids = _qualifier_values(feature, "Parent")
            if not parent_ids and ancestors:
                ancestor_id = _feature_identifier(ancestors[-1])
                if ancestor_id:
                    parent_ids = (ancestor_id,)
            gene_parent_id = _resolve_gene_parent_id(feature, ancestors, parent_graph)
            label = (
                _first_qualifier_from_any(
                    feature, ("locus_tag", "protein_id", "gene", "product")
                )
                or synthetic_protein_id
            )
            record_candidates.append(
                _CdsProteinCandidate(
                    protein_id=synthetic_protein_id,
                    source_protein_id=source_protein_id,
                    record_index=global_record_index,
                    feature_index=feature_index,
                    record_id=str(record.id),
                    start=start,
                    end=end,
                    strand=strand,
                    label=label,
                    protein_length=len(protein_sequence),
                    sequence=protein_sequence,
                    feature_svg_id=compute_feature_hash_from_location_parts(
                        str(feature.type or ""),
                        hash_parts,
                        record_id=record.id,
                    ),
                    view_feature_svg_id=view_feature_svg_id,
                    gene=gene,
                    product=product,
                    note=note,
                    locus_tag=locus_tag,
                    gene_id=gene_id,
                    old_locus_tag=old_locus_tag,
                    db_xref=db_xref,
                    gff_id=gff_id,
                    parent_ids=parent_ids,
                    gene_parent_id=gene_parent_id,
                    feature_type=str(feature.type),
                    feature_hash_start=hash_start,
                    feature_hash_end=hash_end,
                    feature_hash_strand=hash_strand,
                    feature_hash_parts=hash_parts,
                    location_operator=str(getattr(feature.location, "operator", None) or ""),
                    source_feature_position=feature_index,
                )
            )

        candidate_records.append(record_candidates)

    proteins_by_record: list[list[CdsProtein]] = []
    used_ids: set[str] = set()
    for record_candidates in candidate_records:
        record_proteins: list[CdsProtein] = []
        for candidate in record_candidates:
            fasta_safe_source_id = _fasta_safe_protein_id(candidate.source_protein_id)
            preferred_id = (
                fasta_safe_source_id
                if prefer_source_ids
                and fasta_safe_source_id is not None
                and source_id_counts.get(fasta_safe_source_id, 0) == 1
                else candidate.protein_id
            )
            protein_id = _unique_protein_id(preferred_id, candidate.protein_id, used_ids)
            cds_protein = CdsProtein(
                protein_id=protein_id,
                record_index=candidate.record_index,
                feature_index=candidate.feature_index,
                record_id=candidate.record_id,
                start=candidate.start,
                end=candidate.end,
                strand=candidate.strand,
                label=candidate.label,
                protein_length=candidate.protein_length,
                sequence=candidate.sequence,
                source_protein_id=candidate.source_protein_id,
                feature_svg_id=candidate.feature_svg_id,
                view_feature_svg_id=candidate.view_feature_svg_id,
                gene=candidate.gene,
                product=candidate.product,
                note=candidate.note,
                locus_tag=candidate.locus_tag,
                gene_id=candidate.gene_id,
                old_locus_tag=candidate.old_locus_tag,
                db_xref=candidate.db_xref,
                gff_id=candidate.gff_id,
                parent_ids=candidate.parent_ids,
                gene_parent_id=candidate.gene_parent_id,
                feature_type=candidate.feature_type,
                feature_hash_start=candidate.feature_hash_start,
                feature_hash_end=candidate.feature_hash_end,
                feature_hash_strand=candidate.feature_hash_strand,
                feature_hash_parts=candidate.feature_hash_parts,
                location_operator=candidate.location_operator,
                source_feature_position=candidate.source_feature_position,
            )
            record_proteins.append(cds_protein)
            protein_map[protein_id] = cds_protein
            used_ids.add(protein_id)

        proteins_by_record.append(record_proteins)

    return ProteinExtractionResult(
        proteins_by_record=proteins_by_record,
        protein_map=protein_map,
    )


def proteins_to_fasta(proteins: Sequence[CdsProtein]) -> str:
    """Return FASTA text for CDS proteins."""

    lines: list[str] = []
    for protein in proteins:
        lines.append(f">{protein.protein_id} {protein.label}")
        sequence = protein.sequence
        lines.extend(sequence[index : index + 80] for index in range(0, len(sequence), 80))
    return "\n".join(lines) + ("\n" if lines else "")


def _coerce_outfmt6_numeric_columns(df: DataFrame) -> DataFrame:
    coerced = df.copy()
    for column in _NUMERIC_COMPARISON_COLUMNS:
        coerced[column] = pd.to_numeric(coerced[column], errors="coerce")
    numeric = coerced[list(_NUMERIC_COMPARISON_COLUMNS)]
    try:
        all_finite = all(
            math.isfinite(float(value)) for value in numeric.to_numpy().flat
        )
    except (TypeError, ValueError, OverflowError):
        all_finite = False
    if numeric.isna().any(axis=None) or not all_finite:
        raise ParseError("LOSATP blastp output contains non-numeric outfmt 6 fields.")
    return coerced


def _is_strict_outfmt6_numeric_field(column: str, value: str) -> bool:
    pattern = (
        _STRICT_DECIMAL_INTEGER_RE
        if column in _INTEGER_COMPARISON_COLUMNS
        else _STRICT_DECIMAL_NUMBER_RE
    )
    if pattern.fullmatch(value) is None:
        return False
    try:
        return math.isfinite(float(value))
    except ValueError:  # pragma: no cover - the grammar excludes float parse failures
        return False


def parse_losatp_outfmt6(text: str) -> DataFrame:
    """Parse LOSATP blastp outfmt 6 text into the standard comparison columns."""

    data_lines = [
        line
        for line in text.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    if not data_lines:
        return pd.DataFrame(columns=COMPARISON_COLUMNS)
    for line in data_lines:
        columns = line.split("\t")
        if len(columns) != len(COMPARISON_COLUMNS):
            raise ParseError("LOSATP blastp output does not match outfmt 6 columns.")
        if any(
            not _is_strict_outfmt6_numeric_field(column, columns[index])
            for index, column in enumerate(COMPARISON_COLUMNS[2:], start=2)
        ):
            raise ParseError(
                "LOSATP blastp output contains non-numeric outfmt 6 fields."
            )
    try:
        df = pd.read_csv(
            StringIO("\n".join(data_lines)),
            sep="\t",
            names=COMPARISON_COLUMNS,
        )
    except Exception as exc:
        raise ParseError(f"Failed to parse LOSATP blastp output: {exc}") from exc

    if len(df.columns) != len(COMPARISON_COLUMNS):
        raise ParseError("LOSATP blastp output does not match outfmt 6 columns.")
    return _coerce_outfmt6_numeric_columns(df)


def _validate_max_hits(max_hits: int, *, option_name: str = "protein_blastp_max_hits") -> None:
    if int(max_hits) <= 0:
        raise ValidationError(f"{option_name} must be > 0")


def _validate_candidate_limit(candidate_limit: int | None) -> None:
    if candidate_limit is not None and int(candidate_limit) <= 0:
        raise ValidationError("protein_blastp_candidate_limit must be > 0 or None")


def _validate_losatp_threads(threads: int | None) -> None:
    if threads is not None and int(threads) <= 0:
        raise ValidationError("losatp_threads must be > 0 or None")


def normalize_protein_blastp_mode(mode: str | None) -> ProteinBlastpMode:
    """Return a validated LOSATP blastp mode."""

    normalized = str(mode or "none").strip().lower()
    if normalized not in PROTEIN_BLASTP_MODES:
        raise ValidationError(
            "protein_blastp_mode must be one of: "
            + ", ".join(PROTEIN_BLASTP_MODES)
        )
    return normalized  # type: ignore[return-value]


def normalize_orthogroup_membership_mode(mode: str | None) -> OrthogroupMembershipMode:
    """Return the active orthogroup inference model.

    Legacy user/session values are accepted as aliases so old configurations
    load without reactivating the removed inference modes.
    """

    normalized = str(mode or ORTHOGROUP_INFERENCE_VERSION).strip().lower().replace("-", "_")
    aliases = {
        "legacy": ORTHOGROUP_INFERENCE_VERSION,
        "rbh": ORTHOGROUP_INFERENCE_VERSION,
        "rbh_only": ORTHOGROUP_INFERENCE_VERSION,
        "merge": ORTHOGROUP_INFERENCE_VERSION,
        "family": ORTHOGROUP_INFERENCE_VERSION,
        "family_merge": ORTHOGROUP_INFERENCE_VERSION,
        "local_split": ORTHOGROUP_INFERENCE_VERSION,
        "density_split": ORTHOGROUP_INFERENCE_VERSION,
        "outparalog_split": ORTHOGROUP_INFERENCE_VERSION,
        "distribution_split": ORTHOGROUP_INFERENCE_VERSION,
        "orthogroups": ORTHOGROUP_INFERENCE_VERSION,
        "anchor_core": ORTHOGROUP_INFERENCE_VERSION,
    }
    normalized = aliases.get(normalized, normalized)
    if normalized not in ORTHOGROUP_MEMBERSHIP_MODES:
        raise ValidationError(
            "orthogroup_membership_mode must be "
            f"{ORTHOGROUP_INFERENCE_VERSION} or a legacy alias: "
            + ", ".join(_LEGACY_ORTHOGROUP_MEMBERSHIP_MODES)
        )
    return normalized  # type: ignore[return-value]


def _normalize_losatp_machine(machine: str | None = None) -> str:
    normalized = str(machine or platform.machine()).strip().lower()
    aliases = {
        "amd64": "x86_64",
        "x64": "x86_64",
        "arm64": "aarch64",
    }
    return aliases.get(normalized, normalized)


def _bundled_losatp_platform_dir() -> str | None:
    machine = _normalize_losatp_machine()
    if sys.platform.startswith("linux"):
        if machine == "x86_64":
            return "linux-x86_64"
        if machine == "aarch64":
            return "linux-aarch64"
    if sys.platform == "darwin":
        if machine == "x86_64":
            return "macos-x86_64"
        if machine == "aarch64":
            return "macos-arm64"
    if os.name == "nt":
        if machine == "x86_64":
            return "windows-x86_64"
        if machine == "aarch64":
            return "windows-arm64"
    return None


def _bundled_losatp_filename() -> str:
    return "losat.exe" if os.name == "nt" else "losat"


def _bundled_losatp_resource():
    platform_dir = _bundled_losatp_platform_dir()
    if platform_dir is None:
        return None
    try:
        package_root = resources.files("gbdraw")
    except (ModuleNotFoundError, FileNotFoundError):
        return None
    candidate = (
        package_root
        .joinpath(_BUNDLED_LOSATP_DIR)
        .joinpath(platform_dir)
        .joinpath(_bundled_losatp_filename())
    )
    if not candidate.is_file():
        return None
    return candidate


def _ensure_losatp_executable(path: Path) -> None:
    if os.name == "nt":
        return
    try:
        mode = path.stat().st_mode
    except OSError:
        return
    if mode & stat.S_IXUSR:
        return
    try:
        path.chmod(mode | stat.S_IXUSR)
    except OSError:
        logger.debug("Could not mark bundled LOSATP binary executable: %s", path)


def _path_executable(name: str) -> str | None:
    return shutil.which(str(name).strip())


def _protein_blastp_runtime_label(runtime: ProteinBlastpRuntime) -> str:
    if runtime.kind == "ncbi-blastp":
        return "NCBI BLAST+ blastp"
    return "LOSAT blastp"


def _protein_blastp_runtime_error(
    *,
    platform_dir: str | None,
    bundled_losat_found: bool,
    path_losat: str | None,
    path_blastp: str | None,
) -> ValidationError:
    platform_name = platform_dir or "this platform"
    bundled_status = (
        "a bundled LOSAT binary was found"
        if bundled_losat_found
        else f"no bundled LOSAT binary was found for {platform_name}"
    )
    losat_status = (
        f"`losat` was found on PATH at {path_losat}"
        if path_losat
        else "`losat` was not found on PATH"
    )
    blastp_status = (
        f"`blastp` was found on PATH at {path_blastp}"
        if path_blastp
        else "`blastp` was not found on PATH"
    )
    platform_note = ""
    if platform_dir and (platform_dir.startswith("macos-") or platform_dir.startswith("windows-")):
        platform_note = (
            " gbdraw does not currently include a LOSAT binary for this platform."
        )
    return ValidationError(
        "Protein BLASTP comparison needs LOSAT or NCBI BLAST+. "
        f"{bundled_status}, {losat_status}, and {blastp_status}. "
        "gbdraw currently bundles LOSAT only for Linux x86_64."
        f"{platform_note} "
        "Install NCBI BLAST+ and make `blastp` available on PATH, or pass a "
        "native LOSAT executable with --losatp_bin, or pass an NCBI BLAST+ "
        "executable with --ncbi_blastp_bin."
    )


def _resolve_protein_blastp_runtime(
    losatp_bin: str,
    ncbi_blastp_bin: str | None,
    stack: ExitStack,
) -> ProteinBlastpRuntime:
    requested_bin = str(losatp_bin or _DEFAULT_LOSATP_BIN).strip() or _DEFAULT_LOSATP_BIN
    requested_ncbi_bin = str(ncbi_blastp_bin or "").strip() or None
    if requested_bin != _DEFAULT_LOSATP_BIN and requested_ncbi_bin is not None:
        raise ValidationError(
            "Pass either --losatp_bin or --ncbi_blastp_bin for protein BLASTP comparisons, not both."
        )
    if requested_bin != _DEFAULT_LOSATP_BIN:
        runtime = ProteinBlastpRuntime("losat", requested_bin, "explicit")
        logger.debug("Using explicit LOSAT blastp runtime: %s", runtime.executable)
        return runtime
    if requested_ncbi_bin is not None:
        runtime = ProteinBlastpRuntime("ncbi-blastp", requested_ncbi_bin, "explicit")
        logger.debug("Using explicit NCBI BLAST+ blastp runtime: %s", runtime.executable)
        return runtime

    bundled_resource = _bundled_losatp_resource()
    if bundled_resource is not None:
        bundled_path = stack.enter_context(resources.as_file(bundled_resource))
        _ensure_losatp_executable(bundled_path)
        runtime = ProteinBlastpRuntime("losat", str(bundled_path), "bundled")
        logger.debug("Using bundled LOSAT blastp runtime: %s", runtime.executable)
        return runtime

    path_losat = _path_executable(_DEFAULT_LOSATP_BIN)
    if path_losat is not None:
        runtime = ProteinBlastpRuntime("losat", path_losat, "path")
        logger.debug("Using PATH LOSAT blastp runtime: %s", runtime.executable)
        return runtime

    path_blastp = _path_executable("blastp")
    if path_blastp is not None:
        runtime = ProteinBlastpRuntime("ncbi-blastp", path_blastp, "path")
        logger.debug("Using PATH NCBI BLAST+ blastp runtime: %s", runtime.executable)
        return runtime

    raise _protein_blastp_runtime_error(
        platform_dir=_bundled_losatp_platform_dir(),
        bundled_losat_found=False,
        path_losat=path_losat,
        path_blastp=path_blastp,
    )


def _validate_comparison_columns(hits: DataFrame) -> None:
    missing_columns = set(COMPARISON_COLUMNS).difference(hits.columns)
    if missing_columns:
        raise ParseError(
            "LOSATP blastp output is missing required columns: "
            + ", ".join(sorted(missing_columns))
        )


def filter_protein_hits_by_thresholds(
    hits: DataFrame,
    *,
    evalue: float,
    bitscore: float,
    identity: float,
    alignment_length: int,
) -> DataFrame:
    """Keep LOSATP blastp hits that pass visible pairwise-match thresholds."""

    if hits.empty:
        return hits.copy()
    _validate_comparison_columns(hits)

    try:
        evalue_threshold = float(evalue)
        bitscore_threshold = float(bitscore)
        identity_threshold = float(identity)
        alignment_length_threshold = int(alignment_length)
    except (TypeError, ValueError) as exc:
        raise ValidationError("protein colinearity thresholds must be numeric") from exc
    if alignment_length_threshold < 0:
        raise ValidationError("alignment_length must be >= 0")

    coerced_hits = _coerce_outfmt6_numeric_columns(hits)
    return coerced_hits.loc[
        (coerced_hits["evalue"] <= evalue_threshold)
        & (coerced_hits["bitscore"] >= bitscore_threshold)
        & (coerced_hits["identity"] >= identity_threshold)
        & (coerced_hits["alignment_length"] >= alignment_length_threshold)
    ].reset_index(drop=True)


def _sort_hits_for_query_best(hits: DataFrame) -> DataFrame:
    return hits.sort_values(
        ["query", "bitscore", "evalue", "identity", "alignment_length", "subject"],
        ascending=[True, False, True, False, False, True],
        kind="mergesort",
    )


def _sort_hits_for_subject_best(hits: DataFrame) -> DataFrame:
    return hits.sort_values(
        ["subject", "bitscore", "evalue", "identity", "alignment_length", "query"],
        ascending=[True, False, True, False, False, True],
        kind="mergesort",
    )


def select_top_hits_per_query(
    hits: DataFrame,
    *,
    max_hits: int,
) -> DataFrame:
    """Keep the strongest distinct subject protein hits per query protein."""

    _validate_max_hits(max_hits)
    if hits.empty:
        return hits.copy()
    _validate_comparison_columns(hits)

    sorted_hits = _sort_hits_for_query_best(_coerce_outfmt6_numeric_columns(hits))
    sorted_hits = sorted_hits.drop_duplicates(["query", "subject"], keep="first")
    return (
        sorted_hits.groupby("query", group_keys=False, sort=False)
        .head(int(max_hits))
        .reset_index(drop=True)
    )


def _select_member_candidate_hits_per_query(
    hits: DataFrame,
    *,
    max_hits: int | None,
) -> DataFrame:
    """Keep every HSP for the strongest distinct member candidates."""

    if max_hits is None:
        _validate_comparison_columns(hits)
        return hits.copy().reset_index(drop=True)
    selected_pairs = select_top_hits_per_query(hits, max_hits=max_hits)
    if selected_pairs.empty:
        return hits.iloc[0:0].copy()
    pair_index = pd.MultiIndex.from_frame(selected_pairs[["query", "subject"]])
    hit_index = pd.MultiIndex.from_frame(hits[["query", "subject"]])
    return hits.loc[hit_index.isin(pair_index)].reset_index(drop=True)


def select_reciprocal_best_hits(hits: DataFrame) -> DataFrame:
    """Keep query-subject pairs that are mutual best hits in one adjacent-pair table."""

    if hits.empty:
        return hits.copy()
    _validate_comparison_columns(hits)

    coerced_hits = _coerce_outfmt6_numeric_columns(hits)
    query_best = (
        _sort_hits_for_query_best(coerced_hits)
        .drop_duplicates(["query", "subject"], keep="first")
        .drop_duplicates("query", keep="first")
    )
    subject_best = (
        _sort_hits_for_subject_best(coerced_hits)
        .drop_duplicates(["query", "subject"], keep="first")
        .drop_duplicates("subject", keep="first")
    )
    reciprocal_pairs = {
        (str(row.query), str(row.subject))
        for row in subject_best.itertuples(index=False)
    }
    return query_best.loc[
        [
            (str(row.query), str(row.subject)) in reciprocal_pairs
            for row in query_best.itertuples(index=False)
        ]
    ].reset_index(drop=True)


def select_best_hits_per_query(
    hits: DataFrame,
) -> DataFrame:
    """Choose the deterministic best subject for each query protein."""

    if hits.empty:
        return hits.copy()
    _validate_comparison_columns(hits)

    return (
        _sort_hits_for_query_best(_coerce_outfmt6_numeric_columns(hits))
        .drop_duplicates(["query", "subject"], keep="first")
        .drop_duplicates("query", keep="first")
        .reset_index(drop=True)
    )


def select_reciprocal_best_hit_edges(
    forward_hits: DataFrame,
    reverse_hits: DataFrame,
) -> DataFrame:
    """Keep RBH edges from directional best-hit tables.

    Returned rows use the forward orientation: query record i, subject record j.
    """

    if forward_hits.empty or reverse_hits.empty:
        return forward_hits.iloc[0:0].copy()

    forward_best = select_best_hits_per_query(forward_hits)
    reverse_best = select_best_hits_per_query(reverse_hits)
    reverse_best_by_query = {
        str(row.query): str(row.subject)
        for row in reverse_best.itertuples(index=False)
    }
    keep_mask = [
        reverse_best_by_query.get(str(row.subject)) == str(row.query)
        for row in forward_best.itertuples(index=False)
    ]
    return forward_best.loc[keep_mask].reset_index(drop=True)


def _normalized_score_from_row(row: object) -> float:
    score = _row_float(row, "normalized_score", 0.0)
    return score if math.isfinite(score) and score > 0.0 else 0.0


def _select_normalized_fit_rows(
    normalized_hits: DataFrame,
    *,
    top_fraction: float,
) -> list[tuple[float, float]]:
    if normalized_hits.empty:
        return []
    sorted_hits = normalized_hits.sort_values(
        ["length_product", "query", "subject"],
        ascending=[True, True, True],
        kind="mergesort",
    )
    bin_size = max(4, int(math.ceil(len(sorted_hits) / 8)))
    fit_points: list[tuple[float, float]] = []
    for start_index in range(0, len(sorted_hits), bin_size):
        bin_hits = sorted_hits.iloc[start_index : start_index + bin_size]
        top_count = max(1, int(math.ceil(len(bin_hits) * float(top_fraction))))
        top_hits = bin_hits.sort_values(
            ["bitscore", "query", "subject"],
            ascending=[False, True, True],
            kind="mergesort",
        ).head(top_count)
        for row in top_hits.itertuples(index=False):
            length_product = _row_float(row, "length_product", 0.0)
            bitscore = _row_float(row, "bitscore", 0.0)
            if length_product <= 0.0 or bitscore <= 0.0:
                continue
            fit_points.append((math.log10(length_product), math.log10(bitscore)))
    return fit_points


def _fit_expected_bitscore_model(
    normalized_hits: DataFrame,
    *,
    top_fraction: float,
) -> tuple[float, float] | None:
    if len(normalized_hits) < _ORTHOGROUP_SPLIT_MIN_FIT_HITS:
        return None
    fit_points = _select_normalized_fit_rows(
        normalized_hits,
        top_fraction=top_fraction,
    )
    if len(fit_points) < 3:
        return None
    x_values = [point[0] for point in fit_points]
    y_values = [point[1] for point in fit_points]
    if len(set(round(value, 9) for value in x_values)) < 2:
        return None
    x_mean = sum(x_values) / len(x_values)
    y_mean = sum(y_values) / len(y_values)
    denominator = sum((x_value - x_mean) ** 2 for x_value in x_values)
    if denominator <= _ORTHOGROUP_SPLIT_EPSILON:
        return None
    slope = sum(
        (x_value - x_mean) * (y_value - y_mean)
        for x_value, y_value in zip(x_values, y_values)
    ) / denominator
    intercept = y_mean - slope * x_mean
    if not (math.isfinite(slope) and math.isfinite(intercept)):
        return None
    return slope, intercept


def _empty_normalized_hit_table(columns: Sequence[str]) -> DataFrame:
    extra_columns = (
        "query_length",
        "subject_length",
        "length_product",
        "hsp_count",
        "query_covered_length",
        "subject_covered_length",
        "query_coverage",
        "subject_coverage",
        "min_coverage",
        "representative_alignment_length",
        "total_hsp_alignment_length",
        "coverage_source",
        "normalized_score",
        "normalization_fallback",
        "record_pair_normalization_source",
        "domain_only",
    )
    return pd.DataFrame(columns=tuple(dict.fromkeys([*columns, *extra_columns])))


def _coverage_coordinate(value: object) -> int | None:
    try:
        coordinate = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(coordinate):
        return None
    return int(coordinate)


def _coverage_interval_from_hsp(start: object, end: object, length: int) -> tuple[int, int] | None:
    if int(length) <= 0:
        return None
    start_coordinate = _coverage_coordinate(start)
    end_coordinate = _coverage_coordinate(end)
    if start_coordinate is None or end_coordinate is None:
        return None
    low = min(start_coordinate, end_coordinate)
    high = max(start_coordinate, end_coordinate)
    clamped_low = max(1, low)
    clamped_high = min(int(length), high)
    if clamped_low > clamped_high:
        return None
    return clamped_low, clamped_high


def _merge_coverage_intervals(intervals: Sequence[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    cleaned = sorted(
        (int(start), int(end))
        for start, end in intervals
        if int(start) <= int(end)
    )
    if not cleaned:
        return ()
    merged: list[tuple[int, int]] = []
    current_start, current_end = cleaned[0]
    for start, end in cleaned[1:]:
        if start <= current_end + 1:
            current_end = max(current_end, end)
            continue
        merged.append((current_start, current_end))
        current_start, current_end = start, end
    merged.append((current_start, current_end))
    return tuple(merged)


def _covered_length(intervals: Sequence[tuple[int, int]]) -> int:
    return sum(
        max(0, int(end) - int(start) + 1)
        for start, end in _merge_coverage_intervals(intervals)
    )


def _raw_hsp_coordinate_rank(row: object, column: str) -> int:
    coordinate = _coverage_coordinate(getattr(row, column, None))
    return coordinate if coordinate is not None else sys.maxsize


def _raw_hsp_representative_rank(row: object, row_index: int) -> tuple[float, float, float, int, int, int, int, int, int]:
    return (
        -_row_float(row, "bitscore", 0.0),
        _row_float(row, "evalue", float("inf")),
        -_row_float(row, "identity", 0.0),
        -int(_row_float(row, "alignment_length", 0.0)),
        _raw_hsp_coordinate_rank(row, "qstart"),
        _raw_hsp_coordinate_rank(row, "qend"),
        _raw_hsp_coordinate_rank(row, "sstart"),
        _raw_hsp_coordinate_rank(row, "send"),
        int(row_index),
    )


@dataclass(slots=True)
class _HspPairAccumulator:
    query_length: int
    subject_length: int
    representative_row: object = None
    representative_rank: tuple[float | int, ...] = ()
    rank_error: ValueError | OverflowError | None = None
    query_intervals: list[tuple[int, int]] = field(default_factory=list)
    subject_intervals: list[tuple[int, int]] = field(default_factory=list)
    hsp_count: int = 0
    total_alignment_length: int = 0


def _aggregate_hsps_by_protein_pair(
    hits: DataFrame,
    protein_map: Mapping[str, CdsProtein],
) -> DataFrame:
    if hits is None or hits.empty:
        columns = tuple(hits.columns) if hits is not None else tuple(COMPARISON_COLUMNS)
        return _empty_normalized_hit_table(columns)

    # Table-level grouping retains pandas' ID coercion, missing-ID handling
    # and pair order. It does not construct a DataFrame for each pair.
    pairs: dict[tuple[object, object], _HspPairAccumulator] = {}
    for (query_id, subject_id), hsp_count in hits.groupby(
        ["query", "subject"], sort=False, observed=True,
    ).size().items():
        query_protein = protein_map.get(str(query_id))
        subject_protein = protein_map.get(str(subject_id))
        if query_protein is None or subject_protein is None:
            continue
        query_length = int(query_protein.protein_length)
        subject_length = int(subject_protein.protein_length)
        if query_length <= 0 or subject_length <= 0:
            continue
        pairs[(query_id, subject_id)] = _HspPairAccumulator(
            query_length, subject_length, hsp_count=int(hsp_count),
        )

    for row_index, hsp_row in enumerate(hits.itertuples(index=False)):
        accumulator = pairs.get((hsp_row.query, hsp_row.subject))
        if accumulator is None or accumulator.rank_error is not None:
            continue
        try:
            rank = _raw_hsp_representative_rank(hsp_row, row_index)
        except (ValueError, OverflowError) as error:
            # Direct private callers can bypass numeric validation. Preserve
            # the old first-pair error order even when HSPs are interleaved.
            accumulator.rank_error = error
            continue
        if accumulator.representative_row is None or rank < accumulator.representative_rank:
            accumulator.representative_row = hsp_row
            accumulator.representative_rank = rank

        alignment_length = _row_float(hsp_row, "alignment_length", 0.0)
        if math.isfinite(alignment_length) and alignment_length > 0:
            accumulator.total_alignment_length += int(alignment_length)
        query_interval = _coverage_interval_from_hsp(
            getattr(hsp_row, "qstart", None),
            getattr(hsp_row, "qend", None),
            accumulator.query_length,
        )
        if query_interval is not None:
            accumulator.query_intervals.append(query_interval)
        subject_interval = _coverage_interval_from_hsp(
            getattr(hsp_row, "sstart", None),
            getattr(hsp_row, "send", None),
            accumulator.subject_length,
        )
        if subject_interval is not None:
            accumulator.subject_intervals.append(subject_interval)

    rows: list[dict[str, object]] = []
    # Dict insertion order retains pair appearance; global row ranks retain
    # pair-local order on complete ties. Interval sorting remains in the helper.
    for accumulator in pairs.values():
        if accumulator.rank_error is not None:
            raise accumulator.rank_error
        query_length = accumulator.query_length
        subject_length = accumulator.subject_length
        representative_row = accumulator.representative_row
        bitscore = _row_float(representative_row, "bitscore", 0.0)
        representative_alignment_length = int(_row_float(representative_row, "alignment_length", 0.0))
        if bitscore <= 0.0 or representative_alignment_length <= 0:
            continue

        query_covered_length = _covered_length(accumulator.query_intervals)
        subject_covered_length = _covered_length(accumulator.subject_intervals)
        query_coverage = min(1.0, float(query_covered_length) / float(query_length))
        subject_coverage = min(1.0, float(subject_covered_length) / float(subject_length))
        min_hit_coverage = min(query_coverage, subject_coverage)

        record = dict(representative_row._asdict())
        record.update(
            {
                "query_length": query_length,
                "subject_length": subject_length,
                "length_product": float(query_length * subject_length),
                "hsp_count": int(accumulator.hsp_count),
                "query_covered_length": int(query_covered_length),
                "subject_covered_length": int(subject_covered_length),
                "query_coverage": query_coverage,
                "subject_coverage": subject_coverage,
                "min_coverage": min_hit_coverage,
                "representative_alignment_length": int(representative_alignment_length),
                "total_hsp_alignment_length": int(accumulator.total_alignment_length),
                "coverage_source": "hsp_union",
            }
        )
        rows.append(record)

    pairs.clear()
    if not rows:
        return _empty_normalized_hit_table(tuple(hits.columns))
    return pd.DataFrame.from_records(rows)


def _normalize_directional_hit_table(
    hits: DataFrame,
    protein_map: Mapping[str, CdsProtein],
    *,
    top_fraction: float = _ORTHOGROUP_SPLIT_TOP_FRACTION,
    min_coverage: float = _ORTHOGROUP_SPLIT_MIN_COVERAGE,
) -> DataFrame:
    if hits is None or hits.empty:
        columns = tuple(hits.columns) if hits is not None else tuple(COMPARISON_COLUMNS)
        return _empty_normalized_hit_table(columns)
    _validate_comparison_columns(hits)
    coerced_hits = _coerce_outfmt6_numeric_columns(hits)
    aggregated_hits = _aggregate_hsps_by_protein_pair(coerced_hits, protein_map)
    if aggregated_hits.empty:
        return _empty_normalized_hit_table(tuple(coerced_hits.columns))

    normalized_hits = aggregated_hits.loc[
        aggregated_hits["min_coverage"].astype(float) >= float(min_coverage)
    ].reset_index(drop=True)
    if normalized_hits.empty:
        return _empty_normalized_hit_table(tuple(coerced_hits.columns))

    model = _fit_expected_bitscore_model(
        normalized_hits,
        top_fraction=top_fraction,
    )
    fallback = model is None
    normalized_scores: list[float] = []
    for row in normalized_hits.itertuples(index=False):
        bitscore = _row_float(row, "bitscore", 0.0)
        length_product = _row_float(row, "length_product", 0.0)
        if fallback:
            denominator = math.sqrt(max(length_product, _ORTHOGROUP_SPLIT_EPSILON))
            normalized_scores.append(bitscore / denominator)
            continue
        slope, intercept = model
        expected_bitscore = 10 ** (slope * math.log10(length_product) + intercept)
        if not math.isfinite(expected_bitscore) or expected_bitscore <= 0.0:
            denominator = math.sqrt(max(length_product, _ORTHOGROUP_SPLIT_EPSILON))
            normalized_scores.append(bitscore / denominator)
        else:
            normalized_scores.append(bitscore / expected_bitscore)
    normalized_hits["normalized_score"] = normalized_scores
    normalized_hits["normalization_fallback"] = bool(fallback)
    normalized_hits["record_pair_normalization_source"] = (
        "sqrt_length_fallback" if fallback else "fit"
    )
    normalized_hits["domain_only"] = normalized_hits["min_coverage"].astype(float) <= _DOMAIN_ONLY_MAX_MIN_COVERAGE
    return normalized_hits.reset_index(drop=True)


def _normalize_directional_hit_tables(
    directional_tables: Mapping[tuple[int, int], DataFrame],
    protein_map: Mapping[str, CdsProtein],
    *,
    min_coverage: float = _ORTHOGROUP_SPLIT_MIN_COVERAGE,
) -> dict[tuple[int, int], DataFrame]:
    return {
        (int(pair[0]), int(pair[1])): _normalize_directional_hit_table(
            hits,
            protein_map,
            min_coverage=float(min_coverage),
        )
        for pair, hits in directional_tables.items()
    }


def _comparison_columns_only(hits: DataFrame) -> DataFrame:
    if hits.empty:
        return pd.DataFrame(columns=COMPARISON_COLUMNS)
    return hits.loc[:, list(COMPARISON_COLUMNS)].copy()


class _UnionFind:
    def __init__(self) -> None:
        self._parent: dict[str, str] = {}

    def add(self, item: str) -> None:
        if item not in self._parent:
            self._parent[item] = item

    def find(self, item: str) -> str:
        self.add(item)
        parent = self._parent[item]
        if parent != item:
            parent = self.find(parent)
            self._parent[item] = parent
        return parent

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root == right_root:
            return
        if right_root < left_root:
            left_root, right_root = right_root, left_root
        self._parent[right_root] = left_root


def _row_float(row: object, column: str, default: float = 0.0) -> float:
    try:
        return float(getattr(row, column))
    except (TypeError, ValueError, AttributeError):
        return float(default)


def _member_rank_from_row(row: object) -> tuple[float, float, float, float]:
    return (
        _row_float(row, "bitscore", 0.0),
        _row_float(row, "evalue", float("inf")),
        _row_float(row, "identity", 0.0),
        _row_float(row, "alignment_length", 0.0),
    )


def _is_better_member_rank(
    candidate: tuple[float, float, float, float],
    current: tuple[float, float, float, float] | None,
) -> bool:
    if current is None:
        return True
    return (
        candidate[0] > current[0]
        or (candidate[0] == current[0] and candidate[1] < current[1])
        or (
            candidate[0] == current[0]
            and candidate[1] == current[1]
            and candidate[2] > current[2]
        )
        or (
            candidate[0] == current[0]
            and candidate[1] == current[1]
            and candidate[2] == current[2]
            and candidate[3] > current[3]
        )
    )


def _protein_sort_key(protein: CdsProtein) -> tuple[int, int, int, str]:
    return (
        int(protein.record_index),
        int(protein.start),
        int(protein.end),
        str(protein.protein_id),
    )


_ORTHOGROUP_NAME_SOURCE_WEIGHTS = {
    "gene": 80,
    "product": 55,
    "note": 35,
    "label": 10,
}
_ORTHOGROUP_NAME_SOURCE_ORDER = ("gene", "product", "note", "label")
_ORTHOGROUP_NAME_SOURCE_RANK = {
    source: index for index, source in enumerate(_ORTHOGROUP_NAME_SOURCE_ORDER)
}
_NOTE_PREFIX_RE = re.compile(r"^(?:product|gene|note)\s*:\s*", re.IGNORECASE)
_DUF_CANDIDATE_RE = re.compile(r"\bDUF\d+\b.*\bdomain-containing protein\b", re.IGNORECASE)
_ANNOTATION_PROVENANCE_NOTE_RE = re.compile(
    r"^derived by automated computational analysis\b",
    re.IGNORECASE,
)
_GENERIC_ORTHOGROUP_NAME_CANDIDATES = {
    "hypothetical protein",
    "uncharacterized protein",
    "unknown protein",
    "predicted protein",
    "putative protein",
}
_WEAK_ORTHOGROUP_NAME_CANDIDATES = {
    "hypothetical protein",
    "uncharacterized protein",
    "unknown protein",
    "predicted protein",
    "putative protein",
}


def _normalize_orthogroup_name_text(
    text: str | None,
    source: str,
) -> tuple[str, str] | None:
    if text is None:
        return None
    normalized = re.sub(r"\s+", " ", str(text)).strip()
    normalized = _NOTE_PREFIX_RE.sub("", normalized).strip()
    normalized = normalized.strip(" \t\r\n.,;:()[]{}")
    if not normalized:
        return None
    if source == "note" and _ANNOTATION_PROVENANCE_NOTE_RE.search(normalized):
        return None
    compact_length = len(re.sub(r"[^0-9A-Za-z]+", "", normalized))
    if source != "gene" and compact_length < 4:
        return None
    key = normalized.casefold()
    if key in _GENERIC_ORTHOGROUP_NAME_CANDIDATES:
        return None
    return key, normalized


def _is_weak_orthogroup_name_candidate(text: str, source: str) -> bool:
    normalized = re.sub(r"\s+", " ", str(text)).strip().casefold()
    if source == "label":
        return True
    if normalized in _WEAK_ORTHOGROUP_NAME_CANDIDATES:
        return True
    return bool(_DUF_CANDIDATE_RE.search(text))


def _member_annotation_value(member: OrthogroupMember, source: str) -> str | None:
    if source == "product":
        return member.product
    if source == "gene":
        return member.gene
    if source == "note":
        return member.note
    if source == "label":
        return member.label
    return None


def _iter_orthogroup_name_candidates(
    members: Sequence[OrthogroupMember],
    *,
    include_label: bool,
) -> list[OrthogroupNameCandidate]:
    candidate_sources = _ORTHOGROUP_NAME_SOURCE_ORDER if include_label else _ORTHOGROUP_NAME_SOURCE_ORDER[:-1]
    accumulators: dict[str, dict[str, object]] = {}

    for member in members:
        member_id = str(member.protein_id)
        for source in candidate_sources:
            normalized = _normalize_orthogroup_name_text(
                _member_annotation_value(member, source),
                source,
            )
            if normalized is None:
                continue
            key, display_text = normalized
            source_weight = _ORTHOGROUP_NAME_SOURCE_WEIGHTS[source]
            source_rank = _ORTHOGROUP_NAME_SOURCE_RANK[source]
            accumulator = accumulators.setdefault(
                key,
                {
                    "text": display_text,
                    "source": source,
                    "source_weight": source_weight,
                    "source_rank": source_rank,
                    "members": set(),
                    "records": set(),
                    "representatives": set(),
                    "weak": _is_weak_orthogroup_name_candidate(display_text, source),
                },
            )
            if (
                source_weight > int(accumulator["source_weight"])
                or (
                    source_weight == int(accumulator["source_weight"])
                    and source_rank < int(accumulator["source_rank"])
                )
            ):
                accumulator["text"] = display_text
                accumulator["source"] = source
                accumulator["source_weight"] = source_weight
                accumulator["source_rank"] = source_rank
            if not _is_weak_orthogroup_name_candidate(display_text, source):
                accumulator["weak"] = False
            members_set = accumulator["members"]
            records_set = accumulator["records"]
            representatives_set = accumulator["representatives"]
            if isinstance(members_set, set):
                members_set.add(member_id)
            if isinstance(records_set, set):
                records_set.add(int(member.record_index))
            if member.representative and isinstance(representatives_set, set):
                representatives_set.add(member_id)

    candidates: list[OrthogroupNameCandidate] = []
    for accumulator in accumulators.values():
        members_set = accumulator["members"]
        records_set = accumulator["records"]
        representatives_set = accumulator["representatives"]
        member_count = len(members_set) if isinstance(members_set, set) else 0
        record_coverage_count = len(records_set) if isinstance(records_set, set) else 0
        representative_count = len(representatives_set) if isinstance(representatives_set, set) else 0
        source_weight = int(accumulator["source_weight"])
        weak_penalty = 45 if bool(accumulator["weak"]) else 0
        score = (
            source_weight
            + member_count * 10
            + record_coverage_count * 20
            + representative_count * 5
            - weak_penalty
        )
        candidates.append(
            OrthogroupNameCandidate(
                text=str(accumulator["text"]),
                source=str(accumulator["source"]),
                member_count=member_count,
                record_coverage_count=record_coverage_count,
                representative_count=representative_count,
                score=float(score),
            )
        )

    return sorted(candidates, key=_orthogroup_name_candidate_sort_key)


def _orthogroup_name_candidate_sort_key(
    candidate: OrthogroupNameCandidate,
) -> tuple[int, float, int, int, int, str]:
    gene_priority = (
        candidate.source == "gene"
        and not _is_weak_orthogroup_name_candidate(candidate.text, candidate.source)
        and (
            candidate.record_coverage_count >= 2
            or candidate.representative_count > 0
        )
    )
    return (
        0 if gene_priority else 1,
        -candidate.score,
        _ORTHOGROUP_NAME_SOURCE_RANK.get(candidate.source, 99),
        -candidate.record_coverage_count,
        -candidate.member_count,
        candidate.text.casefold(),
    )


def _orthogroup_name_confidence(
    candidate: OrthogroupNameCandidate | None,
) -> str:
    if candidate is None:
        return "none"
    if _is_weak_orthogroup_name_candidate(candidate.text, candidate.source):
        return "low"
    if candidate.member_count <= 1:
        return "low"
    if candidate.record_coverage_count >= 2:
        return "high"
    return "medium"


def _orthogroup_description(
    candidate: OrthogroupNameCandidate | None,
    confidence: str,
    total_record_coverage: int,
) -> str:
    if candidate is None or confidence in {"none", "low"}:
        return "No informative product/gene/note consensus was found."
    record_word = "record" if total_record_coverage == 1 else "records"
    return (
        f"Suggested from {candidate.source} annotations in "
        f"{candidate.record_coverage_count} of {total_record_coverage} {record_word}."
    )


def _build_orthogroup_name_metadata(
    orthogroups: Mapping[str, Sequence[OrthogroupMember]],
) -> tuple[
    dict[str, str],
    dict[str, str],
    dict[str, list[OrthogroupNameCandidate]],
    dict[str, str],
]:
    names_by_orthogroup_id: dict[str, str] = {}
    descriptions_by_orthogroup_id: dict[str, str] = {}
    name_candidates_by_orthogroup_id: dict[str, list[OrthogroupNameCandidate]] = {}
    confidence_by_orthogroup_id: dict[str, str] = {}

    for orthogroup_id, members in orthogroups.items():
        annotation_candidates = _iter_orthogroup_name_candidates(members, include_label=False)
        candidates = annotation_candidates or _iter_orthogroup_name_candidates(members, include_label=True)
        top_candidate = candidates[0] if candidates else None
        total_record_coverage = len({int(member.record_index) for member in members})
        confidence = _orthogroup_name_confidence(top_candidate)

        if top_candidate is not None and confidence not in {"none", "low"}:
            names_by_orthogroup_id[orthogroup_id] = top_candidate.text
        descriptions_by_orthogroup_id[orthogroup_id] = _orthogroup_description(
            top_candidate,
            confidence,
            total_record_coverage,
        )
        name_candidates_by_orthogroup_id[orthogroup_id] = candidates
        confidence_by_orthogroup_id[orthogroup_id] = confidence

    return (
        names_by_orthogroup_id,
        descriptions_by_orthogroup_id,
        name_candidates_by_orthogroup_id,
        confidence_by_orthogroup_id,
    )



def _make_orthogroup_member(
    orthogroup_id: str,
    protein: CdsProtein,
    *,
    representative: bool,
    role: OrthogroupMemberRole = "anchor",
    confidence: OrthogroupMemberConfidence = "high",
    assignment_reason: str = "",
    supporting_edges: Sequence[str] = (),
    best_core_support: float = 0.0,
    second_best_core_support: float = 0.0,
) -> OrthogroupMember:
    return OrthogroupMember(
        orthogroup_id=orthogroup_id,
        protein_id=protein.protein_id,
        record_index=protein.record_index,
        feature_index=protein.feature_index,
        record_id=protein.record_id,
        label=protein.label,
        start=protein.start,
        end=protein.end,
        strand=protein.strand,
        feature_svg_id=protein.feature_svg_id,
        source_protein_id=protein.source_protein_id,
        gene=protein.gene,
        product=protein.product,
        note=protein.note,
        representative=representative,
        role=role,
        confidence=confidence,
        assignment_reason=assignment_reason,
        supporting_edges=tuple(str(edge_id) for edge_id in supporting_edges),
        best_core_support=float(best_core_support),
        second_best_core_support=float(second_best_core_support),
    )


def _orthogroup_result_from_member_ids(
    group_member_ids: Mapping[str, set[str]],
    representative_ids_by_group: Mapping[str, set[str]],
    protein_map: Mapping[str, CdsProtein],
    *,
    group_order: Sequence[str],
    rbh_orthogroups: Mapping[str, Sequence[str]],
    ortholog_edges_by_orthogroup_id: Mapping[str, Sequence[OrthologEdge]],
    path_indexes_by_orthogroup_id: Mapping[str, OrthologPathCollection],
    related_edges_by_orthogroup_id: Mapping[str, Sequence[OrthologEdge]],
    member_roles_by_protein_id: Mapping[str, OrthogroupMemberRole] | None = None,
    member_confidence_by_protein_id: Mapping[str, OrthogroupMemberConfidence] | None = None,
    assignment_reason_by_protein_id: Mapping[str, str] | None = None,
    supporting_edges_by_protein_id: Mapping[str, Sequence[str]] | None = None,
    best_core_support_by_protein_id: Mapping[str, float] | None = None,
    second_best_core_support_by_protein_id: Mapping[str, float] | None = None,
    scope_by_orthogroup_id: Mapping[str, OrthogroupScope] | None = None,
    source_record_index_by_orthogroup_id: Mapping[str, int] | None = None,
) -> OrthogroupGraphResult:
    orthogroups: dict[str, list[OrthogroupMember]] = {}
    member_by_protein_id: dict[str, OrthogroupMember] = {}
    ordered_group_ids = [
        group_id
        for group_id in group_order
        if group_id in group_member_ids and group_member_ids[group_id]
    ]
    remaining_group_ids = sorted(
        set(group_member_ids).difference(ordered_group_ids),
        key=lambda group_id: min(
            _protein_sort_key(protein_map[member_id])
            for member_id in group_member_ids[group_id]
            if member_id in protein_map
        ),
    )
    for group_id in [*ordered_group_ids, *remaining_group_ids]:
        member_ids = sorted(
            group_member_ids[group_id],
            key=lambda member_id: _protein_sort_key(protein_map[member_id]),
        )
        representative_ids = representative_ids_by_group.get(group_id, set())
        members: list[OrthogroupMember] = []
        for member_id in member_ids:
            protein = protein_map[member_id]
            member = _make_orthogroup_member(
                group_id,
                protein,
                representative=member_id in representative_ids,
                role=(member_roles_by_protein_id or {}).get(member_id, "anchor"),
                confidence=(member_confidence_by_protein_id or {}).get(member_id, "high"),
                assignment_reason=(assignment_reason_by_protein_id or {}).get(member_id, ""),
                supporting_edges=(supporting_edges_by_protein_id or {}).get(member_id, ()),
                best_core_support=(best_core_support_by_protein_id or {}).get(member_id, 0.0),
                second_best_core_support=(second_best_core_support_by_protein_id or {}).get(member_id, 0.0),
            )
            members.append(member)
            member_by_protein_id[member_id] = member
        orthogroups[group_id] = members

    (
        names_by_orthogroup_id,
        descriptions_by_orthogroup_id,
        name_candidates_by_orthogroup_id,
        confidence_by_orthogroup_id,
    ) = _build_orthogroup_name_metadata(orthogroups)

    return OrthogroupGraphResult(
        orthogroups=orthogroups,
        member_by_protein_id=member_by_protein_id,
        names_by_orthogroup_id=names_by_orthogroup_id,
        descriptions_by_orthogroup_id=descriptions_by_orthogroup_id,
        name_candidates_by_orthogroup_id=name_candidates_by_orthogroup_id,
        confidence_by_orthogroup_id=confidence_by_orthogroup_id,
        rbh_orthogroups={
            str(key): tuple(str(protein_id) for protein_id in value)
            for key, value in rbh_orthogroups.items()
        },
        ortholog_edges_by_orthogroup_id={
            str(key): tuple(value)
            for key, value in ortholog_edges_by_orthogroup_id.items()
        },
        path_indexes_by_orthogroup_id=dict(path_indexes_by_orthogroup_id),
        related_edges_by_orthogroup_id={
            str(key): tuple(value)
            for key, value in related_edges_by_orthogroup_id.items()
        },
        scope_by_orthogroup_id={
            group_id: (scope_by_orthogroup_id or {}).get(group_id, "cross_record")
            for group_id in orthogroups
        },
        source_record_index_by_orthogroup_id={
            str(group_id): int(source_record_index_by_orthogroup_id[group_id])
            for group_id in orthogroups
            if source_record_index_by_orthogroup_id is not None
            and group_id in source_record_index_by_orthogroup_id
        },
    )


def _canonical_edge_endpoint_ids(
    query_id: str,
    subject_id: str,
    protein_map: Mapping[str, CdsProtein],
) -> tuple[str, str]:
    query_protein = protein_map[query_id]
    subject_protein = protein_map[subject_id]
    if int(query_protein.record_index) < int(subject_protein.record_index):
        return query_id, subject_id
    if int(query_protein.record_index) > int(subject_protein.record_index):
        return subject_id, query_id
    return tuple(sorted((query_id, subject_id)))  # type: ignore[return-value]


def _make_ortholog_edge(
    *,
    orthogroup_id: str,
    source_rbh_orthogroup_id: str | None,
    target_rbh_orthogroup_id: str | None,
    query_id: str,
    subject_id: str,
    row: object,
    protein_map: Mapping[str, CdsProtein],
    edge_kind: OrthologEdgeKind,
    render_role: OrthologRenderRole,
    path_id: str | None = None,
) -> OrthologEdge:
    query_protein = protein_map[query_id]
    subject_protein = protein_map[subject_id]
    return OrthologEdge(
        orthogroup_id=str(orthogroup_id),
        source_rbh_orthogroup_id=source_rbh_orthogroup_id,
        target_rbh_orthogroup_id=target_rbh_orthogroup_id,
        query_protein_id=str(query_id),
        subject_protein_id=str(subject_id),
        query_record_index=int(query_protein.record_index),
        subject_record_index=int(subject_protein.record_index),
        edge_kind=edge_kind,
        render_role=render_role,
        path_id=path_id,
        identity=_row_float(row, "identity", 0.0),
        evalue=_row_float(row, "evalue", 1.0),
        bitscore=_row_float(row, "bitscore", 0.0),
        alignment_length=int(_row_float(row, "alignment_length", 0.0)),
    )


def _build_ortholog_path_indexes(edges_by_group, protein_map):
    updated, indexes = {}, {}
    for group_id, edges in edges_by_group.items():
        index = OrthologPathCollection.from_edges(group_id, edges, protein_map)
        updated[group_id] = tuple(replace(edge, path_id=index.first_path_id(edge)) for edge in edges)
        indexes[group_id] = index
    return updated, indexes


def _anchor_core_hit_rank(
    row: object,
    protein_map: Mapping[str, CdsProtein],
) -> tuple[float, float, float, float, int, int, str, int, str]:
    query_id = str(getattr(row, "query", ""))
    subject_id = str(getattr(row, "subject", ""))
    query_record_index = int(protein_map[query_id].record_index) if query_id in protein_map else 0
    subject_record_index = int(protein_map[subject_id].record_index) if subject_id in protein_map else 0
    return (
        -_normalized_score_from_row(row),
        _row_float(row, "evalue", float("inf")),
        -_row_float(row, "min_coverage", 0.0),
        -_row_float(row, "identity", 0.0),
        -int(_row_float(row, "alignment_length", 0.0)),
        query_record_index,
        query_id,
        subject_record_index,
        subject_id,
    )


def _row_min_coverage(row: object) -> float:
    return _row_float(row, "min_coverage", 0.0)


def _row_domain_only(row: object) -> bool:
    return bool(getattr(row, "domain_only", False)) or _row_min_coverage(row) <= _DOMAIN_ONLY_MAX_MIN_COVERAGE


def _row_supports_membership(row: object) -> bool:
    return _row_min_coverage(row) >= _MIN_MEMBERSHIP_MIN_COVERAGE and not _row_domain_only(row)


def _dedupe_anchor_core_directional_rows(
    normalized_tables: Mapping[tuple[int, int], DataFrame],
    protein_map: Mapping[str, CdsProtein],
) -> dict[tuple[str, str], object]:
    best_by_direction: dict[tuple[str, str], object] = {}
    for hits in normalized_tables.values():
        if hits is None or hits.empty:
            continue
        for row in hits.itertuples(index=False):
            query_id = str(row.query)
            subject_id = str(row.subject)
            if query_id == subject_id:
                continue
            if query_id not in protein_map or subject_id not in protein_map:
                continue
            if _normalized_score_from_row(row) <= 0.0:
                continue
            key = (query_id, subject_id)
            current = best_by_direction.get(key)
            if current is None or _anchor_core_hit_rank(row, protein_map) < _anchor_core_hit_rank(current, protein_map):
                best_by_direction[key] = row
    return best_by_direction


def _best_rows_by_query_target_record(
    best_by_direction: Mapping[tuple[str, str], object],
    protein_map: Mapping[str, CdsProtein],
) -> dict[tuple[str, int], list[object]]:
    rows_by_query_record: dict[tuple[str, int], list[object]] = {}
    for (query_id, subject_id), row in best_by_direction.items():
        query_protein = protein_map.get(query_id)
        subject_protein = protein_map.get(subject_id)
        if query_protein is None or subject_protein is None:
            continue
        if int(query_protein.record_index) == int(subject_protein.record_index):
            continue
        rows_by_query_record.setdefault((query_id, int(subject_protein.record_index)), []).append(row)
    for rows in rows_by_query_record.values():
        rows.sort(key=lambda row: _anchor_core_hit_rank(row, protein_map))
    return rows_by_query_record


def _comparison_record_for_ids(row: object, query_id: str, subject_id: str) -> dict[str, object]:
    record = {column: getattr(row, column) for column in COMPARISON_COLUMNS}
    original_query = str(getattr(row, "query", ""))
    original_subject = str(getattr(row, "subject", ""))
    if original_query == subject_id and original_subject == query_id:
        record["qstart"], record["sstart"] = record["sstart"], record["qstart"]
        record["qend"], record["send"] = record["send"], record["qend"]
    record["query"] = query_id
    record["subject"] = subject_id
    return record


def _anchor_core_edge_sort_key(
    edge: _AnchorCoreEvidenceEdge,
    protein_map: Mapping[str, CdsProtein],
) -> tuple[tuple[int, int, int, str], tuple[int, int, int, str], int, float, float, str, str]:
    return (
        _protein_sort_key(protein_map[edge.query_id]),
        _protein_sort_key(protein_map[edge.subject_id]),
        0 if edge.edge_kind == "rbh" else 1,
        -max(float(edge.score), float(edge.reverse_score)),
        _row_float(edge.row, "evalue", float("inf")),
        edge.query_id,
        edge.subject_id,
    )


def _select_anchor_core_edges(
    best_by_direction: Mapping[tuple[str, str], object],
    protein_map: Mapping[str, CdsProtein],
) -> tuple[_AnchorCoreEvidenceEdge, ...]:
    rows_by_query_record = _best_rows_by_query_target_record(best_by_direction, protein_map)
    best_subject_by_query_record = {
        key: str(rows[0].subject)
        for key, rows in rows_by_query_record.items()
        if rows
    }
    best_score_by_query_record = {
        key: _normalized_score_from_row(rows[0])
        for key, rows in rows_by_query_record.items()
        if rows
    }
    selected_by_pair: dict[tuple[str, str], _AnchorCoreEvidenceEdge] = {}
    for (query_id, subject_id), row in sorted(
        best_by_direction.items(),
        key=lambda item: _anchor_core_hit_rank(item[1], protein_map),
    ):
        query_protein = protein_map.get(query_id)
        subject_protein = protein_map.get(subject_id)
        if query_protein is None or subject_protein is None:
            continue
        query_record_index = int(query_protein.record_index)
        subject_record_index = int(subject_protein.record_index)
        if query_record_index == subject_record_index:
            continue
        if not _row_supports_membership(row):
            continue
        reverse_row = best_by_direction.get((subject_id, query_id))
        if reverse_row is None or not _row_supports_membership(reverse_row):
            continue
        score = _normalized_score_from_row(row)
        reverse_score = _normalized_score_from_row(reverse_row)
        query_best = best_score_by_query_record.get((query_id, subject_record_index), 0.0)
        subject_best = best_score_by_query_record.get((subject_id, query_record_index), 0.0)
        if query_best <= 0.0 or subject_best <= 0.0:
            continue
        if score < _NEAR_RECIPROCAL_MIN_RATIO * query_best:
            continue
        if reverse_score < _NEAR_RECIPROCAL_MIN_RATIO * subject_best:
            continue
        strict_rbh = (
            best_subject_by_query_record.get((query_id, subject_record_index)) == subject_id
            and best_subject_by_query_record.get((subject_id, query_record_index)) == query_id
        )
        canonical_query_id, canonical_subject_id = _canonical_edge_endpoint_ids(
            query_id,
            subject_id,
            protein_map,
        )
        canonical_row = row if canonical_query_id == query_id else reverse_row
        canonical_score = score if canonical_query_id == query_id else reverse_score
        canonical_reverse_score = reverse_score if canonical_query_id == query_id else score
        candidate = _AnchorCoreEvidenceEdge(
            query_id=canonical_query_id,
            subject_id=canonical_subject_id,
            row=canonical_row,
            score=float(canonical_score),
            reverse_score=float(canonical_reverse_score),
            edge_kind="rbh" if strict_rbh else "coortholog",
        )
        key = (canonical_query_id, canonical_subject_id)
        current = selected_by_pair.get(key)
        if current is None:
            selected_by_pair[key] = candidate
            continue
        current_rank = _anchor_core_edge_sort_key(current, protein_map)
        candidate_rank = _anchor_core_edge_sort_key(candidate, protein_map)
        if candidate_rank < current_rank:
            selected_by_pair[key] = candidate
    return tuple(
        sorted(
            selected_by_pair.values(),
            key=lambda edge: _anchor_core_edge_sort_key(edge, protein_map),
        )
    )


def _best_same_record_unassigned_score_by_query(
    best_by_direction: Mapping[tuple[str, str], object],
    protein_map: Mapping[str, CdsProtein],
    group_by_protein: Mapping[str, str],
) -> dict[str, float]:
    best_score_by_query: dict[str, float] = {}
    for (query_id, subject_id), row in best_by_direction.items():
        if query_id == subject_id:
            continue
        query_protein = protein_map.get(query_id)
        subject_protein = protein_map.get(subject_id)
        if query_protein is None or subject_protein is None:
            continue
        if query_id in group_by_protein or subject_id in group_by_protein:
            continue
        if int(query_protein.record_index) != int(subject_protein.record_index):
            continue
        score = _normalized_score_from_row(row)
        if score <= 0.0:
            continue
        best_score_by_query[query_id] = max(best_score_by_query.get(query_id, 0.0), float(score))
    return best_score_by_query


def _record_local_direction_passes_score_floor(
    *,
    query_id: str,
    row: object,
    thresholds: Mapping[str, _LocalThreshold],
    best_same_record_score_by_query: Mapping[str, float],
) -> bool:
    score = _normalized_score_from_row(row)
    threshold = thresholds.get(query_id)
    if threshold is not None:
        return score >= float(threshold.score)
    best_same_record_score = float(best_same_record_score_by_query.get(query_id, 0.0))
    if best_same_record_score <= 0.0:
        return False
    return score >= _RECORD_LOCAL_NEAR_RECIPROCAL_MIN_RATIO * best_same_record_score


def _select_record_local_paralog_edges(
    best_by_direction: Mapping[tuple[str, str], object],
    protein_map: Mapping[str, CdsProtein],
    thresholds: Mapping[str, _LocalThreshold],
    group_member_ids: Mapping[str, set[str]],
    group_by_protein: Mapping[str, str],
) -> tuple[_AnchorCoreEvidenceEdge, ...]:
    _ = group_member_ids
    best_same_record_score_by_query = _best_same_record_unassigned_score_by_query(
        best_by_direction,
        protein_map,
        group_by_protein,
    )
    selected_by_pair: dict[tuple[str, str], _AnchorCoreEvidenceEdge] = {}
    for (query_id, subject_id), row in sorted(
        best_by_direction.items(),
        key=lambda item: _anchor_core_hit_rank(item[1], protein_map),
    ):
        if query_id == subject_id:
            continue
        query_protein = protein_map.get(query_id)
        subject_protein = protein_map.get(subject_id)
        if query_protein is None or subject_protein is None:
            continue
        if int(query_protein.record_index) != int(subject_protein.record_index):
            continue
        if query_id in group_by_protein or subject_id in group_by_protein:
            continue
        if not _row_supports_membership(row):
            continue
        if _row_min_coverage(row) < _RECORD_LOCAL_MIN_MEMBERSHIP_MIN_COVERAGE:
            continue
        if _row_domain_only(row):
            continue
        reverse_row = best_by_direction.get((subject_id, query_id))
        if reverse_row is None:
            continue
        if not _row_supports_membership(reverse_row):
            continue
        if _row_min_coverage(reverse_row) < _RECORD_LOCAL_MIN_MEMBERSHIP_MIN_COVERAGE:
            continue
        if _row_domain_only(reverse_row):
            continue
        if not _record_local_direction_passes_score_floor(
            query_id=query_id,
            row=row,
            thresholds=thresholds,
            best_same_record_score_by_query=best_same_record_score_by_query,
        ):
            continue
        if not _record_local_direction_passes_score_floor(
            query_id=subject_id,
            row=reverse_row,
            thresholds=thresholds,
            best_same_record_score_by_query=best_same_record_score_by_query,
        ):
            continue

        score = _normalized_score_from_row(row)
        reverse_score = _normalized_score_from_row(reverse_row)
        canonical_query_id, canonical_subject_id = _canonical_edge_endpoint_ids(
            query_id,
            subject_id,
            protein_map,
        )
        canonical_row = row if canonical_query_id == query_id else reverse_row
        canonical_score = score if canonical_query_id == query_id else reverse_score
        canonical_reverse_score = reverse_score if canonical_query_id == query_id else score
        candidate = _AnchorCoreEvidenceEdge(
            query_id=canonical_query_id,
            subject_id=canonical_subject_id,
            row=canonical_row,
            score=float(canonical_score),
            reverse_score=float(canonical_reverse_score),
            edge_kind="record_local_paralog",
        )
        key = tuple(sorted((canonical_query_id, canonical_subject_id)))
        current = selected_by_pair.get(key)
        if current is None or _anchor_core_edge_sort_key(candidate, protein_map) < _anchor_core_edge_sort_key(current, protein_map):
            selected_by_pair[key] = candidate
    return tuple(
        sorted(
            selected_by_pair.values(),
            key=lambda edge: _anchor_core_edge_sort_key(edge, protein_map),
        )
    )


def _record_local_components_from_edges(
    edges: Sequence[_AnchorCoreEvidenceEdge],
    protein_map: Mapping[str, CdsProtein],
) -> tuple[tuple[str, ...], ...]:
    union_find = _UnionFind()
    edge_nodes: set[str] = set()
    for edge in edges:
        if edge.query_id not in protein_map or edge.subject_id not in protein_map:
            continue
        union_find.union(edge.query_id, edge.subject_id)
        edge_nodes.update((edge.query_id, edge.subject_id))
    components_by_root: dict[str, set[str]] = {}
    for protein_id in edge_nodes:
        components_by_root.setdefault(union_find.find(protein_id), set()).add(protein_id)

    components: list[tuple[str, ...]] = []
    for member_ids in components_by_root.values():
        if len(member_ids) < _RECORD_LOCAL_MIN_MEMBERS:
            continue
        record_indices = {int(protein_map[member_id].record_index) for member_id in member_ids}
        if len(record_indices) != 1:
            continue
        components.append(
            tuple(
                sorted(
                    member_ids,
                    key=lambda member_id: _protein_sort_key(protein_map[member_id]),
                )
            )
        )
    return tuple(
        sorted(
            components,
            key=lambda component: min(_protein_sort_key(protein_map[member_id]) for member_id in component),
        )
    )


def _record_local_support_by_member(
    edges: Sequence[_AnchorCoreEvidenceEdge],
) -> dict[str, float]:
    support_by_member: dict[str, float] = {}
    for edge in edges:
        support_by_member[edge.query_id] = max(
            support_by_member.get(edge.query_id, 0.0),
            float(edge.score),
        )
        support_by_member[edge.subject_id] = max(
            support_by_member.get(edge.subject_id, 0.0),
            float(edge.reverse_score),
        )
    return support_by_member


def _record_local_component_has_competing_core_support(
    member_ids: Sequence[str],
    has_core_groups: bool,
    evidence_by_protein: Mapping[str, Mapping[str, Sequence[tuple[str, str, object]]]],
    thresholds: Mapping[str, _LocalThreshold],
    protein_map: Mapping[str, CdsProtein],
    local_support_by_member: Mapping[str, float],
) -> bool:
    if not has_core_groups:
        return False
    credible_core_ids: set[str] = set()
    for member_id in member_ids:
        member_local_support = float(local_support_by_member.get(member_id, 0.0))
        if member_local_support <= 0.0:
            return True
        candidates = [
            candidate
            for group_id, evidence in evidence_by_protein.get(member_id, {}).items()
            if (
                candidate := _build_core_support_candidate(
                    member_id,
                    group_id,
                    evidence,
                    thresholds,
                    protein_map,
                )
            )
            is not None
        ]
        if not candidates:
            continue
        strongest = max(
            candidates,
            key=lambda candidate: (
                max(
                    float(candidate.same_record_score),
                    float(candidate.cross_record_score),
                    float(candidate.diagnostic_score),
                ),
                float(candidate.diagnostic_score),
                candidate.group_id,
            ),
        )
        strongest_score = max(
            float(strongest.same_record_score),
            float(strongest.cross_record_score),
            float(strongest.diagnostic_score),
        )
        competition_floor = member_local_support / _RECORD_LOCAL_CORE_COMPETITION_RATIO
        if strongest.domain_only and strongest_score >= competition_floor:
            return True
        for candidate in candidates:
            core_support = max(
                float(candidate.cross_record_score),
                float(candidate.same_record_score),
            )
            if core_support <= 0.0:
                continue
            if candidate.high_confidence_pass:
                return True
            if candidate.domain_only:
                if core_support >= competition_floor:
                    return True
                continue
            if candidate.low_confidence_pass and core_support >= competition_floor:
                credible_core_ids.add(candidate.group_id)
    return len(credible_core_ids) >= 2


def _next_orthogroup_index(group_ids: Sequence[str]) -> int:
    max_index = 0
    for group_id in group_ids:
        match = re.fullmatch(r"og_(\d+)", str(group_id))
        if match is not None:
            max_index = max(max_index, int(match.group(1)))
    return max_index + 1


def _append_record_local_orthogroups(
    *,
    group_member_ids: dict[str, set[str]],
    group_by_protein: dict[str, str],
    representative_ids_by_group: dict[str, set[str]],
    member_roles: dict[str, OrthogroupMemberRole],
    member_confidence: dict[str, OrthogroupMemberConfidence],
    assignment_reasons: dict[str, str],
    supporting_edges: dict[str, tuple[str, ...]],
    best_core_support: dict[str, float],
    second_core_support: dict[str, float],
    ortholog_edges_by_group: dict[str, list[OrthologEdge]],
    scope_by_group: dict[str, OrthogroupScope],
    source_record_index_by_group: dict[str, int],
    group_order: list[str],
    components: Sequence[Sequence[str]],
    accepted_edges: Sequence[_AnchorCoreEvidenceEdge],
    local_support_by_member: Mapping[str, float],
    protein_map: Mapping[str, CdsProtein],
) -> None:
    next_group_index = _next_orthogroup_index(group_order or list(group_member_ids))
    for component in components:
        component_members = tuple(
            sorted(
                (member_id for member_id in component if member_id in protein_map),
                key=lambda member_id: _protein_sort_key(protein_map[member_id]),
            )
        )
        if len(component_members) < _RECORD_LOCAL_MIN_MEMBERS:
            continue
        component_set = set(component_members)
        record_indices = {int(protein_map[member_id].record_index) for member_id in component_members}
        if len(record_indices) != 1:
            continue
        group_id = f"og_{next_group_index}"
        next_group_index += 1
        group_order.append(group_id)
        group_member_ids[group_id] = set(component_members)
        scope_by_group[group_id] = "record_local"
        source_record_index_by_group[group_id] = next(iter(record_indices))
        for member_id in component_members:
            group_by_protein[member_id] = group_id
            member_roles[member_id] = "local_paralog"
            member_confidence[member_id] = "high"
            assignment_reasons[member_id] = "record-local reciprocal paralog cluster"
            best_core_support[member_id] = min(
                float(local_support_by_member.get(component_member_id, 0.0))
                for component_member_id in component_members
            )
            second_core_support[member_id] = 0.0

        representative_id = min(
            component_members,
            key=lambda member_id: (
                -float(local_support_by_member.get(member_id, 0.0)),
                _protein_sort_key(protein_map[member_id]),
            ),
        )
        representative_ids_by_group[group_id] = {representative_id}

        component_edges = [
            edge
            for edge in accepted_edges
            if edge.query_id in component_set and edge.subject_id in component_set
        ]
        for edge in component_edges:
            edge_id = f"{edge.query_id}->{edge.subject_id}:record_local_paralog"
            for member_id in (edge.query_id, edge.subject_id):
                supporting_edges[member_id] = (*supporting_edges.get(member_id, ()), edge_id)
            ortholog_edges_by_group.setdefault(group_id, []).append(
                _make_ortholog_edge(
                    orthogroup_id=group_id,
                    source_rbh_orthogroup_id=group_id,
                    target_rbh_orthogroup_id=group_id,
                    query_id=edge.query_id,
                    subject_id=edge.subject_id,
                    row=edge.row,
                    protein_map=protein_map,
                    edge_kind="record_local_paralog",
                    render_role="display_edge",
                )
            )


def _derive_anchor_core_thresholds(
    best_by_direction: Mapping[tuple[str, str], object],
    anchor_edges: Sequence[_AnchorCoreEvidenceEdge],
    protein_map: Mapping[str, CdsProtein],
) -> dict[str, _LocalThreshold]:
    cross_scores_by_protein: dict[str, list[float]] = {}
    for (query_id, subject_id), row in best_by_direction.items():
        query_protein = protein_map.get(query_id)
        subject_protein = protein_map.get(subject_id)
        if query_protein is None or subject_protein is None:
            continue
        if int(query_protein.record_index) == int(subject_protein.record_index):
            continue
        score = _normalized_score_from_row(row)
        if score > 0.0 and math.isfinite(score):
            cross_scores_by_protein.setdefault(query_id, []).append(score)

    anchor_scores_by_protein: dict[str, list[float]] = {}
    for edge in anchor_edges:
        if edge.score > 0.0:
            anchor_scores_by_protein.setdefault(edge.query_id, []).append(float(edge.score))
        if edge.reverse_score > 0.0:
            anchor_scores_by_protein.setdefault(edge.subject_id, []).append(float(edge.reverse_score))

    thresholds: dict[str, _LocalThreshold] = {}
    for protein_id in sorted(set(cross_scores_by_protein).union(anchor_scores_by_protein)):
        anchor_scores = [
            score
            for score in anchor_scores_by_protein.get(protein_id, [])
            if score > 0.0 and math.isfinite(score)
        ]
        if anchor_scores:
            anchor_floor = min(anchor_scores)
            thresholds[protein_id] = _LocalThreshold(
                protein_id=protein_id,
                score=float(anchor_floor * _INPARALOG_MIN_SAME_RECORD_RATIO_TO_LOCAL_ANCHOR),
                source="anchor",
                rbnh_count=len(anchor_scores),
                accepted_edge_count=len(anchor_scores),
            )
            continue
        cross_scores = [
            score
            for score in cross_scores_by_protein.get(protein_id, [])
            if score > 0.0 and math.isfinite(score)
        ]
        if not cross_scores:
            continue
        fallback_floor = max(cross_scores)
        thresholds[protein_id] = _LocalThreshold(
            protein_id=protein_id,
            score=float(fallback_floor * _INPARALOG_MIN_SAME_RECORD_RATIO_TO_LOCAL_ANCHOR),
            source="fallback",
            rbnh_count=0,
            accepted_edge_count=0,
        )
    return thresholds


def _index_core_support_evidence(
    best_by_direction: Mapping[tuple[str, str], object],
    group_by_protein: Mapping[str, str],
) -> dict[str, dict[str, list[tuple[str, str, object]]]]:
    """Snapshot incoming/outgoing evidence from unassigned proteins to members.

    Rows are immutable normalized tuples. Buckets own only references and never
    alias the mutable membership map; rebuild after membership expansion.
    """
    evidence_by_protein: dict[str, dict[str, list[tuple[str, str, object]]]] = {}
    for (query_id, subject_id), row in best_by_direction.items():
        query_group = group_by_protein.get(query_id)
        subject_group = group_by_protein.get(subject_id)
        if query_group is None and subject_group is not None:
            evidence_by_protein.setdefault(query_id, {}).setdefault(subject_group, []).append(
                (query_id, subject_id, row)
            )
        elif subject_group is None and query_group is not None:
            evidence_by_protein.setdefault(subject_id, {}).setdefault(query_group, []).append(
                (query_id, subject_id, row)
            )
    return evidence_by_protein


def _best_evidence_between_protein_and_members(
    protein_id: str,
    evidence: Sequence[tuple[str, str, object]],
    protein_map: Mapping[str, CdsProtein],
) -> tuple[_BestCoreEvidence, _BestCoreEvidence]:
    """Reduce connected evidence once, returning same-record then cross-record."""
    protein = protein_map[protein_id]
    supports: list[tuple[float, object | None, str, str]] = [(0.0, None, "", "")] * 2
    diagnostics: list[tuple[float, object | None, str, str]] = [(0.0, None, "", "")] * 2
    for query_id, subject_id, row in evidence:
        member_id = subject_id if query_id == protein_id else query_id
        if member_id == protein_id or member_id not in protein_map or row is None:
            continue
        record_kind = int(int(protein.record_index) != int(protein_map[member_id].record_index))
        score = _normalized_score_from_row(row)
        if score <= 0.0:
            continue
        current_diagnostic_row = diagnostics[record_kind][1]
        if (
            current_diagnostic_row is None
            or score > diagnostics[record_kind][0]
            or (
                score == diagnostics[record_kind][0]
                and _anchor_core_hit_rank(row, protein_map) < _anchor_core_hit_rank(current_diagnostic_row, protein_map)
            )
        ):
            diagnostics[record_kind] = (float(score), row, query_id, subject_id)
        if not _row_supports_membership(row):
            continue
        current_support_row = supports[record_kind][1]
        if (
            current_support_row is None
            or score > supports[record_kind][0]
            or (
                score == supports[record_kind][0]
                and _anchor_core_hit_rank(row, protein_map) < _anchor_core_hit_rank(current_support_row, protein_map)
            )
        ):
            supports[record_kind] = (float(score), row, query_id, subject_id)
    return tuple(
        _BestCoreEvidence(
            support_score=float(support[0]),
            support_row=support[1],
            support_query_id=support[2],
            support_subject_id=support[3],
            diagnostic_score=float(diagnostic[0]),
            diagnostic_row=diagnostic[1],
            diagnostic_query_id=diagnostic[2],
            diagnostic_subject_id=diagnostic[3],
        )
        for support, diagnostic in zip(supports, diagnostics)
    )


def _support_gap_ratio(best_support: float, second_support: float) -> float:
    if best_support <= 0.0:
        return 0.0
    if second_support <= _ORTHOGROUP_SPLIT_EPSILON:
        return float("inf")
    return float(best_support) / max(float(second_support), _ORTHOGROUP_SPLIT_EPSILON)


def _build_core_support_candidate(
    protein_id: str,
    group_id: str,
    evidence: Sequence[tuple[str, str, object]],
    thresholds: Mapping[str, _LocalThreshold],
    protein_map: Mapping[str, CdsProtein],
) -> _CoreSupportCandidate | None:
    same_evidence, cross_evidence = _best_evidence_between_protein_and_members(
        protein_id, evidence, protein_map,
    )
    if same_evidence.diagnostic_row is None and cross_evidence.diagnostic_row is None:
        return None

    same_score = float(same_evidence.support_score)
    cross_score = float(cross_evidence.support_score)
    support = float(cross_score) + 0.5 * float(same_score)
    diagnostic_score = max(
        float(same_evidence.diagnostic_score),
        float(cross_evidence.diagnostic_score),
    )

    candidate_threshold = thresholds.get(protein_id)
    same_member_id = ""
    if same_evidence.support_row is not None:
        same_member_id = (
            same_evidence.support_subject_id
            if same_evidence.support_query_id == protein_id
            else same_evidence.support_query_id
        )
    same_member_threshold = thresholds.get(same_member_id)
    same_pass = (
        same_evidence.support_row is not None
        and (
            (
                candidate_threshold is not None
                and same_score >= float(candidate_threshold.score)
            )
            or (
                same_member_threshold is not None
                and same_score >= float(same_member_threshold.score)
            )
        )
    )
    cross_pass = (
        cross_evidence.support_row is not None
        and candidate_threshold is not None
        and cross_score >= float(candidate_threshold.score)
    )

    if same_pass:
        evidence_row = same_evidence.support_row
        evidence_query_id = same_evidence.support_query_id
        evidence_subject_id = same_evidence.support_subject_id
        relation_kind: OrthologEdgeKind = "same_record_inparalog"
    elif cross_pass:
        evidence_row = cross_evidence.support_row
        evidence_query_id = cross_evidence.support_query_id
        evidence_subject_id = cross_evidence.support_subject_id
        relation_kind = "coortholog"
    elif same_evidence.support_row is not None and (
        cross_evidence.support_row is None or same_score >= cross_score
    ):
        evidence_row = same_evidence.support_row
        evidence_query_id = same_evidence.support_query_id
        evidence_subject_id = same_evidence.support_subject_id
        relation_kind = "same_record_inparalog"
    elif cross_evidence.support_row is not None:
        evidence_row = cross_evidence.support_row
        evidence_query_id = cross_evidence.support_query_id
        evidence_subject_id = cross_evidence.support_subject_id
        relation_kind = "coortholog"
    elif same_evidence.diagnostic_row is not None and (
        cross_evidence.diagnostic_row is None
        or same_evidence.diagnostic_score >= cross_evidence.diagnostic_score
    ):
        evidence_row = same_evidence.diagnostic_row
        evidence_query_id = same_evidence.diagnostic_query_id
        evidence_subject_id = same_evidence.diagnostic_subject_id
        relation_kind = "same_record_inparalog"
    else:
        evidence_row = cross_evidence.diagnostic_row
        evidence_query_id = cross_evidence.diagnostic_query_id
        evidence_subject_id = cross_evidence.diagnostic_subject_id
        relation_kind = "coortholog"
    if evidence_row is None:
        return None

    min_coverage = _row_min_coverage(evidence_row)
    domain_only = _row_domain_only(evidence_row)
    has_support_row = same_evidence.support_row is not None or cross_evidence.support_row is not None
    high_confidence_pass = bool(has_support_row and (same_pass or cross_pass)) and min_coverage >= _MIN_MEMBERSHIP_MIN_COVERAGE and not domain_only
    low_confidence_pass = bool(has_support_row) and min_coverage >= _MIN_MEMBERSHIP_MIN_COVERAGE and not domain_only
    if same_pass:
        reason = "same-record support passed local anchor threshold"
    elif cross_pass:
        reason = "cross-record support passed local fallback threshold"
    elif domain_only:
        reason = "support is domain-only"
    elif min_coverage < _MIN_MEMBERSHIP_MIN_COVERAGE:
        reason = "support is below membership coverage"
    else:
        reason = "support is separated but below high-confidence threshold"
    return _CoreSupportCandidate(
        group_id=group_id,
        support=support,
        diagnostic_score=diagnostic_score,
        same_record_score=float(same_score),
        cross_record_score=float(cross_score),
        evidence_row=evidence_row,
        evidence_query_id=evidence_query_id,
        evidence_subject_id=evidence_subject_id,
        relation_kind=relation_kind,
        min_coverage=float(min_coverage),
        domain_only=bool(domain_only),
        high_confidence_pass=high_confidence_pass,
        low_confidence_pass=low_confidence_pass,
        reason=reason,
    )


def _core_support_sort_key(candidate: _CoreSupportCandidate) -> tuple[float, float, str]:
    return (-float(candidate.support), -float(candidate.diagnostic_score), candidate.group_id)


def _append_limited_related_edge(
    related_edges_by_group: dict[str, list[OrthologEdge]],
    *,
    group_id: str,
    max_related_edges_per_orthogroup: int,
    edge: OrthologEdge,
) -> None:
    edges = related_edges_by_group.setdefault(group_id, [])
    if len(edges) >= int(max_related_edges_per_orthogroup):
        return
    existing = {
        (item.query_protein_id, item.subject_protein_id, item.edge_kind)
        for item in edges
    }
    key = (edge.query_protein_id, edge.subject_protein_id, edge.edge_kind)
    reverse_key = (edge.subject_protein_id, edge.query_protein_id, edge.edge_kind)
    if key in existing or reverse_key in existing:
        return
    edges.append(edge)


def _anchor_core_edge_tables(
    anchor_edges: Sequence[_AnchorCoreEvidenceEdge],
    protein_map: Mapping[str, CdsProtein],
) -> dict[tuple[int, int], DataFrame]:
    rows_by_pair: dict[tuple[int, int], list[dict[str, object]]] = {}
    for edge in anchor_edges:
        query_record_index = int(protein_map[edge.query_id].record_index)
        subject_record_index = int(protein_map[edge.subject_id].record_index)
        if query_record_index == subject_record_index:
            continue
        pair = (min(query_record_index, subject_record_index), max(query_record_index, subject_record_index))
        query_id, subject_id = edge.query_id, edge.subject_id
        if query_record_index > subject_record_index:
            query_id, subject_id = subject_id, query_id
        rows_by_pair.setdefault(pair, []).append(_comparison_record_for_ids(edge.row, query_id, subject_id))
    return {
        pair: pd.DataFrame.from_records(rows, columns=COMPARISON_COLUMNS)
        for pair, rows in rows_by_pair.items()
    }


def _build_anchor_core_orthogroups(
    best_by_direction: Mapping[tuple[str, str], object],
    anchor_edges: Sequence[_AnchorCoreEvidenceEdge],
    protein_map: Mapping[str, CdsProtein],
    *,
    include_singletons: bool,
    max_related_edges_per_orthogroup: int,
) -> OrthogroupGraphResult:
    thresholds = _derive_anchor_core_thresholds(best_by_direction, anchor_edges, protein_map)
    union_find = _UnionFind()
    member_ranks: dict[str, tuple[float, float, float, float]] = {}
    member_roles: dict[str, OrthogroupMemberRole] = {}
    member_confidence: dict[str, OrthogroupMemberConfidence] = {}
    assignment_reasons: dict[str, str] = {}
    supporting_edges: dict[str, tuple[str, ...]] = {}
    best_core_support: dict[str, float] = {}
    second_core_support: dict[str, float] = {}
    ortholog_edges_by_group: dict[str, list[OrthologEdge]] = {}
    scope_by_group: dict[str, OrthogroupScope] = {}
    source_record_index_by_group: dict[str, int] = {}

    for edge in anchor_edges:
        union_find.union(edge.query_id, edge.subject_id)
        rank = _member_rank_from_row(edge.row)
        if _is_better_member_rank(rank, member_ranks.get(edge.query_id)):
            member_ranks[edge.query_id] = rank
        if _is_better_member_rank(rank, member_ranks.get(edge.subject_id)):
            member_ranks[edge.subject_id] = rank
        for protein_id in (edge.query_id, edge.subject_id):
            current_role = member_roles.get(protein_id)
            if edge.edge_kind == "rbh" or current_role is None:
                member_roles[protein_id] = "anchor" if edge.edge_kind == "rbh" else "coortholog"
            member_confidence[protein_id] = "high"
            assignment_reasons[protein_id] = (
                "cross-record reciprocal best anchor"
                if edge.edge_kind == "rbh"
                else "cross-record near-reciprocal anchor"
            )
            supporting_edges[protein_id] = (*supporting_edges.get(protein_id, ()), f"{edge.query_id}->{edge.subject_id}:{edge.edge_kind}")

    components: dict[str, set[str]] = {}
    for edge in anchor_edges:
        root = union_find.find(edge.query_id)
        components.setdefault(root, set()).update((edge.query_id, edge.subject_id))
    if include_singletons:
        # anchor_core_v1 keeps isolated proteins unassigned; record-local
        # orthogroups are added only from accepted same-record evidence below.
        pass

    sorted_components = sorted(
        (member_ids for member_ids in components.values() if member_ids),
        key=lambda member_ids: min(_protein_sort_key(protein_map[member_id]) for member_id in member_ids),
    )
    group_member_ids: dict[str, set[str]] = {
        f"og_{index}": set(member_ids)
        for index, member_ids in enumerate(sorted_components, start=1)
    }
    group_order = list(group_member_ids)
    group_by_protein: dict[str, str] = {
        protein_id: group_id
        for group_id, member_ids in group_member_ids.items()
        for protein_id in member_ids
    }
    scope_by_group.update({group_id: "cross_record" for group_id in group_member_ids})
    representative_ids_by_group: dict[str, set[str]] = {}
    for group_id, member_ids in group_member_ids.items():
        members_by_record: dict[int, list[str]] = {}
        for member_id in member_ids:
            protein = protein_map[member_id]
            members_by_record.setdefault(int(protein.record_index), []).append(member_id)
        for record_member_ids in members_by_record.values():
            representative_id = min(
                record_member_ids,
                key=lambda member_id: (
                    -member_ranks.get(member_id, (0.0, float("inf"), 0.0, 0.0))[0],
                    member_ranks.get(member_id, (0.0, float("inf"), 0.0, 0.0))[1],
                    -member_ranks.get(member_id, (0.0, float("inf"), 0.0, 0.0))[2],
                    -member_ranks.get(member_id, (0.0, float("inf"), 0.0, 0.0))[3],
                    str(member_id),
                ),
            )
            representative_ids_by_group.setdefault(group_id, set()).add(representative_id)

    for edge in anchor_edges:
        group_id = group_by_protein.get(edge.query_id)
        if group_id is None:
            continue
        ortholog_edges_by_group.setdefault(group_id, []).append(
            _make_ortholog_edge(
                orthogroup_id=group_id,
                source_rbh_orthogroup_id=group_id,
                target_rbh_orthogroup_id=group_id,
                query_id=edge.query_id,
                subject_id=edge.subject_id,
                row=edge.row,
                protein_map=protein_map,
                edge_kind=edge.edge_kind,
                render_role="block_anchor",
            )
        )

    # Freeze core membership before any additions; evidence cannot chain through
    # proteins assigned later in this loop.
    core_member_snapshot = _index_core_support_evidence(best_by_direction, group_by_protein)
    related_edges_by_group: dict[str, list[OrthologEdge]] = {}
    for protein_id in sorted(protein_map, key=lambda item: _protein_sort_key(protein_map[item])):
        if protein_id in group_by_protein:
            continue
        candidates = [
            candidate
            for group_id, evidence in core_member_snapshot.get(protein_id, {}).items()
            if (
                candidate := _build_core_support_candidate(
                    protein_id,
                    group_id,
                    evidence,
                    thresholds,
                    protein_map,
                )
            )
            is not None
        ]
        if not candidates:
            continue
        candidates.sort(key=_core_support_sort_key)
        best = candidates[0]
        second = candidates[1] if len(candidates) > 1 else None
        second_support = float(second.support) if second is not None else 0.0
        gap_ratio = _support_gap_ratio(best.support, second_support)
        assigned_role: OrthogroupMemberRole | None = None
        assigned_confidence: OrthogroupMemberConfidence | None = None
        assigned_reason = best.reason
        if best.high_confidence_pass and gap_ratio >= _MIN_BEST_SECOND_CORE_RATIO:
            assigned_role = "inparalog" if best.relation_kind == "same_record_inparalog" else "coortholog"
            assigned_confidence = "high"
        elif best.low_confidence_pass and gap_ratio >= _LOW_CONFIDENCE_MIN_BEST_SECOND_CORE_RATIO:
            assigned_role = "low_confidence"
            assigned_confidence = "low"
            assigned_reason = f"low-confidence assignment: {best.reason}"

        if assigned_role is None or assigned_confidence is None:
            if best.domain_only:
                unassigned_relation_kind: OrthologEdgeKind = "domain_only"
            elif second is not None and best.low_confidence_pass:
                unassigned_relation_kind = "ambiguous_paralog"
            else:
                unassigned_relation_kind = best.relation_kind
            if unassigned_relation_kind in {"ambiguous_paralog", "domain_only"}:
                _append_limited_related_edge(
                    related_edges_by_group,
                    group_id=best.group_id,
                    max_related_edges_per_orthogroup=max_related_edges_per_orthogroup,
                    edge=_make_ortholog_edge(
                        orthogroup_id=best.group_id,
                        source_rbh_orthogroup_id=best.group_id,
                        target_rbh_orthogroup_id=None,
                        query_id=best.evidence_query_id,
                        subject_id=best.evidence_subject_id,
                        row=best.evidence_row,
                        protein_map=protein_map,
                        edge_kind=unassigned_relation_kind,
                        render_role="display_edge",
                    ),
                )
            continue

        group_member_ids.setdefault(best.group_id, set()).add(protein_id)
        group_by_protein[protein_id] = best.group_id
        member_roles[protein_id] = assigned_role
        member_confidence[protein_id] = assigned_confidence
        assignment_reasons[protein_id] = assigned_reason
        best_core_support[protein_id] = float(best.support)
        second_core_support[protein_id] = float(second_support)
        support_edge_id = f"{best.evidence_query_id}->{best.evidence_subject_id}:{best.relation_kind}"
        supporting_edges[protein_id] = (support_edge_id,)
        ortholog_edges_by_group.setdefault(best.group_id, []).append(
            _make_ortholog_edge(
                orthogroup_id=best.group_id,
                source_rbh_orthogroup_id=best.group_id,
                target_rbh_orthogroup_id=best.group_id,
                query_id=best.evidence_query_id,
                subject_id=best.evidence_subject_id,
                row=best.evidence_row,
                protein_map=protein_map,
                edge_kind=best.relation_kind,
                render_role="display_edge",
            )
        )

    del core_member_snapshot
    record_local_edges = _select_record_local_paralog_edges(
        best_by_direction,
        protein_map,
        thresholds,
        group_member_ids,
        group_by_protein,
    )
    record_local_components = _record_local_components_from_edges(record_local_edges, protein_map)
    local_support_by_member = _record_local_support_by_member(record_local_edges)
    # Expanded cross-record membership is stable throughout component screening.
    # All components are screened before any record-local groups are appended.
    expanded_core_evidence = (
        _index_core_support_evidence(best_by_direction, group_by_protein)
        if record_local_components and group_member_ids else {}
    )
    accepted_record_local_components = tuple(
        component
        for component in record_local_components
        if not _record_local_component_has_competing_core_support(
            component,
            bool(group_member_ids),
            expanded_core_evidence,
            thresholds,
            protein_map,
            local_support_by_member,
        )
    )
    del expanded_core_evidence
    _append_record_local_orthogroups(
        group_member_ids=group_member_ids,
        group_by_protein=group_by_protein,
        representative_ids_by_group=representative_ids_by_group,
        member_roles=member_roles,
        member_confidence=member_confidence,
        assignment_reasons=assignment_reasons,
        supporting_edges=supporting_edges,
        best_core_support=best_core_support,
        second_core_support=second_core_support,
        ortholog_edges_by_group=ortholog_edges_by_group,
        scope_by_group=scope_by_group,
        source_record_index_by_group=source_record_index_by_group,
        group_order=group_order,
        components=accepted_record_local_components,
        accepted_edges=record_local_edges,
        local_support_by_member=local_support_by_member,
        protein_map=protein_map,
    )

    membership_pairs = {
        tuple(sorted((edge.query_protein_id, edge.subject_protein_id)))
        for edges in ortholog_edges_by_group.values()
        for edge in edges
    }
    seen_related_pairs: set[tuple[str, str, OrthologEdgeKind]] = set()
    for (query_id, subject_id), row in sorted(
        best_by_direction.items(),
        key=lambda item: _anchor_core_hit_rank(item[1], protein_map),
    ):
        if query_id not in protein_map or subject_id not in protein_map or query_id == subject_id:
            continue
        canonical_query_id, canonical_subject_id = _canonical_edge_endpoint_ids(query_id, subject_id, protein_map)
        query_group = group_by_protein.get(canonical_query_id)
        subject_group = group_by_protein.get(canonical_subject_id)
        if query_group is None and subject_group is None:
            continue
        relation_kind: OrthologEdgeKind
        if _row_domain_only(row):
            relation_kind = "domain_only"
        elif query_group is not None and subject_group is not None and query_group != subject_group:
            relation_kind = "weak_bridge"
        elif query_group == subject_group:
            query_role = member_roles.get(canonical_query_id)
            subject_role = member_roles.get(canonical_subject_id)
            if "inparalog" in {query_role, subject_role}:
                relation_kind = "same_record_inparalog"
            else:
                relation_kind = "related_homolog"
        else:
            relation_kind = "related_homolog"
        edge_pair = tuple(sorted((canonical_query_id, canonical_subject_id)))
        edge_key = edge_pair + (relation_kind,)
        if edge_pair in membership_pairs or edge_key in seen_related_pairs:
            continue
        seen_related_pairs.add(edge_key)
        for group_id in dict.fromkeys(group for group in (query_group, subject_group) if group is not None):
            _append_limited_related_edge(
                related_edges_by_group,
                group_id=group_id,
                max_related_edges_per_orthogroup=max_related_edges_per_orthogroup,
                edge=_make_ortholog_edge(
                    orthogroup_id=group_id,
                    source_rbh_orthogroup_id=query_group,
                    target_rbh_orthogroup_id=subject_group,
                    query_id=canonical_query_id,
                    subject_id=canonical_subject_id,
                    row=row,
                    protein_map=protein_map,
                    edge_kind=relation_kind,
                    render_role="display_edge",
                ),
            )

    updated_edges_by_group, paths_by_group = _build_ortholog_path_indexes(
        {
            group_id: sorted(
                edges,
                key=lambda edge: (
                    edge.query_record_index,
                    edge.subject_record_index,
                    edge.query_protein_id,
                    edge.subject_protein_id,
                    edge.edge_kind,
                ),
            )
            for group_id, edges in ortholog_edges_by_group.items()
        },
        protein_map,
    )
    anchor_members_by_group = {
        group_id: [
            member_id
            for member_id in member_ids
            if member_roles.get(member_id) == "anchor"
        ]
        for group_id, member_ids in group_member_ids.items()
    }
    rbh_orthogroups = {
        group_id: tuple(
            sorted(
                anchor_members_by_group.get(group_id) or list(member_ids),
                key=lambda member_id: _protein_sort_key(protein_map[member_id]),
            )
        )
        for group_id, member_ids in group_member_ids.items()
    }
    return _orthogroup_result_from_member_ids(
        group_member_ids,
        representative_ids_by_group,
        protein_map,
        group_order=group_order,
        rbh_orthogroups=rbh_orthogroups,
        ortholog_edges_by_orthogroup_id=updated_edges_by_group,
        path_indexes_by_orthogroup_id=paths_by_group,
        related_edges_by_orthogroup_id={
            group_id: tuple(
                sorted(
                    edges,
                    key=lambda edge: (
                        ORTHOLOG_DISPLAY_EDGE_KIND_RANK.get(str(edge.edge_kind), 99),
                        edge.query_record_index,
                        edge.subject_record_index,
                        edge.query_protein_id,
                        edge.subject_protein_id,
                    ),
                )
            )
            for group_id, edges in related_edges_by_group.items()
        },
        member_roles_by_protein_id=member_roles,
        member_confidence_by_protein_id=member_confidence,
        assignment_reason_by_protein_id=assignment_reasons,
        supporting_edges_by_protein_id=supporting_edges,
        best_core_support_by_protein_id=best_core_support,
        second_best_core_support_by_protein_id=second_core_support,
        scope_by_orthogroup_id=scope_by_group,
        source_record_index_by_orthogroup_id=source_record_index_by_group,
    )


def _select_anchor_core_orthogroup_edges_from_directional_hits(
    directional_hits_by_pair: Mapping[tuple[int, int], DataFrame],
    protein_map: Mapping[str, CdsProtein],
    *,
    record_count: int | None,
    include_singletons: bool,
    max_related_edges_per_orthogroup: int,
    comparison_pairs: Sequence[tuple[int, int]] | None,
) -> OrthogroupEdgeSelectionResult:
    if int(max_related_edges_per_orthogroup) <= 0:
        raise ValidationError("collinear_max_paralog_links_per_orthogroup must be > 0")
    normalized_tables = _normalize_directional_hit_tables(
        directional_hits_by_pair,
        protein_map,
        min_coverage=0.0,
    )
    best_by_direction = _dedupe_anchor_core_directional_rows(normalized_tables, protein_map)
    anchor_edges = _select_anchor_core_edges(best_by_direction, protein_map)
    anchor_edge_tables = _anchor_core_edge_tables(anchor_edges, protein_map)
    if record_count is None:
        record_count = 0
        for query_index, subject_index in directional_hits_by_pair:
            record_count = max(record_count, int(query_index) + 1, int(subject_index) + 1)

    all_edges_by_pair = {
        pair: _comparison_columns_only(table)
        for pair, table in anchor_edge_tables.items()
    }
    display_pairs = (
        tuple(comparison_pairs) if comparison_pairs is not None else
        tuple((index, index + 1) for index in range(max(0, int(record_count) - 1)))
    )
    if any(
        not (0 <= query < int(record_count) and 0 <= subject < int(record_count))
        or query == subject for query, subject in display_pairs
    ):
        raise ValidationError("comparison_pairs contains an invalid record-index pair.")
    if len(set(display_pairs)) != len(display_pairs):
        raise ValidationError("comparison_pairs must not contain duplicates.")
    adjacent_anchor_edges_by_pair = {}
    for query, subject in display_pairs:
        table = anchor_edge_tables.get(tuple(sorted((query, subject))), _empty_comparison_hits())
        if query > subject:
            table = pd.DataFrame.from_records(
                [_comparison_record_for_ids(row, str(row.subject), str(row.query))
                 for row in table.itertuples(index=False)],
                columns=COMPARISON_COLUMNS,
            )
        adjacent_anchor_edges_by_pair[(query, subject)] = _comparison_columns_only(table)
    adjacent_candidate_edges_by_pair = {
        pair: _comparison_columns_only(directional_hits_by_pair.get(pair, _empty_comparison_hits()))
        for pair in display_pairs
    }

    orthogroups = _build_anchor_core_orthogroups(
        best_by_direction,
        anchor_edges,
        protein_map,
        include_singletons=include_singletons,
        max_related_edges_per_orthogroup=max_related_edges_per_orthogroup,
    )
    adjacent_display_edges_by_pair = _build_adjacent_display_edges_by_pair(
        adjacent_anchor_edges_by_pair,
        orthogroups,
        max_display_edges_per_orthogroup=int(max_related_edges_per_orthogroup),
        adjacent_candidate_edges_by_pair=adjacent_candidate_edges_by_pair,
    )
    return OrthogroupEdgeSelectionResult(
        orthogroups=orthogroups,
        all_edges_by_pair=all_edges_by_pair,
        adjacent_anchor_edges_by_pair=adjacent_anchor_edges_by_pair,
        adjacent_display_edges_by_pair=adjacent_display_edges_by_pair,
    )


def _genomic_link_coordinates(protein: CdsProtein) -> tuple[int, int]:
    if protein.strand == -1:
        return protein.end, protein.start + 1
    return protein.start + 1, protein.end


def convert_protein_hits_to_genomic_links(
    hits: DataFrame,
    protein_map: Mapping[str, CdsProtein],
    orthogroups: OrthogroupResult | OrthogroupGraphResult | None = None,
) -> DataFrame:
    """Convert protein hit rows to genomic-coordinate comparison rows."""

    return convert_pair_protein_hits_to_genomic_links(
        hits,
        protein_map,
        protein_map,
        orthogroups=orthogroups,
    )


def _view_feature_svg_id(protein: CdsProtein) -> str:
    return str(
        protein.view_feature_svg_id
        or protein.feature_svg_id
        or ""
    )


def _protein_metadata_value(value: object | None) -> object:
    return "" if value is None else value


def _orthogroup_member_counts(members: Sequence[OrthogroupMember]) -> dict[int, int]:
    counts: dict[int, int] = {}
    for member in members:
        record_index = int(member.record_index)
        counts[record_index] = counts.get(record_index, 0) + 1
    return counts


_OrthogroupEdgeIndex = tuple[
    dict[tuple[str, str], OrthologEdge],
    int,
]


def _index_orthogroup_edges(
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
    orthogroup_id: str,
    requested: tuple[str, str],
    index: _OrthogroupEdgeIndex,
) -> _OrthogroupEdgeIndex:
    """Extend an endpoint index to the requested edge without rereading a prefix."""
    indexed, offset = index
    membership = orthogroups.ortholog_edges_by_orthogroup_id.get(orthogroup_id, ())
    related = orthogroups.related_edges_by_orthogroup_id.get(orthogroup_id, ())
    boundary = len(membership)
    total = boundary + len(related)
    for position in range(offset, total):
        edge = membership[position] if position < boundary else related[position - boundary]
        query_id, subject_id = edge.query_protein_id, edge.subject_protein_id
        key = (query_id, subject_id) if query_id <= subject_id else (subject_id, query_id)
        indexed.setdefault(key, edge)
        if key == requested:
            return indexed, position + 1
    return indexed, total


def _edge_metadata_for_protein_pair(
    orthogroups: OrthogroupResult | OrthogroupGraphResult | None,
    orthogroup_id: str,
    query_id: str,
    subject_id: str,
    edge_indexes: dict[str, _OrthogroupEdgeIndex],
) -> dict[str, object]:
    metadata = {
        "rbh_orthogroup_id": "",
        "ortholog_path_id": "",
        "edge_kind": "",
        "render_role": "",
    }
    if orthogroups is None or not orthogroup_id:
        return metadata
    index = edge_indexes.get(orthogroup_id)
    if index is None:
        index = ({}, 0)
    key = (query_id, subject_id) if query_id <= subject_id else (subject_id, query_id)
    if key not in index[0]:
        index = _index_orthogroup_edges(orthogroups, orthogroup_id, key, index)
    edge_indexes[orthogroup_id] = index
    edge = index[0].get(key)
    if edge is not None:
        source_group = str(edge.source_rbh_orthogroup_id or "")
        target_group = str(edge.target_rbh_orthogroup_id or "")
        if source_group and target_group and source_group != target_group:
            rbh_group = f"{source_group};{target_group}"
        else:
            rbh_group = source_group or target_group
        metadata.update(
            {
                "rbh_orthogroup_id": rbh_group,
                "ortholog_path_id": str(edge.path_id or ""),
                "edge_kind": edge.edge_kind,
                "render_role": edge.render_role,
            }
        )
    return metadata


def convert_pair_protein_hits_to_genomic_links(
    hits: DataFrame,
    query_protein_map: Mapping[str, CdsProtein],
    subject_protein_map: Mapping[str, CdsProtein],
    orthogroups: OrthogroupResult | OrthogroupGraphResult | None = None,
) -> DataFrame:
    """Convert pairwise protein hit rows using separate query and subject maps."""

    if hits.empty:
        return pd.DataFrame(columns=LOSATP_COMPARISON_COLUMNS)

    # Build each touched group once, preserving lazy handling of unused groups.
    edge_indexes: dict[str, _OrthogroupEdgeIndex] = {}
    member_counts: dict[str, dict[int, int]] = {}
    rows: list[dict[str, object]] = []
    missing_ids: set[str] = set()
    for row in hits.itertuples(index=False):
        query_id = str(row.query)
        subject_id = str(row.subject)
        query_protein = query_protein_map.get(query_id)
        subject_protein = subject_protein_map.get(subject_id)
        if query_protein is None:
            missing_ids.add(query_id)
        if subject_protein is None:
            missing_ids.add(subject_id)
        if query_protein is None or subject_protein is None:
            continue

        qstart, qend = _genomic_link_coordinates(query_protein)
        sstart, send = _genomic_link_coordinates(subject_protein)
        query_member = (
            orthogroups.member_by_protein_id.get(query_id)
            if orthogroups is not None
            else None
        )
        subject_member = (
            orthogroups.member_by_protein_id.get(subject_id)
            if orthogroups is not None
            else None
        )
        orthogroup_id = ""
        if query_member is not None and subject_member is not None:
            if query_member.orthogroup_id == subject_member.orthogroup_id:
                orthogroup_id = query_member.orthogroup_id
        edge_metadata = _edge_metadata_for_protein_pair(
            orthogroups,
            orthogroup_id,
            query_id,
            subject_id,
            edge_indexes,
        )
        if orthogroup_id and orthogroup_id not in member_counts:
            member_counts[orthogroup_id] = _orthogroup_member_counts(
                orthogroups.orthogroups.get(orthogroup_id, [])
            )
        counts = member_counts.get(orthogroup_id, {})
        rows.append(
            {
                "query": query_protein.record_id,
                "subject": subject_protein.record_id,
                "identity": row.identity,
                "alignment_length": row.alignment_length,
                "mismatches": row.mismatches,
                "gap_opens": row.gap_opens,
                "qstart": qstart,
                "qend": qend,
                "sstart": sstart,
                "send": send,
                "evalue": row.evalue,
                "bitscore": row.bitscore,
                "query_protein_id": query_protein.protein_id,
                "subject_protein_id": subject_protein.protein_id,
                "query_source_protein_id": _protein_metadata_value(query_protein.source_protein_id),
                "subject_source_protein_id": _protein_metadata_value(subject_protein.source_protein_id),
                "query_record_index": query_protein.record_index,
                "subject_record_index": subject_protein.record_index,
                "query_feature_index": query_protein.feature_index,
                "subject_feature_index": subject_protein.feature_index,
                "query_feature_svg_id": str(
                    query_protein.feature_svg_id or ""
                ),
                "subject_feature_svg_id": str(
                    subject_protein.feature_svg_id or ""
                ),
                "query_view_feature_svg_id": _view_feature_svg_id(
                    query_protein
                ),
                "subject_view_feature_svg_id": _view_feature_svg_id(
                    subject_protein
                ),
                "orthogroup_id": orthogroup_id,
                "rbh_orthogroup_id": edge_metadata["rbh_orthogroup_id"],
                "ortholog_path_id": edge_metadata["ortholog_path_id"],
                "edge_kind": edge_metadata["edge_kind"],
                "render_role": edge_metadata["render_role"],
                "query_orthogroup_representative": (
                    bool(query_member.representative) if query_member is not None else False
                ),
                "subject_orthogroup_representative": (
                    bool(subject_member.representative) if subject_member is not None else False
                ),
                "query_orthogroup_member_count": counts.get(int(query_protein.record_index), 0) if counts else 0,
                "subject_orthogroup_member_count": counts.get(int(subject_protein.record_index), 0) if counts else 0,
                "query_orthogroup_role": (
                    str(query_member.role) if query_member is not None else ""
                ),
                "subject_orthogroup_role": (
                    str(subject_member.role) if subject_member is not None else ""
                ),
                "query_orthogroup_confidence": (
                    str(query_member.confidence) if query_member is not None else ""
                ),
                "subject_orthogroup_confidence": (
                    str(subject_member.confidence) if subject_member is not None else ""
                ),
                "query_orthogroup_assignment_reason": (
                    str(query_member.assignment_reason) if query_member is not None else ""
                ),
                "subject_orthogroup_assignment_reason": (
                    str(subject_member.assignment_reason) if subject_member is not None else ""
                ),
            }
        )

    if missing_ids:
        raise ParseError(
            "LOSATP blastp output contains unknown protein IDs: "
            + ", ".join(sorted(missing_ids))
        )

    return pd.DataFrame.from_records(rows, columns=LOSATP_COMPARISON_COLUMNS)


def _build_losat_blastp_command(
    *,
    executable: str,
    query_path: Path,
    subject_path: Path,
    max_hits: int | None,
    max_hsps_per_subject: int | None,
    threads: int | None,
) -> list[str]:
    command = [
        str(executable),
        "blastp",
        "-query",
        str(query_path),
        "-subject",
        str(subject_path),
        "-outfmt",
        "6",
    ]
    if max_hsps_per_subject is not None:
        command.extend(["--max-hsps-per-subject", str(int(max_hsps_per_subject))])
    if max_hits is not None:
        command.extend(["--max-target-seqs", str(int(max_hits))])
    if threads is not None:
        command.extend(["--num-threads", str(int(threads))])
    return command


def _build_ncbi_blastp_command(
    *,
    executable: str,
    query_path: Path,
    subject_path: Path,
    max_hits: int | None,
    max_hsps_per_subject: int | None,
    threads: int | None,
) -> list[str]:
    command = [
        str(executable),
        "-query",
        str(query_path),
        "-subject",
        str(subject_path),
        "-outfmt",
        "6",
    ]
    if max_hsps_per_subject is not None:
        command.extend(["-max_hsps", str(int(max_hsps_per_subject))])
    if max_hits is not None:
        command.extend(["-max_target_seqs", str(int(max_hits))])
    if threads is not None:
        command.extend(["-num_threads", str(int(threads))])
    return command


def _build_protein_blastp_command(
    runtime: ProteinBlastpRuntime,
    *,
    query_path: Path,
    subject_path: Path,
    max_hits: int | None,
    max_hsps_per_subject: int | None,
    threads: int | None,
) -> list[str]:
    builder = (
        _build_ncbi_blastp_command
        if runtime.kind == "ncbi-blastp"
        else _build_losat_blastp_command
    )
    return builder(
        executable=runtime.executable,
        query_path=query_path,
        subject_path=subject_path,
        max_hits=max_hits,
        max_hsps_per_subject=max_hsps_per_subject,
        threads=threads,
    )


def _run_protein_blastp_subprocess(
    command: list[str],
    *,
    runtime_label: str,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise ValidationError(f"{runtime_label} executable not found: {command[0]}") from exc
    except PermissionError as exc:
        raise ValidationError(f"{runtime_label} executable is not executable: {command[0]}") from exc


def run_losatp_blastp(
    query_fasta: str,
    subject_fasta: str,
    *,
    losatp_bin: str = "losat",
    ncbi_blastp_bin: str | None = None,
    max_hits: int | None = None,
    max_hsps_per_subject: int | None = 1,
    threads: int | None = None,
    raw_output_callback: Callable[[str], None] | None = None,
) -> DataFrame:
    """Run an external protein blastp runtime and parse outfmt 6 output."""

    if max_hits is not None:
        _validate_max_hits(max_hits, option_name="protein_blastp_candidate_limit")
    if max_hsps_per_subject is not None:
        _validate_max_hits(max_hsps_per_subject, option_name="max_hsps_per_subject")
    _validate_losatp_threads(threads)
    with ExitStack() as stack:
        runtime = _resolve_protein_blastp_runtime(
            losatp_bin,
            ncbi_blastp_bin,
            stack,
        )
        temp_dir = stack.enter_context(tempfile.TemporaryDirectory(prefix="gbdraw_losatp_"))
        temp_path = Path(temp_dir)
        query_path = temp_path / "query.faa"
        subject_path = temp_path / "subject.faa"
        query_path.write_text(query_fasta, encoding="utf-8")
        subject_path.write_text(subject_fasta, encoding="utf-8")

        command = _build_protein_blastp_command(
            runtime,
            query_path=query_path,
            subject_path=subject_path,
            max_hits=max_hits,
            max_hsps_per_subject=max_hsps_per_subject,
            threads=threads,
        )
        runtime_label = _protein_blastp_runtime_label(runtime)
        logger.info("INFO: Running %s for protein colinearity.", runtime_label)
        completed = _run_protein_blastp_subprocess(
            command,
            runtime_label=runtime_label,
        )

    if completed.returncode != 0:
        stderr = completed.stderr.strip()
        detail = f": {stderr}" if stderr else ""
        runtime_label = _protein_blastp_runtime_label(runtime)
        raise ValidationError(f"{runtime_label} failed with exit code {completed.returncode}{detail}")
    if raw_output_callback is not None:
        raw_output_callback(completed.stdout)
    return parse_losatp_outfmt6(completed.stdout)


def _validate_extraction_has_proteins(
    records: Sequence[SeqRecord],
    extraction: ProteinExtractionResult,
    *,
    option_name: str,
) -> None:
    empty_record_ids = [
        str(records[index].id)
        for index, proteins in enumerate(extraction.proteins_by_record)
        if not proteins
    ]
    if empty_record_ids:
        raise ValidationError(
            f"{option_name} requires at least one CDS protein in each record; "
            "no CDS proteins were found in: "
            + ", ".join(empty_record_ids)
        )


def _losatp_cache_args(
    *,
    candidate_limit: int | None,
    max_hsps_per_subject: int | None,
) -> list[str]:
    args: list[str] = []
    if max_hsps_per_subject is not None:
        args.extend(["--max-hsps-per-subject", str(int(max_hsps_per_subject))])
    if candidate_limit is not None:
        args.extend(["--max-target-seqs", str(int(candidate_limit))])
    return args


def _execute_losatp_search(
    query_fasta: str,
    subject_fasta: str,
    *,
    losatp_bin: str,
    ncbi_blastp_bin: str | None,
    losatp_threads: int | None,
    candidate_limit: int | None,
    max_hsps_per_subject: int | None,
    runner: LosatpRunner | None,
    losatp_cache: LosatpCacheManager | None,
    filename: str = "",
    display: bool = False,
    raw_output_callback: Callable[[str], None] | None = None,
) -> DataFrame:
    """Build one raw-search invocation from already resolved values."""

    resolved_runner = runner
    if resolved_runner is None and losatp_cache is not None:
        resolved_runner = losatp_cache.runner_for_search(
            losatp_bin=losatp_bin,
            ncbi_blastp_bin=ncbi_blastp_bin,
            losatp_threads=losatp_threads,
            candidate_limit=candidate_limit,
            max_hsps_per_subject=max_hsps_per_subject,
            args=_losatp_cache_args(
                candidate_limit=candidate_limit,
                max_hsps_per_subject=max_hsps_per_subject,
            ),
            filename=filename,
            display=display,
        )
    if resolved_runner is not None:
        return resolved_runner(query_fasta, subject_fasta)
    return run_losatp_blastp(
        query_fasta,
        subject_fasta,
        losatp_bin=losatp_bin,
        ncbi_blastp_bin=ncbi_blastp_bin,
        max_hits=candidate_limit,
        max_hsps_per_subject=max_hsps_per_subject,
        threads=losatp_threads,
        raw_output_callback=raw_output_callback,
    )


def _empty_comparison_hits() -> DataFrame:
    return pd.DataFrame(columns=COMPARISON_COLUMNS)


def _orthogroup_scope(
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
    orthogroup_id: str,
) -> OrthogroupScope:
    return orthogroups.scope_by_orthogroup_id.get(str(orthogroup_id), "cross_record")


def _ortholog_edge_display_rank(
    edge: OrthologEdge,
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
) -> tuple[object, ...]:
    query_member = orthogroups.member_by_protein_id.get(edge.query_protein_id)
    subject_member = orthogroups.member_by_protein_id.get(edge.subject_protein_id)
    both_representative = (
        query_member is not None
        and subject_member is not None
        and bool(query_member.representative)
        and bool(subject_member.representative)
    )
    return (
        ORTHOLOG_DISPLAY_EDGE_KIND_RANK.get(str(edge.edge_kind), 99),
        0 if both_representative else 1,
        float(edge.evalue),
        -float(edge.bitscore),
        -float(edge.identity),
        -int(edge.alignment_length),
        int(edge.query_record_index),
        int(edge.subject_record_index),
        str(edge.query_protein_id),
        str(edge.subject_protein_id),
        str(edge.edge_kind),
    )


def _display_pair_orthogroup_id(
    query_id: str,
    subject_id: str,
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
) -> str | None:
    query_member = orthogroups.member_by_protein_id.get(str(query_id))
    subject_member = orthogroups.member_by_protein_id.get(str(subject_id))
    if query_member is None or subject_member is None:
        return None
    if query_member.orthogroup_id != subject_member.orthogroup_id:
        return None
    return str(query_member.orthogroup_id)


def _comparison_row_from_ortholog_edge_for_pair(
    edge: OrthologEdge,
    pair: tuple[int, int],
) -> dict[str, object] | None:
    query_index, subject_index = int(pair[0]), int(pair[1])
    if (
        int(edge.query_record_index) == query_index
        and int(edge.subject_record_index) == subject_index
    ):
        query_id = edge.query_protein_id
        subject_id = edge.subject_protein_id
    elif (
        int(edge.query_record_index) == subject_index
        and int(edge.subject_record_index) == query_index
    ):
        query_id = edge.subject_protein_id
        subject_id = edge.query_protein_id
    else:
        return None

    alignment_length = max(0, int(edge.alignment_length))
    return {
        "query": str(query_id),
        "subject": str(subject_id),
        "identity": float(edge.identity),
        "alignment_length": alignment_length,
        "mismatches": 0,
        "gap_opens": 0,
        "qstart": 1,
        "qend": alignment_length,
        "sstart": 1,
        "send": alignment_length,
        "evalue": float(edge.evalue),
        "bitscore": float(edge.bitscore),
    }


def _comparison_row_key(row: Mapping[str, object]) -> tuple[str, str]:
    return str(row["query"]), str(row["subject"])


def _comparison_row_display_rank(
    row: Mapping[str, object],
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
    *,
    edge_kind_rank: int,
) -> tuple[object, ...]:
    query_id, subject_id = _comparison_row_key(row)
    query_member = orthogroups.member_by_protein_id.get(query_id)
    subject_member = orthogroups.member_by_protein_id.get(subject_id)
    both_representative = (
        query_member is not None
        and subject_member is not None
        and bool(query_member.representative)
        and bool(subject_member.representative)
    )
    return (
        int(edge_kind_rank),
        0 if both_representative else 1,
        float(row.get("evalue", float("inf"))),
        -float(row.get("bitscore", 0.0)),
        -float(row.get("identity", 0.0)),
        -int(float(row.get("alignment_length", 0.0))),
        int(query_member.record_index) if query_member is not None else 0,
        int(subject_member.record_index) if subject_member is not None else 0,
        query_id,
        subject_id,
        "direct_orthogroup",
    )


def _comparison_row_from_hit_row(row: object) -> dict[str, object]:
    return {
        column: getattr(row, column)
        for column in COMPARISON_COLUMNS
    }


def _has_uncovered_display_alternative(
    row_key: tuple[str, str],
    *,
    current_kind_rank: int,
    candidate_subjects_by_query: Mapping[str, set[str]],
    candidate_queries_by_subject: Mapping[str, set[str]],
    candidate_kind_rank_by_pair: Mapping[tuple[str, str], int],
    covered_queries: set[str],
    covered_subjects: set[str],
    existing_pairs: set[tuple[str, str]],
) -> bool:
    query_id, subject_id = row_key
    if query_id not in covered_queries and subject_id in covered_subjects:
        for alternative_subject_id in candidate_subjects_by_query.get(query_id, set()):
            alternative_key = (query_id, alternative_subject_id)
            if alternative_subject_id == subject_id:
                continue
            if alternative_subject_id in covered_subjects:
                continue
            if alternative_key in existing_pairs or (alternative_key[1], alternative_key[0]) in existing_pairs:
                continue
            if candidate_kind_rank_by_pair.get(alternative_key, 99) > current_kind_rank:
                continue
            return True
    if query_id in covered_queries and subject_id not in covered_subjects:
        for alternative_query_id in candidate_queries_by_subject.get(subject_id, set()):
            alternative_key = (alternative_query_id, subject_id)
            if alternative_query_id == query_id:
                continue
            if alternative_query_id in covered_queries:
                continue
            if alternative_key in existing_pairs or (alternative_key[1], alternative_key[0]) in existing_pairs:
                continue
            if candidate_kind_rank_by_pair.get(alternative_key, 99) > current_kind_rank:
                continue
            return True
    return False


def _add_display_row(
    row: dict[str, object],
    *,
    existing_pairs: set[tuple[str, str]],
    covered_queries: set[str],
    covered_subjects: set[str],
    added_rows: list[dict[str, object]],
) -> None:
    row_key = _comparison_row_key(row)
    existing_pairs.add(row_key)
    existing_pairs.add((row_key[1], row_key[0]))
    covered_queries.add(row_key[0])
    covered_subjects.add(row_key[1])
    added_rows.append(row)


def _orthogroup_display_table(
    table: DataFrame,
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
) -> DataFrame:
    if table is None or table.empty:
        return _empty_comparison_hits()

    rows: list[dict[str, object]] = []
    for row in table.itertuples(index=False):
        query_id = str(row.query)
        subject_id = str(row.subject)
        orthogroup_id = _display_pair_orthogroup_id(
            query_id,
            subject_id,
            orthogroups,
        )
        if orthogroup_id is None:
            continue
        if _orthogroup_scope(orthogroups, orthogroup_id) == "record_local":
            continue
        rows.append(_comparison_row_from_hit_row(row))
    if not rows:
        return _empty_comparison_hits()
    return pd.DataFrame.from_records(rows, columns=COMPARISON_COLUMNS)


def _build_adjacent_display_edges_by_pair(
    adjacent_anchor_edges_by_pair: Mapping[tuple[int, int], DataFrame],
    orthogroups: OrthogroupResult | OrthogroupGraphResult,
    *,
    max_display_edges_per_orthogroup: int,
    adjacent_candidate_edges_by_pair: Mapping[tuple[int, int], DataFrame] | None = None,
) -> dict[tuple[int, int], DataFrame]:
    """Overlay bounded non-anchor orthogroup edges for adjacent display."""

    cap = int(max_display_edges_per_orthogroup)
    if cap <= 0:
        raise ValidationError("collinear_max_paralog_links_per_orthogroup must be > 0")

    display_edges_by_pair: dict[tuple[int, int], DataFrame] = {
        (int(pair[0]), int(pair[1])): _orthogroup_display_table(table, orthogroups)
        for pair, table in adjacent_anchor_edges_by_pair.items()
    }

    all_secondary_edges_by_group = {
        orthogroup_id: tuple(
            edge
            for edge in (
                *orthogroups.ortholog_edges_by_orthogroup_id.get(orthogroup_id, ()),
                *orthogroups.related_edges_by_orthogroup_id.get(orthogroup_id, ()),
            )
            if edge.render_role == "display_edge"
        )
        for orthogroup_id in orthogroups.orthogroups
        if _orthogroup_scope(orthogroups, orthogroup_id) != "record_local"
    }

    for pair, anchor_table in list(display_edges_by_pair.items()):
        existing_pairs = {
            (str(row.query), str(row.subject))
            for row in anchor_table.itertuples(index=False)
        }
        existing_pairs.update((subject_id, query_id) for query_id, subject_id in list(existing_pairs))
        # Secondary edges should reveal extra paralog endpoints, not redraw
        # cross-links between endpoints already covered by stronger edges.
        covered_query_by_group: dict[str, set[str]] = {}
        covered_subject_by_group: dict[str, set[str]] = {}
        for row in anchor_table.itertuples(index=False):
            query_id = str(row.query)
            subject_id = str(row.subject)
            orthogroup_id = _display_pair_orthogroup_id(
                query_id,
                subject_id,
                orthogroups,
            )
            if orthogroup_id is None:
                continue
            if _orthogroup_scope(orthogroups, orthogroup_id) == "record_local":
                continue
            covered_query_by_group.setdefault(orthogroup_id, set()).add(query_id)
            covered_subject_by_group.setdefault(orthogroup_id, set()).add(subject_id)
        added_rows: list[dict[str, object]] = []
        direct_candidates_by_group: dict[str, list[tuple[tuple[object, ...], dict[str, object]]]] = {}
        direct_candidate_table = (
            adjacent_candidate_edges_by_pair.get(pair)
            if adjacent_candidate_edges_by_pair is not None
            else None
        )
        if direct_candidate_table is not None and not direct_candidate_table.empty:
            direct_rows = _sort_hits_for_query_best(
                _coerce_outfmt6_numeric_columns(
                    direct_candidate_table.loc[:, list(COMPARISON_COLUMNS)]
                )
            ).drop_duplicates(["query", "subject"], keep="first")
            for row in direct_rows.itertuples(index=False):
                query_id = str(row.query)
                subject_id = str(row.subject)
                orthogroup_id = _display_pair_orthogroup_id(
                    query_id,
                    subject_id,
                    orthogroups,
                )
                if orthogroup_id is None:
                    continue
                if _orthogroup_scope(orthogroups, orthogroup_id) == "record_local":
                    continue
                row_record = _comparison_row_from_hit_row(row)
                direct_candidates_by_group.setdefault(orthogroup_id, []).append(
                    (
                        _comparison_row_display_rank(
                            row_record,
                            orthogroups,
                            edge_kind_rank=ORTHOLOG_DISPLAY_EDGE_KIND_RANK["coortholog"],
                        ),
                        row_record,
                    )
                )

        for orthogroup_id in sorted(set(all_secondary_edges_by_group).union(direct_candidates_by_group)):
            if _orthogroup_scope(orthogroups, orthogroup_id) == "record_local":
                continue
            candidates: list[tuple[tuple[object, ...], dict[str, object]]] = []
            candidates.extend(direct_candidates_by_group.get(orthogroup_id, []))
            for edge in all_secondary_edges_by_group[orthogroup_id]:
                row = _comparison_row_from_ortholog_edge_for_pair(edge, pair)
                if row is None:
                    continue
                row_key = (str(row["query"]), str(row["subject"]))
                row_orthogroup_id = _display_pair_orthogroup_id(
                    row_key[0],
                    row_key[1],
                    orthogroups,
                )
                if row_orthogroup_id != orthogroup_id:
                    continue
                if row_key in existing_pairs or (row_key[1], row_key[0]) in existing_pairs:
                    continue
                candidates.append((_ortholog_edge_display_rank(edge, orthogroups), row))
            added_for_group = 0
            covered_queries = covered_query_by_group.setdefault(orthogroup_id, set())
            covered_subjects = covered_subject_by_group.setdefault(orthogroup_id, set())
            sorted_candidates = sorted(candidates, key=lambda item: item[0])
            candidate_subjects_by_query: dict[str, set[str]] = {}
            candidate_queries_by_subject: dict[str, set[str]] = {}
            candidate_kind_rank_by_pair: dict[tuple[str, str], int] = {}
            for rank, row in sorted_candidates:
                query_id, subject_id = _comparison_row_key(row)
                candidate_subjects_by_query.setdefault(query_id, set()).add(subject_id)
                candidate_queries_by_subject.setdefault(subject_id, set()).add(query_id)
                candidate_kind_rank_by_pair[(query_id, subject_id)] = int(rank[0])

            # Display selection is stricter than membership expansion: prefer
            # same-quality links that introduce new endpoints on both records.
            for require_both_uncovered in (True, False):
                for rank, row in sorted_candidates:
                    if added_for_group >= cap:
                        break
                    row_key = _comparison_row_key(row)
                    if row_key in existing_pairs or (row_key[1], row_key[0]) in existing_pairs:
                        continue
                    query_covered = row_key[0] in covered_queries
                    subject_covered = row_key[1] in covered_subjects
                    if query_covered and subject_covered:
                        continue
                    if require_both_uncovered:
                        if query_covered or subject_covered:
                            continue
                    else:
                        if not (query_covered or subject_covered):
                            continue
                        if _has_uncovered_display_alternative(
                            row_key,
                            current_kind_rank=int(rank[0]),
                            candidate_subjects_by_query=candidate_subjects_by_query,
                            candidate_queries_by_subject=candidate_queries_by_subject,
                            candidate_kind_rank_by_pair=candidate_kind_rank_by_pair,
                            covered_queries=covered_queries,
                            covered_subjects=covered_subjects,
                            existing_pairs=existing_pairs,
                        ):
                            continue
                    _add_display_row(
                        row,
                        existing_pairs=existing_pairs,
                        covered_queries=covered_queries,
                        covered_subjects=covered_subjects,
                        added_rows=added_rows,
                    )
                    added_for_group += 1
                if added_for_group >= cap:
                    break
        if added_rows:
            added_frame = pd.DataFrame.from_records(added_rows, columns=COMPARISON_COLUMNS)
            if anchor_table.empty:
                display_edges_by_pair[pair] = added_frame.reset_index(drop=True)
            else:
                display_edges_by_pair[pair] = pd.concat(
                    [
                        anchor_table.loc[:, list(COMPARISON_COLUMNS)],
                        added_frame,
                    ],
                    ignore_index=True,
                )
    return display_edges_by_pair


def select_rbh_orthogroup_edges_from_directional_hits(
    directional_hits_by_pair: Mapping[tuple[int, int], DataFrame],
    protein_map: Mapping[str, CdsProtein],
    *,
    record_count: int | None = None,
    include_singletons: bool = False,
    orthogroup_membership_mode: OrthogroupMembershipMode | str = ORTHOGROUP_INFERENCE_VERSION,
    orthogroup_member_max_hits: int | None = None,
    max_related_edges_per_orthogroup: int = 2,
    path_representation: Literal["graph", "exhaustive"] = "graph",
    comparison_pairs: Sequence[tuple[int, int]] | None = None,
) -> OrthogroupEdgeSelectionResult:
    """Infer groups from all evidence and project links onto requested display pairs.

    Omitted comparison_pairs preserves consecutive-record display. An empty
    sequence produces membership without display links.
    """

    if path_representation not in {"graph", "exhaustive"}:
        raise ValidationError("path_representation must be graph or exhaustive")
    normalize_orthogroup_membership_mode(str(orthogroup_membership_mode))
    if orthogroup_member_max_hits is not None:
        _validate_max_hits(
            orthogroup_member_max_hits,
            option_name="orthogroup_member_max_hits",
        )
    member_hits = {
        pair: _select_member_candidate_hits_per_query(
            hits,
            max_hits=orthogroup_member_max_hits,
        )
        for pair, hits in directional_hits_by_pair.items()
    }
    result = _select_anchor_core_orthogroup_edges_from_directional_hits(
        member_hits,
        protein_map,
        record_count=record_count,
        include_singletons=include_singletons,
        max_related_edges_per_orthogroup=max_related_edges_per_orthogroup,
        comparison_pairs=comparison_pairs,
    )

    if path_representation == "exhaustive":
        return replace(result, orthogroups=materialize_ortholog_paths(result.orthogroups))
    return result


def build_pairwise_protein_blastp_comparisons(
    records: Sequence[SeqRecord],
    *,
    losatp_bin: str = "losat",
    ncbi_blastp_bin: str | None = None,
    losatp_threads: int | None = None,
    max_hits: int = 5,
    candidate_limit: int | None = None,
    evalue: float = 1e-5,
    bitscore: float = 50.0,
    identity: float = 70.0,
    alignment_length: int = 0,
    runner: LosatpRunner | None = None,
    losatp_cache: LosatpCacheManager | None = None,
    protein_extraction: ProteinExtractionResult | None = None,
    feature_visibility_rules: list[dict[str, object]] | None = None,
    cache_filenames: Sequence[str] | None = None,
) -> ProteinBlastpResult:
    """Generate adjacent-record LOSATP blastp display comparisons."""

    if len(records) < 2:
        raise ValidationError("protein_blastp_mode='pairwise' requires at least two records")
    _validate_max_hits(max_hits)
    _validate_losatp_threads(losatp_threads)
    _validate_candidate_limit(candidate_limit)
    if int(alignment_length) < 0:
        raise ValidationError("alignment_length must be >= 0")

    extraction = protein_extraction or extract_cds_proteins(
        records,
        feature_visibility_rules=feature_visibility_rules,
    )
    _validate_extraction_has_proteins(
        records,
        extraction,
        option_name="protein_blastp_mode='pairwise'",
    )

    comparisons: list[DataFrame] = []
    for record_index in range(len(records) - 1):
        query_fasta = proteins_to_fasta(extraction.proteins_by_record[record_index])
        subject_fasta = proteins_to_fasta(extraction.proteins_by_record[record_index + 1])
        protein_hits = _execute_losatp_search(
            query_fasta,
            subject_fasta,
            losatp_bin=losatp_bin,
            ncbi_blastp_bin=ncbi_blastp_bin,
            losatp_threads=losatp_threads,
            candidate_limit=candidate_limit,
            max_hsps_per_subject=1,
            runner=runner,
            losatp_cache=losatp_cache,
            filename=(
                str(cache_filenames[record_index])
                if cache_filenames is not None and record_index < len(cache_filenames)
                else ""
            ),
            display=True,
        )
        filtered_hits = filter_protein_hits_by_thresholds(
            protein_hits,
            evalue=evalue,
            bitscore=bitscore,
            identity=identity,
            alignment_length=alignment_length,
        )
        display_hits = select_top_hits_per_query(filtered_hits, max_hits=max_hits)
        comparisons.append(
            convert_protein_hits_to_genomic_links(
                display_hits,
                extraction.protein_map,
                orthogroups=None,
            )
        )
    return ProteinBlastpResult(comparisons=comparisons, orthogroups=None)


def build_rbh_orthogroup_protein_blastp_comparisons(
    records: Sequence[SeqRecord],
    *,
    path_representation: Literal["graph", "exhaustive"] = "graph",
    losatp_bin: str = "losat",
    ncbi_blastp_bin: str | None = None,
    losatp_threads: int | None = None,
    candidate_limit: int | None = None,
    orthogroup_membership_mode: OrthogroupMembershipMode | str = ORTHOGROUP_INFERENCE_VERSION,
    orthogroup_member_max_hits: int | None = None,
    max_related_edges_per_orthogroup: int = 2,
    evalue: float = 1e-5,
    bitscore: float = 50.0,
    identity: float = 70.0,
    alignment_length: int = 0,
    runner: LosatpRunner | None = None,
    losatp_cache: LosatpCacheManager | None = None,
    protein_extraction: ProteinExtractionResult | None = None,
    feature_visibility_rules: list[dict[str, object]] | None = None,
    cache_filenames: Sequence[str] | None = None,
) -> ProteinBlastpResult:
    """Infer all-vs-all RBH-seeded orthogroups and return adjacent display links."""

    if path_representation not in {"graph", "exhaustive"}:
        raise ValidationError("path_representation must be graph or exhaustive")
    if len(records) < 2:
        raise ValidationError("protein_blastp_mode='orthogroup' requires at least two records")
    _validate_losatp_threads(losatp_threads)
    _validate_candidate_limit(candidate_limit)
    normalized_membership_mode = normalize_orthogroup_membership_mode(str(orthogroup_membership_mode))
    if orthogroup_member_max_hits is not None:
        _validate_max_hits(orthogroup_member_max_hits, option_name="orthogroup_member_max_hits")
    if int(max_related_edges_per_orthogroup) <= 0:
        raise ValidationError("collinear_max_paralog_links_per_orthogroup must be > 0")
    if int(alignment_length) < 0:
        raise ValidationError("alignment_length must be >= 0")

    extraction = protein_extraction or extract_cds_proteins(
        records,
        feature_visibility_rules=feature_visibility_rules,
    )
    _validate_extraction_has_proteins(
        records,
        extraction,
        option_name="protein_blastp_mode='orthogroup'",
    )

    search_candidate_limit = candidate_limit
    directional_hits_by_pair: dict[tuple[int, int], DataFrame] = {}
    for query_index in range(len(records)):
        for subject_index in range(query_index, len(records)):
            query_fasta = proteins_to_fasta(extraction.proteins_by_record[query_index])
            subject_fasta = proteins_to_fasta(extraction.proteins_by_record[subject_index])

            forward_hits = _execute_losatp_search(
                query_fasta,
                subject_fasta,
                losatp_bin=losatp_bin,
                ncbi_blastp_bin=ncbi_blastp_bin,
                losatp_threads=losatp_threads,
                candidate_limit=search_candidate_limit,
                max_hsps_per_subject=None,
                runner=runner,
                losatp_cache=losatp_cache,
                filename=(
                    str(cache_filenames[query_index])
                    if cache_filenames is not None and query_index < len(cache_filenames)
                    else ""
                ),
                display=subject_index == query_index + 1,
            )
            filtered_forward_hits = filter_protein_hits_by_thresholds(
                forward_hits,
                evalue=evalue,
                bitscore=bitscore,
                identity=identity,
                alignment_length=alignment_length,
            )
            directional_hits_by_pair[(query_index, subject_index)] = filtered_forward_hits
            if query_index == subject_index:
                continue
            reverse_hits = _execute_losatp_search(
                subject_fasta,
                query_fasta,
                losatp_bin=losatp_bin,
                ncbi_blastp_bin=ncbi_blastp_bin,
                losatp_threads=losatp_threads,
                candidate_limit=search_candidate_limit,
                max_hsps_per_subject=None,
                runner=runner,
                losatp_cache=losatp_cache,
                display=False,
            )
            filtered_reverse_hits = filter_protein_hits_by_thresholds(
                reverse_hits,
                evalue=evalue,
                bitscore=bitscore,
                identity=identity,
                alignment_length=alignment_length,
            )
            directional_hits_by_pair[(subject_index, query_index)] = filtered_reverse_hits

    edge_selection = select_rbh_orthogroup_edges_from_directional_hits(
        directional_hits_by_pair,
        extraction.protein_map,
        path_representation=path_representation,
        record_count=len(records),
        orthogroup_membership_mode=normalized_membership_mode,
        orthogroup_member_max_hits=orthogroup_member_max_hits,
        max_related_edges_per_orthogroup=max_related_edges_per_orthogroup,
    )
    comparisons = [
        convert_protein_hits_to_genomic_links(
            edge_selection.adjacent_display_edges_by_pair.get(
                (record_index, record_index + 1),
                _empty_comparison_hits(),
            ),
            extraction.protein_map,
            orthogroups=edge_selection.orthogroups,
        )
        for record_index in range(len(records) - 1)
    ]
    return ProteinBlastpResult(comparisons=comparisons, orthogroups=edge_selection.orthogroups)


__all__ = [
    "CdsProtein",
    "LEGACY_PROTEIN_LOSAT_CACHE_SCHEMA",
    "LEGACY_PROTEIN_RAW_CANDIDATE_SCHEMA",
    "LOSAT_CACHE_SCHEMA",
    "LOSATP_COMPARISON_COLUMNS",
    "LOSATP_METADATA_COLUMNS",
    "LegacyProteinRawCachePromotion",
    "LegacyProteinRawCachePromotionScan",
    "LegacyProteinRawCacheRejection",
    "LosatpCacheManager",
    "ORTHOGROUP_INFERENCE_VERSION",
    "ORTHOGROUP_MEMBERSHIP_MODES",
    "PROTEIN_BLASTP_MODES",
    "OrthogroupEdgeSelectionResult",
    "OrthogroupMember",
    "OrthogroupMemberConfidence",
    "OrthogroupMemberRole",
    "OrthogroupMembershipMode",
    "OrthogroupNameCandidate",
    "OrthogroupResult",
    "OrthogroupGraphResult",
    "OrthologPathCollection",
    "materialize_ortholog_paths",
    "OrthogroupScope",
    "OrthologEdge",
    "OrthologEdgeKind",
    "OrthologPath",
    "OrthologRenderRole",
    "ProteinBlastpMode",
    "ProteinBlastpResult",
    "ProteinBlastpRuntime",
    "ProteinExtractionResult",
    "ProteinIdentityManifest",
    "ProteinLosatPairIdentity",
    "PROTEIN_IDENTITY_MANIFEST_SCHEMA",
    "PROTEIN_LOSAT_CACHE_SCHEMA",
    "build_legacy_protein_reference_map",
    "build_protein_export_id_map",
    "build_protein_losat_cache_key",
    "build_protein_losat_pair_identity",
    "build_protein_runtime_handle",
    "build_web_losat_cache_key",
    "build_pairwise_protein_blastp_comparisons",
    "build_rbh_orthogroup_protein_blastp_comparisons",
    "convert_pair_protein_hits_to_genomic_links",
    "convert_protein_hits_to_genomic_links",
    "canonical_feature_analysis_id",
    "canonical_protein_identity_json",
    "extract_cds_proteins",
    "extract_protein_identity_manifest",
    "extract_web_stable_cds_proteins",
    "filter_protein_hits_by_thresholds",
    "hydrate_protein_losat_tsv",
    "normalize_orthogroup_membership_mode",
    "normalize_protein_blastp_mode",
    "parse_losatp_outfmt6",
    "parse_losat_fasta_ids",
    "percent_encode_losat_transport_field",
    "proteins_to_fasta",
    "promote_legacy_protein_raw_cache_entries",
    "raw_protein_tsv_matches_bindings",
    "run_losatp_blastp",
    "select_protein_display_alias",
    "select_best_hits_per_query",
    "select_rbh_orthogroup_edges_from_directional_hits",
    "select_reciprocal_best_hit_edges",
    "select_reciprocal_best_hits",
    "select_top_hits_per_query",
    "is_legacy_protein_losat_cache_entry",
    "is_protein_losat_cache_entry",
    "make_legacy_protein_raw_candidate",
    "validate_legacy_protein_raw_candidate_envelope",
    "validate_protein_identity_manifest",
    "validate_protein_raw_entry_references",
]
