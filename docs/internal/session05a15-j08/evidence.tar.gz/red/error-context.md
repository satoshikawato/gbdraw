# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settings-only-session.playwright.spec.js >> settings-only Session preserves non-default Circular and Linear profiles through real Save and fresh Load
- Location: tests/web/settings-only-session.playwright.spec.js:54:1

# Error details

```
Error: Ordinary source-free Save must produce a Session download

expect(received).toBeNull()

Received: {"details": [], "summary": "Canonical resource record-1-genbank is missing."}
```

# Test source

```ts
  1   | const { test, expect } = require('@playwright/test');
  2   | const fs = require('node:fs/promises');
  3   | const { gunzipSync } = require('node:zlib');
  4   | const { openApp, assertDiagramWorkerIdle } = require('./helpers/app-lifecycle.cjs');
  5   | 
  6   | const snapshot = page => page.evaluate(async () => {
  7   |   const { state: s } = await import('./js/state.js');
  8   |   const { buildConfigData, getCommittedCanonicalSession } = await import('./js/services/config.js');
  9   |   return {
  10  |     mode: s.mode.value, config: buildConfigData(),
  11  |     circularSources: ['c_gb', 'c_gff', 'c_fasta'].map(key => Boolean(s.files[key])),
  12  |     linearSources: s.linearSeqs.map(row => ['gb', 'gff', 'fasta'].map(key => Boolean(row[key]))),
  13  |     results: s.results.value.length, catalog: s.featureCatalog.value,
  14  |     committed: getCommittedCanonicalSession(), error: s.errorLog.value
  15  |   };
  16  | });
  17  | 
  18  | const assertSourceFree = state => {
  19  |   expect(state.circularSources).toEqual([false, false, false]);
  20  |   expect(state.linearSources.flat().some(Boolean)).toBe(false);
  21  |   expect(state.results).toBe(0);
  22  |   expect(state.catalog).toBeNull();
  23  |   expect(state.committed).toBeNull();
  24  | };
  25  | 
  26  | const reveal = async locator => {
  27  |   for (const details of await locator.locator('xpath=ancestor::details').all()) {
  28  |     if (await details.getAttribute('open') === null) await details.locator(':scope > summary').click();
  29  |   }
  30  |   return locator;
  31  | };
  32  | 
  33  | const save = async (page, testInfo, label) => {
  34  |   let downloaded;
  35  |   const listener = download => { downloaded = download; };
  36  |   page.on('download', listener);
  37  |   try {
  38  |     await page.getByRole('button', { name: 'Save Session', exact: true }).click();
  39  |     // Await operation settlement, then assert once. Preserve the product error
  40  |     // as the red witness instead of reporting only a download timeout.
  41  |     await expect.poll(async () => Boolean(downloaded || (await snapshot(page)).error), { timeout: 180_000 }).toBe(true);
  42  |     const boundary = await snapshot(page);
  43  |     await fs.writeFile(testInfo.outputPath(`${label}-save-boundary.json`), JSON.stringify(boundary, null, 2));
> 44  |     expect(boundary.error, 'Ordinary source-free Save must produce a Session download').toBeNull();
      |                                                                                         ^ Error: Ordinary source-free Save must produce a Session download
  45  |     expect(downloaded).toBeTruthy();
  46  |     const file = testInfo.outputPath(`${label}.gbdraw-session.json.gz`);
  47  |     await downloaded.saveAs(file);
  48  |     return { file, document: JSON.parse(gunzipSync(await fs.readFile(file))) };
  49  |   } finally {
  50  |     page.off('download', listener);
  51  |   }
  52  | };
  53  | 
  54  | test('settings-only Session preserves non-default Circular and Linear profiles through real Save and fresh Load', async ({ browser }, testInfo) => {
  55  |   test.setTimeout(1_800_000);
  56  |   const contexts = [];
  57  |   const fresh = async () => {
  58  |     const context = await browser.newContext();
  59  |     contexts.push(context);
  60  |     await context.route('**/*', route => new URL(route.request().url()).hostname === '127.0.0.1'
  61  |       ? route.continue() : route.abort());
  62  |     const page = await context.newPage();
  63  |     page.on('dialog', dialog => dialog.accept(dialog.type() === 'prompt' ? 'J08 settings' : undefined));
  64  |     await openApp(page);
  65  |     return page;
  66  |   };
  67  |   try {
  68  |     const page = await fresh();
  69  |     assertSourceFree(await snapshot(page));
  70  |     await (await reveal(page.locator('#circular-label-mode'))).selectOption('both');
  71  |     await (await reveal(page.locator('#circular-track-preset'))).selectOption('middle');
  72  |     await page.getByRole('button', { name: 'Linear', exact: true }).click();
  73  |     await (await reveal(page.locator('#linear-show-labels'))).selectOption('all');
  74  |     await page.getByRole('button', { name: 'Circular', exact: true }).click();
  75  |     const before = await snapshot(page);
  76  |     expect(before.config.form.labels_mode).toBe('both');
  77  |     expect(before.config.form.track_type).toBe('middle');
  78  |     const saved = await save(page, testInfo, 'first');
  79  |     assertSourceFree(await snapshot(page));
  80  |     await assertDiagramWorkerIdle(page);
  81  | 
  82  |     const restored = await fresh();
  83  |     const loaded = restored.waitForEvent('dialog');
  84  |     await restored.locator('input[accept^=".json,"]').setInputFiles(saved.file);
  85  |     expect((await loaded).message()).toBe('Session loaded successfully!');
  86  |     await restored.waitForFunction(() => !window.__GBDRAW_APP__.sessionImportPending);
  87  |     const after = await snapshot(restored);
  88  |     assertSourceFree(after);
  89  |     expect(after.mode).toBe('circular');
  90  |     expect(after.config.form.labels_mode).toBe('both');
  91  |     expect(after.config.form.track_type).toBe('middle');
  92  |     expect(after.config).toEqual(before.config);
  93  |     await assertDiagramWorkerIdle(restored);
  94  |     const again = await save(restored, testInfo, 'second');
  95  |     expect(again.document.config).toEqual(saved.document.config);
  96  |     expect(again.document.resources).toEqual(saved.document.resources);
  97  |     await restored.getByRole('button', { name: 'Linear', exact: true }).click();
  98  |     expect((await snapshot(restored)).config.form.show_labels_linear).toBe('all');
  99  |     await restored.getByRole('button', { name: 'Circular', exact: true }).click();
  100 |     expect((await snapshot(restored)).config.form.labels_mode).toBe('both');
  101 |     await assertDiagramWorkerIdle(restored);
  102 |   } finally {
  103 |     for (const context of contexts) await context.close();
  104 |   }
  105 | });
  106 | 
```