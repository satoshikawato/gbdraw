const base = require('/tmp/gbdraw-session-05a15-j08/playwright.config.js');
module.exports = {
  ...base,
  testDir: '/tmp/gbdraw-session-05a15-j08/tests/web',
  testMatch: 'settings-only-session.playwright.spec.js',
  grep: /preserves non-default Circular/,
  workers: 1,
  use: { ...base.use, baseURL: 'http://127.0.0.1:4179' },
  webServer: {
    command: 'python3 -m http.server 4179 --bind 127.0.0.1 --directory /tmp/gbdraw-j08-evidence/main',
    url: 'http://127.0.0.1:4179', reuseExistingServer: false, stderr: 'ignore'
  }
};
