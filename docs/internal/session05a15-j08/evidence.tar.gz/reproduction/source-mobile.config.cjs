const base = require('/tmp/gbdraw-session-05a15-j08/playwright.config.js');
module.exports = {
  ...base,
  testDir: '/tmp/gbdraw-session-05a15-j08/tests/web',
  testMatch: 'settings-only-session.playwright.spec.js',
  grep: /preserves non-default Circular/,
  workers: 1,
  projects: [{ name: 'source-mobile', use: { viewport: { width: 390, height: 844 } } }]
};
